import Foundation
import UIKit

// THIS FILE IS AUTO-GENERATED. PLEASE DO NOT EDIT IT MANUALLY.
// Generated on 24/08/2023 11:30:15 am

/// Tokens that are common and share the same values across all themes
///
/// Not seeing what you expect to see? Yes this file only consist of 
/// tokens that are common across all themes - so if the token you are 
/// looking for is missing from one of the themes, they would not be here!
///
/// So what should you do?
///
/// You can either get designers to ensure they exist for all themes, or 
/// perform a pre-processing step that ensure the key exists in all themes.
public enum GlobalTokens {
    public enum borderRadius {
        /// Type: borderRadius
        public static let xs: CGFloat = 2
        /// Type: borderRadius
        public static let s: CGFloat = 4
        /// Type: borderRadius
        public static let m: CGFloat = 8
        /// Type: borderRadius
        public static let ml: CGFloat = 12
        /// Type: borderRadius
        public static let l: CGFloat = 16
        /// Type: borderRadius
        public static let big: CGFloat = 20
        /// Type: borderRadius
        public static let xl: CGFloat = 24
        /// Type: borderRadius
        public static let xxl: CGFloat = 32
        /// Type: borderRadius
        public static let none: CGFloat = 0
    }

    public enum borderWidth {
        /// Type: borderWidth
        public static let s: CGFloat = 1
        /// Type: borderWidth
        public static let m: CGFloat = 2
    }

    public enum fontFamilies {
        /// Type: fontFamilies
        public static let roboto = "Roboto"
        /// Type: fontFamilies
        public static let opensans = "Open Sans"
        /// Type: fontFamilies
        public static let poppins = "Poppins"
        /// Type: fontFamilies
        public static let geomanist = "Geomanist"
    }

    public enum fontSize {
        /// Type: fontSizes
        public static let xxxs: CGFloat = 10
        /// Type: fontSizes
        public static let xxs: CGFloat = 12
        /// Type: fontSizes
        public static let xs: CGFloat = 14
        /// Type: fontSizes
        public static let s: CGFloat = 16
        /// Type: fontSizes
        public static let m: CGFloat = 18
        /// Type: fontSizes
        public static let l: CGFloat = 20
        /// Type: fontSizes
        public static let xl: CGFloat = 24
        /// Type: fontSizes
        public static let xxl: CGFloat = 26
        /// Type: fontSizes
        public static let xxxl: CGFloat = 32
        /// Type: fontSizes
        public static let big: CGFloat = 40
    }

    public enum fontWeights {
        /// Type: fontWeights
        public static let light = "Light"
        /// Type: fontWeights
        public static let regular = "Regular"
        /// Type: fontWeights
        public static let medium = "Medium"
        /// Type: fontWeights
        public static let semibold = "SemiBold"
        /// Type: fontWeights
        public static let bold = "Bold"
        /// Type: fontWeights
        public static let book = "Book"
    }

    public enum letterSpacing {
        /// Type: letterSpacing
        public static let none: CGFloat = 0
        /// Type: letterSpacing
        public static let s: CGFloat = 1
    }

    public enum lineHeights {
        /// Type: lineHeights
        public static let xBig: CGFloat = 48
        /// Type: lineHeights
        public static let big: CGFloat = 40
        /// Type: lineHeights
        public static let xxl: CGFloat = 32
        /// Type: lineHeights
        public static let xl: CGFloat = 28
        /// Type: lineHeights
        public static let l: CGFloat = 24
        /// Type: lineHeights
        public static let m: CGFloat = 20
        /// Type: lineHeights
        public static let s: CGFloat = 16
        /// Type: lineHeights
        public static let xs: CGFloat = 14
        /// Type: lineHeights
        public static let xxs: CGFloat = 12
    }

    public enum paragraphSpacing {
        /// Type: paragraphSpacing
        public static let none: CGFloat = 0
    }

    public enum size {
        /// Type: sizing
        public static let xxs: CGFloat = 4
        /// Type: sizing
        public static let xs: CGFloat = 8
        /// Type: sizing
        public static let s: CGFloat = 16
        /// Type: sizing
        public static let m: CGFloat = 24
        /// Type: sizing
        public static let ml: CGFloat = 32
        /// Type: sizing
        public static let l: CGFloat = 40
        /// Type: sizing
        public static let xl: CGFloat = 48
    }

    public enum space {
        /// Type: spacing
        public static let none: CGFloat = 0
        /// Type: spacing
        public static let xxxxs: CGFloat = 2
        /// Type: spacing
        public static let xxxs: CGFloat = 4
        /// Type: spacing
        public static let xxs: CGFloat = 8
        /// Type: spacing
        public static let xs: CGFloat = 12
        /// Type: spacing
        public static let s: CGFloat = 16
        /// Type: spacing
        public static let ms: CGFloat = 20
        /// Type: spacing
        public static let m: CGFloat = 24
        /// Type: spacing
        public static let l: CGFloat = 32
        /// Type: spacing
        public static let xl: CGFloat = 40
        /// Type: spacing
        public static let xxl: CGFloat = 48
        /// Type: spacing
        public static let xxxl: CGFloat = 56
        /// Type: spacing
        public static let xxxxl: CGFloat = 64
        /// Type: spacing
        public static let big: CGFloat = 80
        /// Type: spacing
        public static let xBig: CGFloat = 96
        /// Type: spacing
        public static let xxBig: CGFloat = 160
    }

    public enum textCase {
        /// Type: textCase
        public static let none = "none"
        /// Type: textCase
        public static let uppercase = "uppercase"
    }

    public enum textDecoration {
        /// Type: textDecoration
        public static let none = "none"
    }
}
