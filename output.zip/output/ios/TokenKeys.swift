import Foundation
import UIKit

// THIS FILE IS AUTO-GENERATED. PLEASE DO NOT EDIT IT MANUALLY.
// Generated on 21/09/2023 9:22:28 am

public enum TokenKeys {
    public enum text {
        public enum link {
            /// Type: color
            public static let active = "text.link.active.value"
            /// Type: color
            public static let pressed = "text.link.pressed.value"
            /// Type: color
            public static let disabled = "text.link.disabled.value"
        }

        /// Type: color
        public static let error = "text.error.value"
        /// Type: color
        public static let header = "text.header.value"
        /// Type: color
        public static let success = "text.success.value"
        public enum body {
            /// Type: color
            public static let onLight = "text.body.onLight.value"
            /// Type: color
            public static let onDark = "text.body.onDark.value"
            public enum caption {
                /// Type: color
                public static let onLight = "text.body.caption.onLight.value"
                /// Type: color
                public static let onDark = "text.body.caption.onDark.value"
            }

            public enum eyebrow {
                /// Type: color
                public static let primary = "text.body.eyebrow.primary.value"
                /// Type: color
                public static let secondary = "text.body.eyebrow.secondary.value"
            }

            /// Type: color
            public static let disabled = "text.body.disabled.value"
        }
    }

    public enum interactive {
        public enum primary {
            public enum bg {
                /// Type: color
                public static let defaultValue = "interactive.primary.bg.default.value"
                /// Type: color
                public static let pressed = "interactive.primary.bg.pressed.value"
                /// Type: color
                public static let disabled = "interactive.primary.bg.disabled.value"
            }
        }

        public enum secondary {
            public enum bg {
                /// Type: color
                public static let defaultValue = "interactive.secondary.bg.default.value"
                /// Type: color
                public static let pressed = "interactive.secondary.bg.pressed.value"
                /// Type: color
                public static let disabled = "interactive.secondary.bg.disabled.value"
            }

            public enum border {
                /// Type: color
                public static let defaultValue = "interactive.secondary.border.default.value"
                /// Type: color
                public static let pressed = "interactive.secondary.border.pressed.value"
                /// Type: color
                public static let disabled = "interactive.secondary.border.disabled.value"
            }
        }
    }

    public enum icon {
        public enum link {
            /// Type: color
            public static let active = "icon.link.active.value"
            /// Type: color
            public static let pressed = "icon.link.pressed.value"
            /// Type: color
            public static let disabled = "icon.link.disabled.value"
        }

        /// Type: color
        public static let alert = "icon.alert.value"
        /// Type: color
        public static let error = "icon.error.value"
        /// Type: color
        public static let success = "icon.success.value"
        /// Type: color
        public static let informational = "icon.informational.value"
        public enum defaultValue {
            /// Type: color
            public static let onDark = "icon.default.onDark.value"
            /// Type: color
            public static let onLight = "icon.default.onLight.value"
        }
    }

    public enum background {
        /// Type: color
        public static let surface1 = "background.surface1.value"
        /// Type: color
        public static let surface2 = "background.surface2.value"
        /// Type: color
        public static let highlight = "background.highlight.value"
    }

    public enum hyperlinks {
        /// Type: typography
        public static let primary = "hyperlinks.primary.value"
        /// Type: typography
        public static let secondary = "hyperlinks.secondary.value"
        /// Type: typography
        public static let tertiary = "hyperlinks.tertiary.value"
    }

    public enum body {
        public enum primary {
            /// Type: typography
            public static let regular = "body.primary.regular.value"
            /// Type: typography
            public static let semibold = "body.primary.semibold.value"
        }

        public enum secondary {
            /// Type: typography
            public static let regular = "body.secondary.regular.value"
            /// Type: typography
            public static let semibold = "body.secondary.semibold.value"
        }
    }

    public enum caption {
        /// Type: typography
        public static let regular = "caption.regular.value"
        /// Type: typography
        public static let semibold = "caption.semibold.value"
    }

    public enum header {
        /// Type: typography
        public static let primary = "header.primary.value"
        /// Type: typography
        public static let secondary = "header.secondary.value"
    }

    public enum eyebrow {
        /// Type: typography
        public static let primary = "eyebrow.primary.value"
        /// Type: typography
        public static let secondary = "eyebrow.secondary.value"
    }

    /// Type: spacing
    public static let pagemargin = "pagemargin.value"
    public enum button {
        public enum standard {
            public enum color {
                public enum bg {
                    public enum primary {
                        /// Type: color
                        public static let defaultValue = "button.standard.color.bg.primary.default.value"
                        /// Type: color
                        public static let pressed = "button.standard.color.bg.primary.pressed.value"
                        /// Type: color
                        public static let disabled = "button.standard.color.bg.primary.disabled.value"
                    }
                }

                public enum text {
                    public enum primary {
                        /// Type: color
                        public static let defaultValue = "button.standard.color.text.primary.default.value"
                        /// Type: color
                        public static let disabled = "button.standard.color.text.primary.disabled.value"
                    }

                    public enum secondary {
                        /// Type: color
                        public static let defaultValue = "button.standard.color.text.secondary.default.value"
                        /// Type: color
                        public static let disabled = "button.standard.color.text.secondary.disabled.value"
                    }
                }

                public enum border {
                    public enum secondary {
                        /// Type: color
                        public static let defaultValue = "button.standard.color.border.secondary.default.value"
                        /// Type: color
                        public static let pressed = "button.standard.color.border.secondary.pressed.value"
                        /// Type: color
                        public static let disabled = "button.standard.color.border.secondary.disabled.value"
                    }
                }

                public enum icon {
                    public enum primary {
                        /// Type: color
                        public static let defaultValue = "button.standard.color.icon.primary.default.value"
                        /// Type: color
                        public static let disabled = "button.standard.color.icon.primary.disabled.value"
                    }

                    public enum secondary {
                        /// Type: color
                        public static let defaultValue = "button.standard.color.icon.secondary.default.value"
                        /// Type: color
                        public static let disabled = "button.standard.color.icon.secondary.disabled.value"
                    }
                }
            }

            /// Type: borderRadius
            public static let borderRadius = "button.standard.borderRadius.value"
            public enum spacing {
                /// Type: spacing
                public static let vertical = "button.standard.spacing.vertical.value"
            }
        }

        public enum slider {
            /// Type: typography
            public static let font = "button.slider.font.value"
            public enum color {
                public enum container {
                    /// Type: color
                    public static let defaultValue = "button.slider.color.container.default.value"
                    /// Type: color
                    public static let pressed = "button.slider.color.container.pressed.value"
                    /// Type: color
                    public static let success = "button.slider.color.container.success.value"
                    /// Type: color
                    public static let error = "button.slider.color.container.error.value"
                    /// Type: color
                    public static let disabled = "button.slider.color.container.disabled.value"
                }

                public enum knob {
                    /// Type: color
                    public static let defaultValue = "button.slider.color.knob.default.value"
                    /// Type: color
                    public static let disabled = "button.slider.color.knob.disabled.value"
                }

                public enum icon {
                    /// Type: color
                    public static let defaultValue = "button.slider.color.icon.default.value"
                    public enum knob {
                        /// Type: color
                        public static let defaultValue = "button.slider.color.icon.knob.default.value"
                        /// Type: color
                        public static let disabled = "button.slider.color.icon.knob.disabled.value"
                    }
                }

                public enum text {
                    /// Type: color
                    public static let defaultValue = "button.slider.color.text.default.value"
                    /// Type: color
                    public static let pressed = "button.slider.color.text.pressed.value"
                    /// Type: color
                    public static let disabled = "button.slider.color.text.disabled.value"
                }
            }

            public enum loader {
                /// Type: other
                public static let mode = "button.slider.loader.mode.value"
            }
        }

        /// Type: typography
        public static let font = "button.font.value"
        public enum rounded {
            /// Type: borderRadius
            public static let borderRadius = "button.rounded.borderRadius.value"
            public enum spacing {
                /// Type: spacing
                public static let vertical = "button.rounded.spacing.vertical.value"
                /// Type: spacing
                public static let gap = "button.rounded.spacing.gap.value"
                /// Type: spacing
                public static let horizontal = "button.rounded.spacing.horizontal.value"
            }
        }

        public enum combo {
            public enum standard {
                public enum spacing {
                    /// Type: spacing
                    public static let gap = "button.combo.standard.spacing.gap.value"
                    /// Type: spacing
                    public static let vertical = "button.combo.standard.spacing.vertical.value"
                }
            }

            public enum rounded {
                public enum spacing {
                    /// Type: spacing
                    public static let gap = "button.combo.rounded.spacing.gap.value"
                }
            }

            public enum standardHorizontal {
                public enum spacing {
                    /// Type: spacing
                    public static let gap = "button.combo.standardHorizontal.spacing.gap.value"
                }
            }
        }

        public enum textLink {
            /// Type: spacing
            public static let gap = "button.textLink.gap.value"
            public enum color {
                public enum text {
                    public enum defaultValue {
                        /// Type: color
                        public static let onLight = "button.textLink.color.text.default.onLight.value"
                        /// Type: color
                        public static let onDark = "button.textLink.color.text.default.onDark.value"
                    }

                    public enum pressed {
                        /// Type: color
                        public static let onLight = "button.textLink.color.text.pressed.onLight.value"
                        /// Type: color
                        public static let onDark = "button.textLink.color.text.pressed.onDark.value"
                    }

                    public enum disabled {
                        /// Type: color
                        public static let onLight = "button.textLink.color.text.disabled.onLight.value"
                        /// Type: color
                        public static let onDark = "button.textLink.color.text.disabled.onDark.value"
                    }
                }

                public enum icon {
                    public enum defaultValue {
                        /// Type: color
                        public static let onLight = "button.textLink.color.icon.default.onLight.value"
                        /// Type: color
                        public static let onDark = "button.textLink.color.icon.default.onDark.value"
                    }

                    public enum pressed {
                        /// Type: color
                        public static let onLight = "button.textLink.color.icon.pressed.onLight.value"
                        /// Type: color
                        public static let onDark = "button.textLink.color.icon.pressed.onDark.value"
                    }

                    public enum disabled {
                        /// Type: color
                        public static let onLight = "button.textLink.color.icon.disabled.onLight.value"
                        /// Type: color
                        public static let onDark = "button.textLink.color.icon.disabled.onDark.value"
                    }
                }
            }

            public enum font {
                /// Type: typography
                public static let primary = "button.textLink.font.primary.value"
                /// Type: typography
                public static let secondary = "button.textLink.font.secondary.value"
                /// Type: typography
                public static let tertiary = "button.textLink.font.tertiary.value"
            }

            public enum icon {
                /// Type: sizing
                public static let size = "button.textLink.icon.size.value"
            }

            public enum tertiary {
                public enum icon {
                    /// Type: sizing
                    public static let size = "button.textLink.tertiary.icon.size.value"
                }
            }
        }

        public enum circle {
            public enum color {
                public enum bg {
                    /// Type: color
                    public static let defaultValue = "button.circle.color.bg.default.value"
                    /// Type: color
                    public static let pressed = "button.circle.color.bg.pressed.value"
                    /// Type: color
                    public static let disabled = "button.circle.color.bg.disabled.value"
                }

                /// Type: color
                public static let actionIcon = "button.circle.color.actionIcon.value"
            }

            public enum size {
                /// Type: sizing
                public static let m = "button.circle.size.m.value"
                /// Type: sizing
                public static let l = "button.circle.size.l.value"
                /// Type: sizing
                public static let xl = "button.circle.size.xl.value"
            }
        }

        public enum sticky {
            public enum spacing {
                public enum vertical {
                    /// Type: spacing
                    public static let wHomeBar = "button.sticky.spacing.vertical.wHomeBar.value"
                    /// Type: spacing
                    public static let noHomeBar = "button.sticky.spacing.vertical.noHomeBar.value"
                }
            }

            /// Type: boxShadow
            public static let boxShadow = "button.sticky.boxShadow.value"
            /// Type: borderRadius
            public static let borderRadius = "button.sticky.borderRadius.value"
            public enum color {
                /// Type: color
                public static let container = "button.sticky.color.container.value"
            }
        }
    }

    public enum overlay {
        public enum color {
            /// Type: color
            public static let container = "overlay.color.container.value"
        }
    }

    public enum toast {
        public enum color {
            public enum actionIcon {
                /// Type: color
                public static let defaultValue = "toast.color.actionIcon.default.value"
            }

            public enum statusIcon {
                /// Type: color
                public static let defaultValue = "toast.color.statusIcon.default.value"
                /// Type: color
                public static let success = "toast.color.statusIcon.success.value"
                /// Type: color
                public static let error = "toast.color.statusIcon.error.value"
                /// Type: color
                public static let informational = "toast.color.statusIcon.informational.value"
            }

            public enum bg {
                public enum container {
                    /// Type: color
                    public static let defaultValue = "toast.color.bg.container.default.value"
                    /// Type: color
                    public static let success = "toast.color.bg.container.success.value"
                    /// Type: color
                    public static let error = "toast.color.bg.container.error.value"
                    /// Type: color
                    public static let informational = "toast.color.bg.container.informational.value"
                }

                public enum emphasis {
                    /// Type: color
                    public static let success = "toast.color.bg.emphasis.success.value"
                    /// Type: color
                    public static let error = "toast.color.bg.emphasis.error.value"
                    /// Type: color
                    public static let informational = "toast.color.bg.emphasis.informational.value"
                }
            }

            /// Type: color
            public static let font = "toast.color.font.value"
            public enum fullWidthIcon {
                /// Type: color
                public static let error = "toast.color.fullWidthIcon.error.value"
                /// Type: color
                public static let success = "toast.color.fullWidthIcon.success.value"
                /// Type: color
                public static let informational = "toast.color.fullWidthIcon.informational.value"
            }
        }

        /// Type: borderRadius
        public static let borderRadius = "toast.borderRadius.value"
        /// Type: typography
        public static let font = "toast.font.value"
        public enum spacing {
            /// Type: spacing
            public static let vertical = "toast.spacing.vertical.value"
            /// Type: spacing
            public static let horizontal = "toast.spacing.horizontal.value"
            /// Type: spacing
            public static let gap = "toast.spacing.gap.value"
            public enum fullWidth {
                /// Type: spacing
                public static let topPadding = "toast.spacing.fullWidth.topPadding.value"
                /// Type: spacing
                public static let vertical = "toast.spacing.fullWidth.vertical.value"
                /// Type: spacing
                public static let horizontal = "toast.spacing.fullWidth.horizontal.value"
                /// Type: spacing
                public static let gap = "toast.spacing.fullWidth.gap.value"
            }
        }

        /// Type: sizing
        public static let size = "toast.size.value"
        /// Type: typography
        public static let title = "toast.title.value"
    }

    public enum avatar {
        /// Type: typography
        public static let font = "avatar.font.value"
        public enum color {
            public enum bg {
                /// Type: color
                public static let product = "avatar.color.bg.product.value"
                /// Type: color
                public static let user = "avatar.color.bg.user.value"
            }

            /// Type: color
            public static let text = "avatar.color.text.value"
            /// Type: color
            public static let icon = "avatar.color.icon.value"
        }

        /// Type: sizing
        public static let size = "avatar.size.value"
        /// Type: sizing
        public static let iconSize = "avatar.iconSize.value"
    }

    public enum loader {
        public enum spinner {
            public enum color {
                public enum border {
                    /// Type: color
                    public static let onLight = "loader.spinner.color.border.onLight.value"
                    /// Type: color
                    public static let onDark = "loader.spinner.color.border.onDark.value"
                }
            }

            /// Type: borderWidth
            public static let borderWidth = "loader.spinner.borderWidth.value"
        }

        public enum skeletal {
            public enum color {
                /// Type: color
                public static let bg = "loader.skeletal.color.bg.value"
                /// Type: color
                public static let shimmer = "loader.skeletal.color.shimmer.value"
            }

            public enum gap {
                /// Type: spacing
                public static let vertical = "loader.skeletal.gap.vertical.value"
                /// Type: spacing
                public static let horizontal = "loader.skeletal.gap.horizontal.value"
            }

            public enum horizontal {
                public enum size {
                    /// Type: sizing
                    public static let s = "loader.skeletal.horizontal.size.s.value"
                    /// Type: sizing
                    public static let m = "loader.skeletal.horizontal.size.m.value"
                    /// Type: sizing
                    public static let l = "loader.skeletal.horizontal.size.l.value"
                    /// Type: sizing
                    public static let xl = "loader.skeletal.horizontal.size.xl.value"
                }
            }

            public enum rounded {
                public enum borderRadius {
                    /// Type: borderRadius
                    public static let s = "loader.skeletal.rounded.borderRadius.s.value"
                }
            }
        }
    }

    public enum switchComponent {
        public enum off {
            public enum color {
                public enum container {
                    /// Type: color
                    public static let defaultValue = "switch.off.color.container.default.value"
                    /// Type: color
                    public static let disabled = "switch.off.color.container.disabled.value"
                }

                public enum knob {
                    /// Type: color
                    public static let defaultValue = "switch.off.color.knob.default.value"
                    /// Type: color
                    public static let disabled = "switch.off.color.knob.disabled.value"
                }
            }
        }

        public enum on {
            public enum color {
                public enum container {
                    /// Type: color
                    public static let defaultValue = "switch.on.color.container.default.value"
                    /// Type: color
                    public static let disabled = "switch.on.color.container.disabled.value"
                }

                public enum knob {
                    /// Type: color
                    public static let defaultValue = "switch.on.color.knob.default.value"
                    /// Type: color
                    public static let disabled = "switch.on.color.knob.disabled.value"
                }
            }
        }

        public enum loader {
            /// Type: other
            public static let mode = "switch.loader.mode.value"
        }

        /// Type: boxShadow
        public static let elevation = "switch.elevation.value"
    }

    public enum alerts {
        public enum spacing {
            /// Type: spacing
            public static let vertical = "alerts.spacing.vertical.value"
            /// Type: spacing
            public static let horizontal = "alerts.spacing.horizontal.value"
            /// Type: spacing
            public static let gap = "alerts.spacing.gap.value"
        }

        public enum borderRadius {
            /// Type: borderRadius
            public static let standard = "alerts.borderRadius.standard.value"
            /// Type: borderRadius
            public static let inCard = "alerts.borderRadius.inCard.value"
        }

        /// Type: typography
        public static let font = "alerts.font.value"
        public enum color {
            /// Type: color
            public static let font = "alerts.color.font.value"
            public enum bg {
                public enum container {
                    /// Type: color
                    public static let alert = "alerts.color.bg.container.alert.value"
                    /// Type: color
                    public static let informational = "alerts.color.bg.container.informational.value"
                    /// Type: color
                    public static let promotional = "alerts.color.bg.container.promotional.value"
                }
            }

            /// Type: color
            public static let actionIcon = "alerts.color.actionIcon.value"
            public enum statusIcon {
                /// Type: color
                public static let highAlert = "alerts.color.statusIcon.highAlert.value"
                /// Type: color
                public static let lowAlert = "alerts.color.statusIcon.lowAlert.value"
                /// Type: color
                public static let informational = "alerts.color.statusIcon.informational.value"
                /// Type: color
                public static let promotional = "alerts.color.statusIcon.promotional.value"
            }
        }

        public enum infoIcon {
            /// Type: other
            public static let iconRendering = "alerts.infoIcon.iconRendering.value"
        }
    }

    public enum dividers {
        public enum color {
            public enum bg {
                /// Type: color
                public static let thin = "dividers.color.bg.thin.value"
                /// Type: color
                public static let thick = "dividers.color.bg.thick.value"
            }
        }

        public enum size {
            /// Type: sizing
            public static let thick = "dividers.size.thick.value"
        }
    }

    public enum control {
        public enum on {
            public enum color {
                public enum bg {
                    /// Type: color
                    public static let defaultValue = "control.on.color.bg.default.value"
                    /// Type: color
                    public static let disabled = "control.on.color.bg.disabled.value"
                }

                public enum icon {
                    /// Type: color
                    public static let defaultValue = "control.on.color.icon.default.value"
                    /// Type: color
                    public static let disabled = "control.on.color.icon.disabled.value"
                }
            }
        }

        public enum off {
            public enum color {
                public enum border {
                    /// Type: color
                    public static let defaultValue = "control.off.color.border.default.value"
                    /// Type: color
                    public static let error = "control.off.color.border.error.value"
                }

                public enum bg {
                    /// Type: color
                    public static let disabled = "control.off.color.bg.disabled.value"
                }
            }
        }

        /// Type: boxShadow
        public static let elevation = "control.elevation.value"
        public enum color {
            public enum label {
                /// Type: color
                public static let defaultValue = "control.color.label.default.value"
                /// Type: color
                public static let disabled = "control.color.label.disabled.value"
            }

            public enum description {
                /// Type: color
                public static let defaultValue = "control.color.description.default.value"
                /// Type: color
                public static let disabled = "control.color.description.disabled.value"
            }
        }

        public enum font {
            public enum label {
                /// Type: typography
                public static let s = "control.font.label.s.value"
                /// Type: typography
                public static let xs = "control.font.label.xs.value"
            }

            public enum description {
                /// Type: typography
                public static let s = "control.font.description.s.value"
                /// Type: typography
                public static let xs = "control.font.description.xs.value"
            }
        }

        public enum spacing {
            public enum horizontal {
                /// Type: spacing
                public static let label = "control.spacing.horizontal.label.value"
                /// Type: spacing
                public static let column = "control.spacing.horizontal.column.value"
            }

            public enum vertical {
                /// Type: spacing
                public static let description = "control.spacing.vertical.description.value"
                /// Type: spacing
                public static let status = "control.spacing.vertical.status.value"
                /// Type: spacing
                public static let row = "control.spacing.vertical.row.value"
            }
        }
    }

    public enum tabs {
        public enum color {
            public enum text {
                /// Type: color
                public static let selected = "tabs.color.text.selected.value"
                /// Type: color
                public static let defaultValue = "tabs.color.text.default.value"
                /// Type: color
                public static let pill = "tabs.color.text.pill.value"
            }

            public enum bg {
                /// Type: color
                public static let selectedbar = "tabs.color.bg.selectedbar.value"
                /// Type: color
                public static let pill = "tabs.color.bg.pill.value"
            }
        }

        public enum font {
            /// Type: typography
            public static let large = "tabs.font.large.value"
            /// Type: typography
            public static let medium = "tabs.font.medium.value"
            public enum compact {
                /// Type: typography
                public static let selected = "tabs.font.compact.selected.value"
                /// Type: typography
                public static let defaultValue = "tabs.font.compact.default.value"
            }
        }

        public enum spacing {
            /// Type: spacing
            public static let vertical = "tabs.spacing.vertical.value"
            /// Type: spacing
            public static let horizontal = "tabs.spacing.horizontal.value"
            /// Type: spacing
            public static let gap = "tabs.spacing.gap.value"
        }

        public enum compact {
            /// Type: spacing
            public static let horizontal = "tabs.compact.horizontal.value"
            /// Type: spacing
            public static let gap = "tabs.compact.gap.value"
            /// Type: spacing
            public static let bar = "tabs.compact.bar.value"
        }

        public enum pill {
            /// Type: spacing
            public static let vertical = "tabs.pill.vertical.value"
            /// Type: spacing
            public static let horizontal = "tabs.pill.horizontal.value"
            /// Type: spacing
            public static let inBetween = "tabs.pill.inBetween.value"
            public enum container {
                /// Type: spacing
                public static let vertical = "tabs.pill.container.vertical.value"
                /// Type: spacing
                public static let horizontal = "tabs.pill.container.horizontal.value"
            }
        }
    }

    public enum pagetitle {
        public enum spacing {
            public enum gap {
                /// Type: spacing
                public static let vertical = "pagetitle.spacing.gap.vertical.value"
                /// Type: spacing
                public static let horizontal = "pagetitle.spacing.gap.horizontal.value"
            }

            public enum vertical {
                /// Type: spacing
                public static let l = "pagetitle.spacing.vertical.l.value"
                /// Type: spacing
                public static let m = "pagetitle.spacing.vertical.m.value"
                /// Type: spacing
                public static let s = "pagetitle.spacing.vertical.s.value"
                /// Type: spacing
                public static let xl = "pagetitle.spacing.vertical.xl.value"
            }
        }

        public enum font {
            public enum header {
                /// Type: typography
                public static let large = "pagetitle.font.header.large.value"
                /// Type: typography
                public static let medium = "pagetitle.font.header.medium.value"
                /// Type: typography
                public static let small = "pagetitle.font.header.small.value"
                /// Type: typography
                public static let eyebrow = "pagetitle.font.header.eyebrow.value"
            }

            /// Type: typography
            public static let description = "pagetitle.font.description.value"
        }

        public enum color {
            public enum text {
                /// Type: color
                public static let header = "pagetitle.color.text.header.value"
                /// Type: color
                public static let description = "pagetitle.color.text.description.value"
                /// Type: color
                public static let eyebrow = "pagetitle.color.text.eyebrow.value"
            }
        }
    }

    public enum navigation {
        public enum bottom {
            /// Type: typography
            public static let font = "navigation.bottom.font.value"
            public enum color {
                public enum icon {
                    /// Type: color
                    public static let on = "navigation.bottom.color.icon.on.value"
                    /// Type: color
                    public static let off = "navigation.bottom.color.icon.off.value"
                }

                public enum text {
                    /// Type: color
                    public static let on = "navigation.bottom.color.text.on.value"
                    /// Type: color
                    public static let off = "navigation.bottom.color.text.off.value"
                }

                public enum bg {
                    /// Type: color
                    public static let container = "navigation.bottom.color.bg.container.value"
                }
            }

            public enum borderWidth {
                /// Type: borderWidth
                public static let featured = "navigation.bottom.borderWidth.featured.value"
            }

            public enum spacing {
                public enum gap {
                    /// Type: spacing
                    public static let defaultValue = "navigation.bottom.spacing.gap.default.value"
                }

                public enum vertical {
                    /// Type: spacing
                    public static let bottom = "navigation.bottom.spacing.vertical.bottom.value"
                    /// Type: spacing
                    public static let top = "navigation.bottom.spacing.vertical.top.value"
                }
            }

            public enum size {
                /// Type: sizing
                public static let featured = "navigation.bottom.size.featured.value"
            }
        }

        public enum top {
            public enum standard {
                public enum color {
                    public enum icon {
                        /// Type: color
                        public static let onLight = "navigation.top.standard.color.icon.onLight.value"
                        /// Type: color
                        public static let onDark = "navigation.top.standard.color.icon.onDark.value"
                    }

                    public enum text {
                        /// Type: color
                        public static let onLight = "navigation.top.standard.color.text.onLight.value"
                        /// Type: color
                        public static let onDark = "navigation.top.standard.color.text.onDark.value"
                    }

                    /// Type: color
                    public static let container = "navigation.top.standard.color.container.value"
                }

                public enum spacing {
                    /// Type: spacing
                    public static let vertical = "navigation.top.standard.spacing.vertical.value"
                    /// Type: spacing
                    public static let horizontal = "navigation.top.standard.spacing.horizontal.value"
                    public enum gap {
                        /// Type: spacing
                        public static let defaultValue = "navigation.top.standard.spacing.gap.default.value"
                        /// Type: spacing
                        public static let icon = "navigation.top.standard.spacing.gap.icon.value"
                    }
                }

                /// Type: typography
                public static let font = "navigation.top.standard.font.value"
            }

            public enum search {
                public enum spacing {
                    public enum vertical {
                        /// Type: spacing
                        public static let top = "navigation.top.search.spacing.vertical.top.value"
                        /// Type: spacing
                        public static let bottom = "navigation.top.search.spacing.vertical.bottom.value"
                    }

                    /// Type: spacing
                    public static let horizontal = "navigation.top.search.spacing.horizontal.value"
                }
            }
        }
    }

    public enum search {
        public enum color {
            public enum text {
                public enum input {
                    /// Type: color
                    public static let onDark = "search.color.text.input.onDark.value"
                    /// Type: color
                    public static let onLight = "search.color.text.input.onLight.value"
                }

                public enum placeholder {
                    /// Type: color
                    public static let onDark = "search.color.text.placeholder.onDark.value"
                    /// Type: color
                    public static let onLight = "search.color.text.placeholder.onLight.value"
                }
            }

            public enum icon {
                /// Type: color
                public static let onLight = "search.color.icon.onLight.value"
                /// Type: color
                public static let onDark = "search.color.icon.onDark.value"
            }

            public enum container {
                /// Type: color
                public static let onLight = "search.color.container.onLight.value"
                /// Type: color
                public static let onDark = "search.color.container.onDark.value"
            }

            public enum border {
                /// Type: color
                public static let onLight = "search.color.border.onLight.value"
                /// Type: color
                public static let onDark = "search.color.border.onDark.value"
            }
        }

        public enum font {
            /// Type: typography
            public static let input = "search.font.input.value"
            /// Type: typography
            public static let placeholder = "search.font.placeholder.value"
        }

        public enum spacing {
            public enum searchBar {
                /// Type: spacing
                public static let horizontal = "search.spacing.searchBar.horizontal.value"
                /// Type: spacing
                public static let vertical = "search.spacing.searchBar.vertical.value"
            }
        }

        public enum gap {
            /// Type: spacing
            public static let horizontal = "search.gap.horizontal.value"
            /// Type: spacing
            public static let searchIcon = "search.gap.searchIcon.value"
            /// Type: spacing
            public static let searchBar = "search.gap.searchBar.value"
        }

        /// Type: borderRadius
        public static let borderRadius = "search.borderRadius.value"
    }

    public enum quickactionbar {
        public enum spacing {
            /// Type: spacing
            public static let gap = "quickactionbar.spacing.gap.value"
            /// Type: spacing
            public static let horizontal = "quickactionbar.spacing.horizontal.value"
            /// Type: spacing
            public static let vertical = "quickactionbar.spacing.vertical.value"
        }

        /// Type: typography
        public static let font = "quickactionbar.font.value"
        public enum color {
            public enum icon {
                /// Type: color
                public static let defaultValue = "quickactionbar.color.icon.default.value"
                /// Type: color
                public static let disabled = "quickactionbar.color.icon.disabled.value"
            }

            public enum text {
                /// Type: color
                public static let defaultValue = "quickactionbar.color.text.default.value"
                /// Type: color
                public static let disabled = "quickactionbar.color.text.disabled.value"
            }
        }
    }

    public enum textFields {
        public enum font {
            /// Type: typography
            public static let input = "textFields.font.input.value"
            /// Type: typography
            public static let placeholder = "textFields.font.placeholder.value"
            /// Type: typography
            public static let counter = "textFields.font.counter.value"
            /// Type: typography
            public static let helper = "textFields.font.helper.value"
            /// Type: typography
            public static let error = "textFields.font.error.value"
            public enum label {
                /// Type: typography
                public static let defaultValue = "textFields.font.label.default.value"
                /// Type: typography
                public static let focused = "textFields.font.label.focused.value"
            }

            /// Type: typography
            public static let presuffix = "textFields.font.presuffix.value"
        }

        public enum color {
            public enum text {
                public enum label {
                    /// Type: color
                    public static let defaultValue = "textFields.color.text.label.default.value"
                    /// Type: color
                    public static let focused = "textFields.color.text.label.focused.value"
                    /// Type: color
                    public static let disabled = "textFields.color.text.label.disabled.value"
                }

                public enum input {
                    /// Type: color
                    public static let focused = "textFields.color.text.input.focused.value"
                    /// Type: color
                    public static let disabled = "textFields.color.text.input.disabled.value"
                }

                /// Type: color
                public static let placeholder = "textFields.color.text.placeholder.value"
                public enum counter {
                    /// Type: color
                    public static let focused = "textFields.color.text.counter.focused.value"
                    /// Type: color
                    public static let disabled = "textFields.color.text.counter.disabled.value"
                }

                public enum helper {
                    /// Type: color
                    public static let defaultValue = "textFields.color.text.helper.default.value"
                    /// Type: color
                    public static let disabled = "textFields.color.text.helper.disabled.value"
                }

                /// Type: color
                public static let error = "textFields.color.text.error.value"
                /// Type: color
                public static let success = "textFields.color.text.success.value"
                public enum preSuffix {
                    /// Type: color
                    public static let focused = "textFields.color.text.preSuffix.focused.value"
                    /// Type: color
                    public static let disabled = "textFields.color.text.preSuffix.disabled.value"
                }
            }

            public enum icon {
                /// Type: color
                public static let defaultValue = "textFields.color.icon.default.value"
                /// Type: color
                public static let disabled = "textFields.color.icon.disabled.value"
            }

            public enum underline {
                /// Type: color
                public static let defaultValue = "textFields.color.underline.default.value"
                /// Type: color
                public static let focused = "textFields.color.underline.focused.value"
                /// Type: color
                public static let disabled = "textFields.color.underline.disabled.value"
                /// Type: color
                public static let error = "textFields.color.underline.error.value"
                /// Type: color
                public static let success = "textFields.color.underline.success.value"
            }

            public enum button {
                /// Type: color
                public static let inactive = "textFields.color.button.inactive.value"
                public enum icon {
                    /// Type: color
                    public static let inactive = "textFields.color.button.icon.inactive.value"
                }
            }
        }

        public enum filled {
            public enum color {
                public enum container {
                    /// Type: color
                    public static let defaultValue = "textFields.filled.color.container.default.value"
                    /// Type: color
                    public static let disabled = "textFields.filled.color.container.disabled.value"
                }
            }

            public enum borderRadius {
                /// Type: borderRadius
                public static let top = "textFields.filled.borderRadius.top.value"
                /// Type: borderRadius
                public static let btm = "textFields.filled.borderRadius.btm.value"
            }
        }

        public enum spacing {
            public enum vertical {
                /// Type: spacing
                public static let defaultValue = "textFields.spacing.vertical.default.value"
                public enum bottom {
                    /// Type: spacing
                    public static let focused = "textFields.spacing.vertical.bottom.focused.value"
                }

                public enum top {
                    /// Type: spacing
                    public static let focused = "textFields.spacing.vertical.top.focused.value"
                }
            }

            public enum horizontal {
                /// Type: spacing
                public static let defaultValue = "textFields.spacing.horizontal.default.value"
                /// Type: spacing
                public static let focused = "textFields.spacing.horizontal.focused.value"
            }

            public enum gap {
                /// Type: spacing
                public static let focused = "textFields.spacing.gap.focused.value"
                /// Type: spacing
                public static let scrollbar = "textFields.spacing.gap.scrollbar.value"
                public enum suffix {
                    /// Type: spacing
                    public static let s = "textFields.spacing.gap.suffix.s.value"
                    /// Type: spacing
                    public static let m = "textFields.spacing.gap.suffix.m.value"
                }

                /// Type: spacing
                public static let fields = "textFields.spacing.gap.fields.value"
            }

            public enum helper {
                /// Type: spacing
                public static let vertical = "textFields.spacing.helper.vertical.value"
                /// Type: spacing
                public static let horizontal = "textFields.spacing.helper.horizontal.value"
            }
        }

        public enum borderWidth {
            /// Type: borderWidth
            public static let underline = "textFields.borderWidth.underline.value"
        }

        public enum amount {
            public enum small {
                public enum font {
                    public enum input {
                        /// Type: typography
                        public static let defaultValue = "textFields.amount.small.font.input.default.value"
                        /// Type: typography
                        public static let med = "textFields.amount.small.font.input.med.value"
                        /// Type: typography
                        public static let min = "textFields.amount.small.font.input.min.value"
                    }

                    public enum placeholder {
                        /// Type: typography
                        public static let defaultValue = "textFields.amount.small.font.placeholder.default.value"
                        /// Type: typography
                        public static let med = "textFields.amount.small.font.placeholder.med.value"
                        /// Type: typography
                        public static let min = "textFields.amount.small.font.placeholder.min.value"
                    }

                    /// Type: typography
                    public static let suffix = "textFields.amount.small.font.suffix.value"
                }

                public enum gap {
                    /// Type: spacing
                    public static let dropdown = "textFields.amount.small.gap.dropdown.value"
                    /// Type: spacing
                    public static let flag = "textFields.amount.small.gap.flag.value"
                    /// Type: spacing
                    public static let input = "textFields.amount.small.gap.input.value"
                }
            }

            public enum big {
                public enum font {
                    public enum input {
                        /// Type: typography
                        public static let defaultValue = "textFields.amount.big.font.input.default.value"
                        /// Type: typography
                        public static let med = "textFields.amount.big.font.input.med.value"
                        /// Type: typography
                        public static let min = "textFields.amount.big.font.input.min.value"
                    }

                    public enum placeholder {
                        /// Type: typography
                        public static let defaultValue = "textFields.amount.big.font.placeholder.default.value"
                        /// Type: typography
                        public static let med = "textFields.amount.big.font.placeholder.med.value"
                        /// Type: typography
                        public static let min = "textFields.amount.big.font.placeholder.min.value"
                    }

                    /// Type: typography
                    public static let suffix = "textFields.amount.big.font.suffix.value"
                    /// Type: typography
                    public static let helper = "textFields.amount.big.font.helper.value"
                }

                public enum spacing {
                    /// Type: spacing
                    public static let gap = "textFields.amount.big.spacing.gap.value"
                    public enum description {
                        /// Type: spacing
                        public static let vertical = "textFields.amount.big.spacing.description.vertical.value"
                    }
                }

                public enum gap {
                    /// Type: spacing
                    public static let description = "textFields.amount.big.gap.description.value"
                    /// Type: spacing
                    public static let dropdown = "textFields.amount.big.gap.dropdown.value"
                    /// Type: spacing
                    public static let flag = "textFields.amount.big.gap.flag.value"
                    /// Type: spacing
                    public static let input = "textFields.amount.big.gap.input.value"
                }
            }
        }

        public enum dualAmount {
            public enum small {
                public enum gap {
                    /// Type: spacing
                    public static let vertical = "textFields.dualAmount.small.gap.vertical.value"
                }

                public enum spacing {
                    /// Type: spacing
                    public static let loaders = "textFields.dualAmount.small.spacing.loaders.value"
                }
            }

            public enum big {
                /// Type: sizing
                public static let divider = "textFields.dualAmount.big.divider.value"
                public enum spacing {
                    public enum top {
                        public enum vertical {
                            /// Type: spacing
                            public static let btm = "textFields.dualAmount.big.spacing.top.vertical.btm.value"
                            /// Type: spacing
                            public static let top = "textFields.dualAmount.big.spacing.top.vertical.top.value"
                        }
                    }

                    public enum btm {
                        public enum vertical {
                            /// Type: spacing
                            public static let top = "textFields.dualAmount.big.spacing.btm.vertical.top.value"
                            /// Type: spacing
                            public static let btm = "textFields.dualAmount.big.spacing.btm.vertical.btm.value"
                        }
                    }

                    /// Type: spacing
                    public static let loaders = "textFields.dualAmount.big.spacing.loaders.value"
                    /// Type: spacing
                    public static let horizontal = "textFields.dualAmount.big.spacing.horizontal.value"
                }
            }
        }
    }

    public enum datapoints {
        public enum font {
            public enum label {
                /// Type: typography
                public static let s = "datapoints.font.label.s.value"
                /// Type: typography
                public static let xs = "datapoints.font.label.xs.value"
            }

            public enum details {
                /// Type: typography
                public static let xl = "datapoints.font.details.xl.value"
                /// Type: typography
                public static let l = "datapoints.font.details.l.value"
                /// Type: typography
                public static let m = "datapoints.font.details.m.value"
                /// Type: typography
                public static let s = "datapoints.font.details.s.value"
                /// Type: typography
                public static let xs = "datapoints.font.details.xs.value"
                /// Type: typography
                public static let xxs = "datapoints.font.details.xxs.value"
            }

            /// Type: typography
            public static let description = "datapoints.font.description.value"
            public enum PnL {
                /// Type: typography
                public static let s = "datapoints.font.PnL.s.value"
                /// Type: typography
                public static let xs = "datapoints.font.PnL.xs.value"
            }
        }

        public enum color {
            public enum text {
                /// Type: color
                public static let label = "datapoints.color.text.label.value"
                /// Type: color
                public static let details = "datapoints.color.text.details.value"
                /// Type: color
                public static let description = "datapoints.color.text.description.value"
                /// Type: color
                public static let profit = "datapoints.color.text.profit.value"
                /// Type: color
                public static let loss = "datapoints.color.text.loss.value"
            }

            /// Type: color
            public static let icon = "datapoints.color.icon.value"
            /// Type: color
            public static let emphasisbar = "datapoints.color.emphasisbar.value"
        }

        public enum spacing {
            public enum gap {
                public enum vertical {
                    /// Type: spacing
                    public static let row = "datapoints.spacing.gap.vertical.row.value"
                    /// Type: spacing
                    public static let spacer = "datapoints.spacing.gap.vertical.spacer.value"
                }

                public enum horizontal {
                    /// Type: spacing
                    public static let details = "datapoints.spacing.gap.horizontal.details.value"
                    /// Type: spacing
                    public static let label = "datapoints.spacing.gap.horizontal.label.value"
                    /// Type: spacing
                    public static let column = "datapoints.spacing.gap.horizontal.column.value"
                    /// Type: spacing
                    public static let legend = "datapoints.spacing.gap.horizontal.legend.value"
                }
            }

            public enum padding {
                /// Type: spacing
                public static let label = "datapoints.spacing.padding.label.value"
                /// Type: spacing
                public static let vertical = "datapoints.spacing.padding.vertical.value"
                /// Type: spacing
                public static let legend = "datapoints.spacing.padding.legend.value"
            }
        }

        /// Type: sizing
        public static let spacer = "datapoints.spacer.value"
    }

    public enum dataelements {
        public enum body {
            public enum gap {
                public enum horizontal {
                    /// Type: spacing
                    public static let trailing = "dataelements.body.gap.horizontal.trailing.value"
                    /// Type: spacing
                    public static let text = "dataelements.body.gap.horizontal.text.value"
                }
            }
        }

        public enum header {
            public enum gap {
                public enum horizontal {
                    /// Type: spacing
                    public static let trailng = "dataelements.header.gap.horizontal.trailng.value"
                    /// Type: spacing
                    public static let text = "dataelements.header.gap.horizontal.text.value"
                }
            }
        }

        public enum label {
            public enum gap {
                public enum horizontal {
                    /// Type: spacing
                    public static let trailng = "dataelements.label.gap.horizontal.trailng.value"
                    /// Type: spacing
                    public static let text = "dataelements.label.gap.horizontal.text.value"
                }
            }
        }

        public enum description {
            public enum gap {
                public enum horizontal {
                    /// Type: spacing
                    public static let trailing = "dataelements.description.gap.horizontal.trailing.value"
                    /// Type: spacing
                    public static let text = "dataelements.description.gap.horizontal.text.value"
                }
            }
        }
    }

    public enum bottomSheet {
        public enum spacing {
            public enum swipeBar {
                public enum vertical {
                    /// Type: spacing
                    public static let top = "bottomSheet.spacing.swipeBar.vertical.top.value"
                    /// Type: spacing
                    public static let bottom = "bottomSheet.spacing.swipeBar.vertical.bottom.value"
                }
            }

            public enum cta {
                public enum standard {
                    public enum vertical {
                        /// Type: spacing
                        public static let top = "bottomSheet.spacing.cta.standard.vertical.top.value"
                        /// Type: spacing
                        public static let bottom = "bottomSheet.spacing.cta.standard.vertical.bottom.value"
                    }

                    /// Type: spacing
                    public static let horizontal = "bottomSheet.spacing.cta.standard.horizontal.value"
                }

                public enum sticky {
                    public enum vertical {
                        /// Type: spacing
                        public static let top = "bottomSheet.spacing.cta.sticky.vertical.top.value"
                        /// Type: spacing
                        public static let bottom = "bottomSheet.spacing.cta.sticky.vertical.bottom.value"
                    }

                    /// Type: spacing
                    public static let horizontal = "bottomSheet.spacing.cta.sticky.horizontal.value"
                }
            }

            public enum title {
                public enum noIcon {
                    /// Type: spacing
                    public static let horizontal = "bottomSheet.spacing.title.noIcon.horizontal.value"
                }

                public enum withIcon {
                    public enum horizontal {
                        /// Type: spacing
                        public static let left = "bottomSheet.spacing.title.withIcon.horizontal.left.value"
                        /// Type: spacing
                        public static let right = "bottomSheet.spacing.title.withIcon.horizontal.right.value"
                    }
                }

                public enum vertical {
                    /// Type: spacing
                    public static let bottom = "bottomSheet.spacing.title.vertical.bottom.value"
                }
            }

            public enum content {
                /// Type: spacing
                public static let horizontal = "bottomSheet.spacing.content.horizontal.value"
                public enum vertical {
                    /// Type: spacing
                    public static let bottom = "bottomSheet.spacing.content.vertical.bottom.value"
                }

                public enum selection {
                    /// Type: spacing
                    public static let horizontal = "bottomSheet.spacing.content.selection.horizontal.value"
                }
            }
        }

        public enum gap {
            public enum title {
                public enum withIcon {
                    /// Type: spacing
                    public static let horizontal = "bottomSheet.gap.title.withIcon.horizontal.value"
                }
            }
        }

        public enum color {
            /// Type: color
            public static let container = "bottomSheet.color.container.value"
            /// Type: color
            public static let icon = "bottomSheet.color.icon.value"
            /// Type: color
            public static let font = "bottomSheet.color.font.value"
            /// Type: color
            public static let swipeBar = "bottomSheet.color.swipeBar.value"
        }

        public enum size {
            public enum swipeBar {
                /// Type: sizing
                public static let width = "bottomSheet.size.swipeBar.width.value"
                /// Type: sizing
                public static let height = "bottomSheet.size.swipeBar.height.value"
            }
        }

        public enum borderRadius {
            public enum container {
                /// Type: borderRadius
                public static let top = "bottomSheet.borderRadius.container.top.value"
                /// Type: borderRadius
                public static let bottom = "bottomSheet.borderRadius.container.bottom.value"
            }

            /// Type: borderRadius
            public static let swipeBar = "bottomSheet.borderRadius.swipeBar.value"
        }

        public enum font {
            /// Type: typography
            public static let content = "bottomSheet.font.content.value"
        }
    }

    public enum cards {
        public enum boxShadow {
            public enum content {
                /// Type: boxShadow
                public static let high = "cards.boxShadow.content.high.value"
                /// Type: boxShadow
                public static let low = "cards.boxShadow.content.low.value"
            }

            /// Type: boxShadow
            public static let base = "cards.boxShadow.base.value"
        }

        public enum color {
            public enum fill {
                /// Type: color
                public static let high = "cards.color.fill.high.value"
                /// Type: color
                public static let low = "cards.color.fill.low.value"
            }

            /// Type: color
            public static let icon = "cards.color.icon.value"
            public enum insightsCard {
                public enum text {
                    /// Type: color
                    public static let body = "cards.color.insightsCard.text.body.value"
                    /// Type: color
                    public static let title = "cards.color.insightsCard.text.title.value"
                    /// Type: color
                    public static let eyebrow = "cards.color.insightsCard.text.eyebrow.value"
                }
            }

            public enum actionCard {
                public enum text {
                    /// Type: color
                    public static let title = "cards.color.actionCard.text.title.value"
                    /// Type: color
                    public static let body = "cards.color.actionCard.text.body.value"
                }
            }

            public enum productCard {
                /// Type: color
                public static let body = "cards.color.productCard.body.value"
            }

            public enum selectionCard {
                public enum title {
                    /// Type: color
                    public static let defaultValue = "cards.color.selectionCard.title.default.value"
                    /// Type: color
                    public static let disabled = "cards.color.selectionCard.title.disabled.value"
                }

                public enum icon {
                    /// Type: color
                    public static let defaultValue = "cards.color.selectionCard.icon.default.value"
                    /// Type: color
                    public static let disabled = "cards.color.selectionCard.icon.disabled.value"
                }
            }
        }

        public enum font {
            public enum insightsCard {
                /// Type: typography
                public static let eyebrow = "cards.font.insightsCard.eyebrow.value"
                /// Type: typography
                public static let title = "cards.font.insightsCard.title.value"
                /// Type: typography
                public static let body = "cards.font.insightsCard.body.value"
            }

            public enum actionCard {
                /// Type: typography
                public static let title = "cards.font.actionCard.title.value"
                /// Type: typography
                public static let body = "cards.font.actionCard.body.value"
            }

            public enum productCard {
                /// Type: typography
                public static let body = "cards.font.productCard.body.value"
            }

            public enum tiles {
                /// Type: typography
                public static let title = "cards.font.tiles.title.value"
                /// Type: typography
                public static let body = "cards.font.tiles.body.value"
            }

            public enum selectionCard {
                /// Type: typography
                public static let title = "cards.font.selectionCard.title.value"
            }
        }

        public enum spacing {
            public enum insightCard {
                /// Type: spacing
                public static let vertical = "cards.spacing.insightCard.vertical.value"
                /// Type: spacing
                public static let horizontal = "cards.spacing.insightCard.horizontal.value"
                public enum gap {
                    /// Type: spacing
                    public static let vertical = "cards.spacing.insightCard.gap.vertical.value"
                    /// Type: spacing
                    public static let horizontal = "cards.spacing.insightCard.gap.horizontal.value"
                }

                public enum carousel {
                    /// Type: spacing
                    public static let vertical = "cards.spacing.insightCard.carousel.vertical.value"
                    /// Type: spacing
                    public static let horizontal = "cards.spacing.insightCard.carousel.horizontal.value"
                }
            }
        }

        public enum actionCard {
            public enum spacing {
                /// Type: spacing
                public static let vertical = "cards.actionCard.spacing.vertical.value"
                /// Type: spacing
                public static let horizontal = "cards.actionCard.spacing.horizontal.value"
            }

            public enum spacer {
                public enum content {
                    /// Type: spacing
                    public static let vertical = "cards.actionCard.spacer.content.vertical.value"
                }
            }

            public enum gap {
                /// Type: spacing
                public static let vertical = "cards.actionCard.gap.vertical.value"
                /// Type: spacing
                public static let horizontal = "cards.actionCard.gap.horizontal.value"
                public enum datapoint {
                    /// Type: spacing
                    public static let vertical = "cards.actionCard.gap.datapoint.vertical.value"
                }
            }
        }

        public enum productCard {
            public enum spacing {
                /// Type: spacing
                public static let vertical = "cards.productCard.spacing.vertical.value"
                /// Type: spacing
                public static let horizontal = "cards.productCard.spacing.horizontal.value"
            }

            public enum gap {
                /// Type: spacing
                public static let horizontal = "cards.productCard.gap.horizontal.value"
                /// Type: spacing
                public static let vertical = "cards.productCard.gap.vertical.value"
            }
        }

        public enum content {
            /// Type: borderRadius
            public static let borderRadius = "cards.content.borderRadius.value"
        }

        public enum base {
            public enum borderRadius {
                /// Type: borderRadius
                public static let top = "cards.base.borderRadius.top.value"
            }
        }

        public enum standard {
            /// Type: borderRadius
            public static let borderRadius = "cards.standard.borderRadius.value"
        }

        public enum tiles {
            public enum spacing {
                /// Type: spacing
                public static let vertical = "cards.tiles.spacing.vertical.value"
                /// Type: spacing
                public static let horizontal = "cards.tiles.spacing.horizontal.value"
            }

            public enum gap {
                /// Type: spacing
                public static let vertical = "cards.tiles.gap.vertical.value"
                /// Type: spacing
                public static let horizontal = "cards.tiles.gap.horizontal.value"
            }
        }

        public enum selectionCard {
            public enum spacing {
                /// Type: spacing
                public static let vertical = "cards.selectionCard.spacing.vertical.value"
                /// Type: spacing
                public static let horizontal = "cards.selectionCard.spacing.horizontal.value"
            }

            /// Type: spacing
            public static let gap = "cards.selectionCard.gap.value"
        }

        public enum modular {
            public enum spacing {
                /// Type: spacing
                public static let horizontal = "cards.modular.spacing.horizontal.value"
                /// Type: spacing
                public static let vertical = "cards.modular.spacing.vertical.value"
                public enum content {
                    public enum vertical {
                        /// Type: spacing
                        public static let top = "cards.modular.spacing.content.vertical.top.value"
                    }
                }

                public enum prefix {
                    public enum icon {
                        /// Type: spacing
                        public static let horizontal = "cards.modular.spacing.prefix.icon.horizontal.value"
                        /// Type: spacing
                        public static let vertical = "cards.modular.spacing.prefix.icon.vertical.value"
                    }

                    public enum card {
                        /// Type: spacing
                        public static let horizontal = "cards.modular.spacing.prefix.card.horizontal.value"
                        /// Type: spacing
                        public static let vertical = "cards.modular.spacing.prefix.card.vertical.value"
                    }
                }
            }

            public enum gap {
                /// Type: spacing
                public static let vertical = "cards.modular.gap.vertical.value"
                public enum content {
                    /// Type: spacing
                    public static let vertical = "cards.modular.gap.content.vertical.value"
                }

                public enum header {
                    /// Type: spacing
                    public static let horizontal = "cards.modular.gap.header.horizontal.value"
                    /// Type: spacing
                    public static let vertical = "cards.modular.gap.header.vertical.value"
                }

                public enum footer {
                    /// Type: spacing
                    public static let vertical = "cards.modular.gap.footer.vertical.value"
                }
            }
        }
    }

    public enum tiles {
        public enum standard {
            /// Type: borderRadius
            public static let borderRadius = "tiles.standard.borderRadius.value"
            public enum color {
                public enum container {
                    public enum static {
                        /// Type: color
                        public static let variant1 = "tiles.standard.color.container.static.variant1.value"
                        /// Type: color
                        public static let variant2 = "tiles.standard.color.container.static.variant2.value"
                    }
                }

                public enum text {
                    /// Type: color
                    public static let headline = "tiles.standard.color.text.headline.value"
                    /// Type: color
                    public static let body = "tiles.standard.color.text.body.value"
                    /// Type: color
                    public static let eyebrow = "tiles.standard.color.text.eyebrow.value"
                }

                /// Type: color
                public static let icon = "tiles.standard.color.icon.value"
            }

            public enum spacing {
                public enum content {
                    /// Type: spacing
                    public static let vertical = "tiles.standard.spacing.content.vertical.value"
                    public enum badge {
                        public enum vertical {
                            /// Type: spacing
                            public static let top = "tiles.standard.spacing.content.badge.vertical.top.value"
                        }

                        public enum horizontal {
                            /// Type: spacing
                            public static let right = "tiles.standard.spacing.content.badge.horizontal.right.value"
                        }
                    }

                    public enum horizontal {
                        /// Type: spacing
                        public static let left = "tiles.standard.spacing.content.horizontal.left.value"
                        /// Type: spacing
                        public static let right = "tiles.standard.spacing.content.horizontal.right.value"
                    }
                }

                public enum thumbnail {
                    /// Type: spacing
                    public static let vertical = "tiles.standard.spacing.thumbnail.vertical.value"
                    public enum horizontal {
                        /// Type: spacing
                        public static let left = "tiles.standard.spacing.thumbnail.horizontal.left.value"
                        /// Type: spacing
                        public static let right = "tiles.standard.spacing.thumbnail.horizontal.right.value"
                    }
                }
            }

            public enum gap {
                public enum content {
                    /// Type: spacing
                    public static let vertical = "tiles.standard.gap.content.vertical.value"
                    /// Type: spacing
                    public static let horizontal = "tiles.standard.gap.content.horizontal.value"
                }
            }

            public enum font {
                /// Type: typography
                public static let headline = "tiles.standard.font.headline.value"
                /// Type: typography
                public static let eyebrow = "tiles.standard.font.eyebrow.value"
                /// Type: typography
                public static let body = "tiles.standard.font.body.value"
                /// Type: typography
                public static let badge = "tiles.standard.font.badge.value"
            }

            public enum badge {
                public enum color {
                    /// Type: color
                    public static let text = "tiles.standard.badge.color.text.value"
                    /// Type: color
                    public static let container = "tiles.standard.badge.color.container.value"
                }
            }
        }

        public enum color {
            public enum container {
                /// Type: color
                public static let base = "tiles.color.container.base.value"
                /// Type: color
                public static let variant1 = "tiles.color.container.variant1.value"
                /// Type: color
                public static let variant2 = "tiles.color.container.variant2.value"
                /// Type: color
                public static let variant3 = "tiles.color.container.variant3.value"
                /// Type: color
                public static let variant4 = "tiles.color.container.variant4.value"
                /// Type: color
                public static let variant5 = "tiles.color.container.variant5.value"
                /// Type: color
                public static let variant6 = "tiles.color.container.variant6.value"
                /// Type: color
                public static let variant7 = "tiles.color.container.variant7.value"
            }
        }

        public enum badge {
            /// Type: borderRadius
            public static let borderRadius = "tiles.badge.borderRadius.value"
            public enum spacing {
                /// Type: spacing
                public static let vertical = "tiles.badge.spacing.vertical.value"
                /// Type: spacing
                public static let horizontal = "tiles.badge.spacing.horizontal.value"
            }

            public enum gap {
                /// Type: spacing
                public static let horizontal = "tiles.badge.gap.horizontal.value"
            }

            /// Type: boxShadow
            public static let boxShadow = "tiles.badge.boxShadow.value"
        }

        public enum feature {
            public enum font {
                /// Type: typography
                public static let eyebrow = "tiles.feature.font.eyebrow.value"
                /// Type: typography
                public static let header = "tiles.feature.font.header.value"
                /// Type: typography
                public static let body = "tiles.feature.font.body.value"
            }

            public enum color {
                public enum text {
                    /// Type: color
                    public static let eyebrow = "tiles.feature.color.text.eyebrow.value"
                    /// Type: color
                    public static let header = "tiles.feature.color.text.header.value"
                    /// Type: color
                    public static let body = "tiles.feature.color.text.body.value"
                }
            }

            /// Type: borderRadius
            public static let borderRadius = "tiles.feature.borderRadius.value"
            public enum spacing {
                public enum content {
                    /// Type: spacing
                    public static let vertical = "tiles.feature.spacing.content.vertical.value"
                    /// Type: spacing
                    public static let horizontal = "tiles.feature.spacing.content.horizontal.value"
                }
            }

            public enum gap {
                /// Type: spacing
                public static let labels = "tiles.feature.gap.labels.value"
                public enum content {
                    public enum vertical {
                        /// Type: spacing
                        public static let s = "tiles.feature.gap.content.vertical.s.value"
                        /// Type: spacing
                        public static let xs = "tiles.feature.gap.content.vertical.xs.value"
                    }
                }
            }

            /// Type: boxShadow
            public static let boxShadow = "tiles.feature.boxShadow.value"
        }

        public enum rewards {
            public enum color {
                /// Type: color
                public static let container = "tiles.rewards.color.container.value"
                public enum text {
                    public enum description {
                        /// Type: color
                        public static let defaultValue = "tiles.rewards.color.text.description.default.value"
                        /// Type: color
                        public static let disabled = "tiles.rewards.color.text.description.disabled.value"
                    }

                    public enum header {
                        /// Type: color
                        public static let defaultValue = "tiles.rewards.color.text.header.default.value"
                        /// Type: color
                        public static let disabled = "tiles.rewards.color.text.header.disabled.value"
                    }

                    public enum points {
                        /// Type: color
                        public static let strikethrough = "tiles.rewards.color.text.points.strikethrough.value"
                        /// Type: color
                        public static let defaultValue = "tiles.rewards.color.text.points.default.value"
                        /// Type: color
                        public static let disabled = "tiles.rewards.color.text.points.disabled.value"
                    }

                    /// Type: color
                    public static let eyebrow = "tiles.rewards.color.text.eyebrow.value"
                }
            }

            /// Type: boxShadow
            public static let boxShadow = "tiles.rewards.boxShadow.value"
            /// Type: borderRadius
            public static let borderRadius = "tiles.rewards.borderRadius.value"
            public enum small {
                public enum font {
                    /// Type: typography
                    public static let header = "tiles.rewards.small.font.header.value"
                    /// Type: typography
                    public static let description = "tiles.rewards.small.font.description.value"
                    public enum points {
                        /// Type: typography
                        public static let strikethrough = "tiles.rewards.small.font.points.strikethrough.value"
                        /// Type: typography
                        public static let defaultValue = "tiles.rewards.small.font.points.default.value"
                    }
                }
            }

            public enum spacing {
                public enum content {
                    /// Type: spacing
                    public static let vertical = "tiles.rewards.spacing.content.vertical.value"
                    /// Type: spacing
                    public static let horizontal = "tiles.rewards.spacing.content.horizontal.value"
                }

                /// Type: spacing
                public static let label = "tiles.rewards.spacing.label.value"
            }

            public enum gap {
                public enum content {
                    public enum vertical {
                        /// Type: spacing
                        public static let s = "tiles.rewards.gap.content.vertical.s.value"
                        /// Type: spacing
                        public static let xs = "tiles.rewards.gap.content.vertical.xs.value"
                    }
                }

                /// Type: spacing
                public static let row = "tiles.rewards.gap.row.value"
            }

            public enum large {
                public enum font {
                    /// Type: typography
                    public static let header = "tiles.rewards.large.font.header.value"
                    /// Type: typography
                    public static let description = "tiles.rewards.large.font.description.value"
                    /// Type: typography
                    public static let eyebrow = "tiles.rewards.large.font.eyebrow.value"
                }
            }
        }
    }

    public enum statustypes {
        public enum spacing {
            /// Type: spacing
            public static let gap = "statustypes.spacing.gap.value"
            /// Type: spacing
            public static let vertical = "statustypes.spacing.vertical.value"
            /// Type: spacing
            public static let iconTop = "statustypes.spacing.iconTop.value"
        }

        public enum color {
            public enum text {
                /// Type: color
                public static let error = "statustypes.color.text.error.value"
                /// Type: color
                public static let success = "statustypes.color.text.success.value"
            }

            public enum icon {
                /// Type: color
                public static let error = "statustypes.color.icon.error.value"
                /// Type: color
                public static let success = "statustypes.color.icon.success.value"
            }
        }

        public enum font {
            /// Type: typography
            public static let medium = "statustypes.font.medium.value"
            /// Type: typography
            public static let small = "statustypes.font.small.value"
        }
    }

    public enum rows {
        public enum font {
            /// Type: typography
            public static let header = "rows.font.header.value"
            public enum description {
                /// Type: typography
                public static let body = "rows.font.description.body.value"
                /// Type: typography
                public static let details = "rows.font.description.details.value"
                /// Type: typography
                public static let status = "rows.font.description.status.value"
            }
        }

        public enum gap {
            /// Type: spacing
            public static let vertical = "rows.gap.vertical.value"
        }

        public enum spacing {
            public enum content {
                /// Type: spacing
                public static let vertical = "rows.spacing.content.vertical.value"
                /// Type: spacing
                public static let horizontal = "rows.spacing.content.horizontal.value"
            }

            public enum icon {
                /// Type: spacing
                public static let vertical = "rows.spacing.icon.vertical.value"
                public enum horizontal {
                    /// Type: spacing
                    public static let left = "rows.spacing.icon.horizontal.left.value"
                    /// Type: spacing
                    public static let right = "rows.spacing.icon.horizontal.right.value"
                }
            }

            public enum card {
                /// Type: spacing
                public static let vertical = "rows.spacing.card.vertical.value"
                public enum horizontal {
                    /// Type: spacing
                    public static let left = "rows.spacing.card.horizontal.left.value"
                    /// Type: spacing
                    public static let right = "rows.spacing.card.horizontal.right.value"
                }
            }

            public enum container {
                public enum horizontal {
                    /// Type: spacing
                    public static let left = "rows.spacing.container.horizontal.left.value"
                }
            }
        }

        public enum color {
            public enum text {
                public enum header {
                    /// Type: color
                    public static let defaultValue = "rows.color.text.header.default.value"
                    /// Type: color
                    public static let disabled = "rows.color.text.header.disabled.value"
                }

                public enum description {
                    /// Type: color
                    public static let defaultValue = "rows.color.text.description.default.value"
                    /// Type: color
                    public static let disabled = "rows.color.text.description.disabled.value"
                }

                public enum details {
                    /// Type: color
                    public static let defaultValue = "rows.color.text.details.default.value"
                    /// Type: color
                    public static let disabled = "rows.color.text.details.disabled.value"
                }
            }

            public enum container {
                /// Type: color
                public static let pressed = "rows.color.container.pressed.value"
            }

            public enum icon {
                /// Type: color
                public static let defaultValue = "rows.color.icon.default.value"
                /// Type: color
                public static let disabled = "rows.color.icon.disabled.value"
            }
        }
    }

    public enum chips {
        public enum size {
            /// Type: sizing
            public static let l = "chips.size.l.value"
            /// Type: sizing
            public static let m = "chips.size.m.value"
            /// Type: sizing
            public static let xl = "chips.size.xl.value"
        }

        public enum standard {
            public enum spacing {
                /// Type: spacing
                public static let vertical = "chips.standard.spacing.vertical.value"
                /// Type: spacing
                public static let horizontal = "chips.standard.spacing.horizontal.value"
                /// Type: spacing
                public static let gap = "chips.standard.spacing.gap.value"
            }
        }

        public enum filter {
            public enum padding {
                /// Type: spacing
                public static let label = "chips.filter.padding.label.value"
            }

            public enum container {
                public enum off {
                    /// Type: color
                    public static let defaultValue = "chips.filter.container.off.default.value"
                    /// Type: color
                    public static let disabled = "chips.filter.container.off.disabled.value"
                }

                public enum on {
                    /// Type: color
                    public static let defaultValue = "chips.filter.container.on.default.value"
                    /// Type: color
                    public static let disabled = "chips.filter.container.on.disabled.value"
                }
            }

            public enum text {
                public enum off {
                    /// Type: color
                    public static let defaultValue = "chips.filter.text.off.default.value"
                    /// Type: color
                    public static let disabled = "chips.filter.text.off.disabled.value"
                }

                /// Type: color
                public static let on = "chips.filter.text.on.value"
            }

            public enum icon {
                public enum off {
                    /// Type: color
                    public static let defaultValue = "chips.filter.icon.off.default.value"
                    /// Type: color
                    public static let disabled = "chips.filter.icon.off.disabled.value"
                }

                /// Type: color
                public static let on = "chips.filter.icon.on.value"
            }
        }

        public enum input {
            public enum color {
                public enum container {
                    /// Type: color
                    public static let defaultValue = "chips.input.color.container.default.value"
                    /// Type: color
                    public static let focus = "chips.input.color.container.focus.value"
                    /// Type: color
                    public static let entry = "chips.input.color.container.entry.value"
                    /// Type: color
                    public static let defocused = "chips.input.color.container.defocused.value"
                }

                public enum text {
                    /// Type: color
                    public static let defaultValue = "chips.input.color.text.default.value"
                    /// Type: color
                    public static let counter = "chips.input.color.text.counter.value"
                }
            }

            public enum counter {
                /// Type: spacing
                public static let gap = "chips.input.counter.gap.value"
            }
        }

        public enum choice {
            public enum container {
                public enum off {
                    /// Type: color
                    public static let defaultValue = "chips.choice.container.off.default.value"
                    /// Type: color
                    public static let disabled = "chips.choice.container.off.disabled.value"
                }

                public enum on {
                    /// Type: color
                    public static let defaultValue = "chips.choice.container.on.default.value"
                    /// Type: color
                    public static let disabled = "chips.choice.container.on.disabled.value"
                }
            }

            public enum text {
                public enum off {
                    /// Type: color
                    public static let defaultValue = "chips.choice.text.off.default.value"
                    /// Type: color
                    public static let disabled = "chips.choice.text.off.disabled.value"
                }

                /// Type: color
                public static let on = "chips.choice.text.on.value"
            }

            public enum icon {
                public enum off {
                    /// Type: color
                    public static let defaultValue = "chips.choice.icon.off.default.value"
                    /// Type: color
                    public static let disabled = "chips.choice.icon.off.disabled.value"
                }

                /// Type: color
                public static let on = "chips.choice.icon.on.value"
            }
        }

        public enum font {
            /// Type: typography
            public static let counter = "chips.font.counter.value"
            public enum label {
                /// Type: typography
                public static let s = "chips.font.label.s.value"
                /// Type: typography
                public static let l = "chips.font.label.l.value"
            }
        }

        public enum container {
            public enum borderRadius {
                /// Type: borderRadius
                public static let s = "chips.container.borderRadius.s.value"
                /// Type: borderRadius
                public static let m = "chips.container.borderRadius.m.value"
                /// Type: borderRadius
                public static let l = "chips.container.borderRadius.l.value"
            }
        }
    }

    public enum labels {
        public enum font {
            /// Type: typography
            public static let primary = "labels.font.primary.value"
            /// Type: typography
            public static let secondary = "labels.font.secondary.value"
        }

        /// Type: borderRadius
        public static let borderRadius = "labels.borderRadius.value"
        public enum announcement {
            public enum color {
                public enum bg {
                    /// Type: color
                    public static let neutral = "labels.announcement.color.bg.neutral.value"
                    /// Type: color
                    public static let coloured = "labels.announcement.color.bg.coloured.value"
                }

                public enum text {
                    /// Type: color
                    public static let neutral = "labels.announcement.color.text.neutral.value"
                    /// Type: color
                    public static let coloured = "labels.announcement.color.text.coloured.value"
                }
            }
        }

        public enum status {
            public enum color {
                public enum bg {
                    /// Type: color
                    public static let info = "labels.status.color.bg.info.value"
                    /// Type: color
                    public static let alert = "labels.status.color.bg.alert.value"
                    /// Type: color
                    public static let negative = "labels.status.color.bg.negative.value"
                    /// Type: color
                    public static let positive = "labels.status.color.bg.positive.value"
                }

                /// Type: color
                public static let text = "labels.status.color.text.value"
                public enum icon {
                    /// Type: color
                    public static let info = "labels.status.color.icon.info.value"
                    /// Type: color
                    public static let alert = "labels.status.color.icon.alert.value"
                    /// Type: color
                    public static let negative = "labels.status.color.icon.negative.value"
                    /// Type: color
                    public static let positive = "labels.status.color.icon.positive.value"
                }
            }

            public enum font {
                /// Type: typography
                public static let primary = "labels.status.font.primary.value"
            }
        }

        public enum spacing {
            public enum announcement {
                public enum primary {
                    /// Type: spacing
                    public static let vertical = "labels.spacing.announcement.primary.vertical.value"
                    /// Type: spacing
                    public static let horizontal = "labels.spacing.announcement.primary.horizontal.value"
                }

                public enum secondary {
                    /// Type: spacing
                    public static let vertical = "labels.spacing.announcement.secondary.vertical.value"
                    /// Type: spacing
                    public static let horizontal = "labels.spacing.announcement.secondary.horizontal.value"
                }
            }

            public enum status {
                /// Type: spacing
                public static let vertical = "labels.spacing.status.vertical.value"
                /// Type: spacing
                public static let horizontal = "labels.spacing.status.horizontal.value"
            }

            /// Type: spacing
            public static let gap = "labels.spacing.gap.value"
            public enum standard {
                /// Type: spacing
                public static let vertical = "labels.spacing.standard.vertical.value"
                /// Type: spacing
                public static let horizontal = "labels.spacing.standard.horizontal.value"
            }
        }

        public enum standard {
            /// Type: borderRadius
            public static let borderRadius = "labels.standard.borderRadius.value"
            public enum color {
                public enum bg {
                    /// Type: color
                    public static let neutral = "labels.standard.color.bg.neutral.value"
                    /// Type: color
                    public static let coloured = "labels.standard.color.bg.coloured.value"
                    /// Type: color
                    public static let white = "labels.standard.color.bg.white.value"
                }

                public enum text {
                    /// Type: color
                    public static let onLight = "labels.standard.color.text.onLight.value"
                }
            }

            public enum font {
                /// Type: typography
                public static let primary = "labels.standard.font.primary.value"
                /// Type: typography
                public static let secondary = "labels.standard.font.secondary.value"
            }
        }
    }

    public enum accordion {
        public enum font {
            public enum standard {
                /// Type: typography
                public static let label = "accordion.font.standard.label.value"
                /// Type: typography
                public static let description = "accordion.font.standard.description.value"
            }

            /// Type: typography
            public static let content = "accordion.font.content.value"
            public enum inCard {
                /// Type: typography
                public static let label = "accordion.font.inCard.label.value"
            }
        }

        public enum color {
            public enum container {
                /// Type: color
                public static let defaultValue = "accordion.color.container.default.value"
                /// Type: color
                public static let pressed = "accordion.color.container.pressed.value"
            }

            public enum text {
                public enum label {
                    /// Type: color
                    public static let defaultValue = "accordion.color.text.label.default.value"
                    /// Type: color
                    public static let disabled = "accordion.color.text.label.disabled.value"
                }

                public enum description {
                    /// Type: color
                    public static let defaultValue = "accordion.color.text.description.default.value"
                    /// Type: color
                    public static let disabled = "accordion.color.text.description.disabled.value"
                }
            }

            public enum chevron {
                /// Type: color
                public static let defaultValue = "accordion.color.chevron.default.value"
                /// Type: color
                public static let disabled = "accordion.color.chevron.disabled.value"
            }

            /// Type: color
            public static let content = "accordion.color.content.value"
            /// Type: color
            public static let bg = "accordion.color.bg.value"
            public enum inCard {
                public enum text {
                    public enum label {
                        /// Type: color
                        public static let defaultValue = "accordion.color.inCard.text.label.default.value"
                        /// Type: color
                        public static let disabled = "accordion.color.inCard.text.label.disabled.value"
                    }

                    public enum description {
                        /// Type: color
                        public static let defaultValue = "accordion.color.inCard.text.description.default.value"
                        /// Type: color
                        public static let disabled = "accordion.color.inCard.text.description.disabled.value"
                    }
                }

                public enum chevron {
                    /// Type: color
                    public static let defaultValue = "accordion.color.inCard.chevron.default.value"
                    /// Type: color
                    public static let disabled = "accordion.color.inCard.chevron.disabled.value"
                }
            }
        }

        public enum gap {
            /// Type: spacing
            public static let rows = "accordion.gap.rows.value"
            /// Type: spacing
            public static let chevron = "accordion.gap.chevron.value"
            public enum inCard {
                /// Type: spacing
                public static let rows = "accordion.gap.inCard.rows.value"
            }
        }

        public enum borderRadius {
            /// Type: borderRadius
            public static let inCard = "accordion.borderRadius.inCard.value"
        }

        public enum spacing {
            public enum fullWidth {
                /// Type: spacing
                public static let horizontal = "accordion.spacing.fullWidth.horizontal.value"
            }

            public enum collapsed {
                /// Type: spacing
                public static let vertical = "accordion.spacing.collapsed.vertical.value"
            }

            public enum inCard {
                /// Type: spacing
                public static let horizontal = "accordion.spacing.inCard.horizontal.value"
            }

            public enum expanded {
                /// Type: spacing
                public static let vertical = "accordion.spacing.expanded.vertical.value"
                /// Type: spacing
                public static let bottom = "accordion.spacing.expanded.bottom.value"
            }
        }

        public enum inCard {
            /// Type: boxShadow
            public static let boxShadow = "accordion.inCard.boxShadow.value"
        }
    }

    public enum emptyStates {
        public enum font {
            public enum medium {
                /// Type: typography
                public static let title = "emptyStates.font.medium.title.value"
                /// Type: typography
                public static let description = "emptyStates.font.medium.description.value"
            }

            public enum small {
                /// Type: typography
                public static let title = "emptyStates.font.small.title.value"
                /// Type: typography
                public static let description = "emptyStates.font.small.description.value"
            }
        }

        public enum color {
            public enum medium {
                public enum text {
                    /// Type: color
                    public static let title = "emptyStates.color.medium.text.title.value"
                    /// Type: color
                    public static let description = "emptyStates.color.medium.text.description.value"
                }
            }

            public enum small {
                public enum text {
                    /// Type: color
                    public static let title = "emptyStates.color.small.text.title.value"
                    /// Type: color
                    public static let description = "emptyStates.color.small.text.description.value"
                }
            }
        }

        public enum spacing {
            public enum medium {
                /// Type: spacing
                public static let horizontal = "emptyStates.spacing.medium.horizontal.value"
                /// Type: spacing
                public static let vertical = "emptyStates.spacing.medium.vertical.value"
            }

            public enum large {
                /// Type: spacing
                public static let vertical = "emptyStates.spacing.large.vertical.value"
                /// Type: spacing
                public static let horizontal = "emptyStates.spacing.large.horizontal.value"
            }

            public enum small {
                /// Type: spacing
                public static let vertical = "emptyStates.spacing.small.vertical.value"
                /// Type: spacing
                public static let horizontal = "emptyStates.spacing.small.horizontal.value"
            }
        }

        public enum gap {
            public enum container {
                public enum medium {
                    /// Type: spacing
                    public static let vertical = "emptyStates.gap.container.medium.vertical.value"
                }

                public enum small {
                    /// Type: spacing
                    public static let vertical = "emptyStates.gap.container.small.vertical.value"
                }
            }

            public enum content {
                public enum medium {
                    /// Type: spacing
                    public static let vertical = "emptyStates.gap.content.medium.vertical.value"
                }

                public enum small {
                    /// Type: spacing
                    public static let vertical = "emptyStates.gap.content.small.vertical.value"
                }
            }
        }
    }

    public enum transactionListing {
        public enum color {
            public enum text {
                /// Type: color
                public static let status = "transactionListing.color.text.status.value"
                /// Type: color
                public static let priBody = "transactionListing.color.text.priBody.value"
                /// Type: color
                public static let secBody = "transactionListing.color.text.secBody.value"
                /// Type: color
                public static let amountIncoming = "transactionListing.color.text.amountIncoming.value"
                /// Type: color
                public static let amountOutgoing = "transactionListing.color.text.amountOutgoing.value"
                /// Type: color
                public static let foregnCurrency = "transactionListing.color.text.foregnCurrency.value"
            }

            public enum container {
                /// Type: color
                public static let pressed = "transactionListing.color.container.pressed.value"
            }
        }

        public enum font {
            /// Type: typography
            public static let status = "transactionListing.font.status.value"
            /// Type: typography
            public static let priBody = "transactionListing.font.priBody.value"
            /// Type: typography
            public static let secBody = "transactionListing.font.secBody.value"
            /// Type: typography
            public static let amountIncoming = "transactionListing.font.amountIncoming.value"
            /// Type: typography
            public static let amountOutgoing = "transactionListing.font.amountOutgoing.value"
            /// Type: typography
            public static let foreignCurrency = "transactionListing.font.foreignCurrency.value"
        }

        public enum spacing {
            public enum content {
                /// Type: spacing
                public static let horizontal = "transactionListing.spacing.content.horizontal.value"
                /// Type: spacing
                public static let vertical = "transactionListing.spacing.content.vertical.value"
            }

            public enum icon {
                public enum horizontal {
                    /// Type: spacing
                    public static let left = "transactionListing.spacing.icon.horizontal.left.value"
                    /// Type: spacing
                    public static let right = "transactionListing.spacing.icon.horizontal.right.value"
                }

                /// Type: spacing
                public static let vertical = "transactionListing.spacing.icon.vertical.value"
            }

            public enum card {
                public enum horizontal {
                    /// Type: spacing
                    public static let left = "transactionListing.spacing.card.horizontal.left.value"
                    /// Type: spacing
                    public static let right = "transactionListing.spacing.card.horizontal.right.value"
                }

                /// Type: spacing
                public static let vertical = "transactionListing.spacing.card.vertical.value"
            }
        }

        public enum gap {
            /// Type: spacing
            public static let status = "transactionListing.gap.status.value"
            /// Type: spacing
            public static let body = "transactionListing.gap.body.value"
            /// Type: spacing
            public static let amount = "transactionListing.gap.amount.value"
            /// Type: spacing
            public static let fx = "transactionListing.gap.fx.value"
        }
    }

    public enum acknowledgement {
        public enum spacing {
            public enum content {
                /// Type: spacing
                public static let horizontal = "acknowledgement.spacing.content.horizontal.value"
            }

            public enum cta {
                /// Type: spacing
                public static let horizontal = "acknowledgement.spacing.cta.horizontal.value"
                public enum vertical {
                    /// Type: spacing
                    public static let top = "acknowledgement.spacing.cta.vertical.top.value"
                    /// Type: spacing
                    public static let bottom = "acknowledgement.spacing.cta.vertical.bottom.value"
                }
            }

            public enum footnote {
                /// Type: spacing
                public static let vertical = "acknowledgement.spacing.footnote.vertical.value"
            }
        }

        public enum gap {
            public enum content {
                /// Type: spacing
                public static let vertical = "acknowledgement.gap.content.vertical.value"
            }

            public enum header {
                /// Type: spacing
                public static let vertical = "acknowledgement.gap.header.vertical.value"
            }

            public enum info {
                /// Type: spacing
                public static let vertical = "acknowledgement.gap.info.vertical.value"
            }
        }

        public enum font {
            /// Type: typography
            public static let content = "acknowledgement.font.content.value"
            /// Type: typography
            public static let link = "acknowledgement.font.link.value"
            /// Type: typography
            public static let footnote = "acknowledgement.font.footnote.value"
        }

        public enum color {
            public enum text {
                /// Type: color
                public static let body = "acknowledgement.color.text.body.value"
                /// Type: color
                public static let link = "acknowledgement.color.text.link.value"
                /// Type: color
                public static let footnote = "acknowledgement.color.text.footnote.value"
            }
        }
    }

    public enum otp {
        public enum color {
            public enum bg {
                /// Type: color
                public static let empty = "otp.color.bg.empty.value"
                /// Type: color
                public static let activated = "otp.color.bg.activated.value"
                /// Type: color
                public static let error = "otp.color.bg.error.value"
                /// Type: color
                public static let filled = "otp.color.bg.filled.value"
                /// Type: color
                public static let input = "otp.color.bg.input.value"
            }

            public enum text {
                /// Type: color
                public static let input = "otp.color.text.input.value"
                /// Type: color
                public static let caption = "otp.color.text.caption.value"
            }
        }

        public enum font {
            /// Type: typography
            public static let caption = "otp.font.caption.value"
            /// Type: typography
            public static let input = "otp.font.input.value"
        }

        public enum gap {
            public enum input {
                /// Type: spacing
                public static let vertical = "otp.gap.input.vertical.value"
            }

            /// Type: spacing
            public static let horizontal = "otp.gap.horizontal.value"
            /// Type: spacing
            public static let vertical = "otp.gap.vertical.value"
        }

        public enum xs {
            public enum gap {
                /// Type: spacing
                public static let horizontal = "otp.xs.gap.horizontal.value"
                public enum section {
                    /// Type: spacing
                    public static let horizontal = "otp.xs.gap.section.horizontal.value"
                }
            }
        }
    }

    public enum calendar {
        public enum drumroll {
            public enum iOS {
                public enum spacing {
                    /// Type: spacing
                    public static let vertical = "calendar.drumroll.iOS.spacing.vertical.value"
                }
            }

            public enum android {
                public enum spacing {
                    /// Type: spacing
                    public static let vertical = "calendar.drumroll.android.spacing.vertical.value"
                }
            }
        }

        public enum picker {
            public enum font {
                /// Type: typography
                public static let monthyear = "calendar.picker.font.monthyear.value"
                /// Type: typography
                public static let days = "calendar.picker.font.days.value"
                public enum date {
                    /// Type: typography
                    public static let defaultValue = "calendar.picker.font.date.default.value"
                    /// Type: typography
                    public static let selected = "calendar.picker.font.date.selected.value"
                }
            }

            public enum color {
                public enum text {
                    /// Type: color
                    public static let monthyear = "calendar.picker.color.text.monthyear.value"
                    /// Type: color
                    public static let days = "calendar.picker.color.text.days.value"
                    public enum date {
                        /// Type: color
                        public static let defaultValue = "calendar.picker.color.text.date.default.value"
                        /// Type: color
                        public static let disabled = "calendar.picker.color.text.date.disabled.value"
                        /// Type: color
                        public static let today = "calendar.picker.color.text.date.today.value"
                        /// Type: color
                        public static let selection = "calendar.picker.color.text.date.selection.value"
                    }
                }

                public enum container {
                    /// Type: color
                    public static let selected = "calendar.picker.color.container.selected.value"
                    /// Type: color
                    public static let range = "calendar.picker.color.container.range.value"
                }

                public enum icon {
                    public enum chevron {
                        /// Type: color
                        public static let active = "calendar.picker.color.icon.chevron.active.value"
                        /// Type: color
                        public static let inactive = "calendar.picker.color.icon.chevron.inactive.value"
                    }
                }

                /// Type: color
                public static let bg = "calendar.picker.color.bg.value"
            }
        }
    }

    public enum errorHandling {
        public enum toast {
            public enum spacing {
                public enum horizontal {
                    /// Type: spacing
                    public static let bottom = "errorHandling.toast.spacing.horizontal.bottom.value"
                }
            }
        }

        public enum color {
            /// Type: color
            public static let text = "errorHandling.color.text.value"
            /// Type: color
            public static let icon = "errorHandling.color.icon.value"
        }
    }

    public enum progressIndicator {
        public enum color {
            /// Type: color
            public static let track = "progressIndicator.color.track.value"
            /// Type: color
            public static let indicator = "progressIndicator.color.indicator.value"
        }
    }

    public enum cvp {
        public enum color {
            public enum text {
                /// Type: color
                public static let description = "cvp.color.text.description.value"
            }
        }

        public enum font {
            /// Type: typography
            public static let description = "cvp.font.description.value"
        }

        public enum spacing {
            public enum visual {
                /// Type: spacing
                public static let vertical = "cvp.spacing.visual.vertical.value"
            }

            public enum content {
                /// Type: spacing
                public static let horizontal = "cvp.spacing.content.horizontal.value"
                /// Type: spacing
                public static let vertical = "cvp.spacing.content.vertical.value"
            }

            public enum button {
                /// Type: spacing
                public static let horizontal = "cvp.spacing.button.horizontal.value"
                public enum vertical {
                    /// Type: spacing
                    public static let top = "cvp.spacing.button.vertical.top.value"
                    /// Type: spacing
                    public static let btm = "cvp.spacing.button.vertical.btm.value"
                }
            }
        }

        public enum gap {
            /// Type: spacing
            public static let content = "cvp.gap.content.value"
        }
    }

    public enum authentication {
        public enum spacing {
            /// Type: spacing
            public static let horizontal = "authentication.spacing.horizontal.value"
            /// Type: spacing
            public static let vertical = "authentication.spacing.vertical.value"
        }

        public enum gap {
            public enum graphic {
                /// Type: spacing
                public static let vertical = "authentication.gap.graphic.vertical.value"
            }

            public enum header {
                /// Type: spacing
                public static let vertical = "authentication.gap.header.vertical.value"
            }

            public enum content {
                /// Type: spacing
                public static let vertical = "authentication.gap.content.vertical.value"
            }
        }

        public enum color {
            public enum text {
                /// Type: color
                public static let title = "authentication.color.text.title.value"
                /// Type: color
                public static let description = "authentication.color.text.description.value"
                /// Type: color
                public static let timer = "authentication.color.text.timer.value"
            }

            public enum bg {
                /// Type: color
                public static let loader = "authentication.color.bg.loader.value"
            }
        }

        public enum font {
            /// Type: typography
            public static let title = "authentication.font.title.value"
            /// Type: typography
            public static let description = "authentication.font.description.value"
            /// Type: typography
            public static let timer = "authentication.font.timer.value"
        }
    }

    public enum tabswitch {
        public enum spacing {
            /// Type: spacing
            public static let vertical = "tabswitch.spacing.vertical.value"
            /// Type: spacing
            public static let horizontal = "tabswitch.spacing.horizontal.value"
        }

        public enum color {
            public enum bg {
                /// Type: color
                public static let on = "tabswitch.color.bg.on.value"
            }

            public enum label {
                /// Type: color
                public static let on = "tabswitch.color.label.on.value"
                /// Type: color
                public static let off = "tabswitch.color.label.off.value"
            }
        }

        /// Type: borderRadius
        public static let borderRadius = "tabswitch.borderRadius.value"
        public enum font {
            /// Type: typography
            public static let label = "tabswitch.font.label.value"
        }
    }

    public enum stepper {
        public enum color {
            public enum circle {
                /// Type: color
                public static let active = "stepper.color.circle.active.value"
                /// Type: color
                public static let inactive = "stepper.color.circle.inactive.value"
                /// Type: color
                public static let success = "stepper.color.circle.success.value"
                /// Type: color
                public static let failed = "stepper.color.circle.failed.value"
            }

            /// Type: color
            public static let icon = "stepper.color.icon.value"
            /// Type: color
            public static let connector = "stepper.color.connector.value"
            public enum text {
                /// Type: color
                public static let number = "stepper.color.text.number.value"
                /// Type: color
                public static let description = "stepper.color.text.description.value"
                /// Type: color
                public static let title = "stepper.color.text.title.value"
            }

            /// Type: color
            public static let progress = "stepper.color.progress.value"
        }

        public enum font {
            /// Type: typography
            public static let number = "stepper.font.number.value"
            /// Type: typography
            public static let description = "stepper.font.description.value"
            /// Type: typography
            public static let title = "stepper.font.title.value"
        }

        public enum spacing {
            public enum text {
                /// Type: spacing
                public static let horizontal = "stepper.spacing.text.horizontal.value"
                /// Type: spacing
                public static let vertical = "stepper.spacing.text.vertical.value"
            }

            public enum badge {
                /// Type: spacing
                public static let vertical = "stepper.spacing.badge.vertical.value"
            }
        }

        public enum gap {
            /// Type: spacing
            public static let connector = "stepper.gap.connector.value"
            /// Type: spacing
            public static let description = "stepper.gap.description.value"
        }

        public enum connector {
            /// Type: sizing
            public static let top = "stepper.connector.top.value"
        }
    }

    public enum pagination {
        public enum gap {
            /// Type: spacing
            public static let page = "pagination.gap.page.value"
        }

        public enum color {
            /// Type: color
            public static let active = "pagination.color.active.value"
            /// Type: color
            public static let inactive = "pagination.color.inactive.value"
        }
    }

    public enum highlights {
        public enum spacing {
            public enum row {
                /// Type: spacing
                public static let gap = "highlights.spacing.row.gap.value"
            }

            public enum padding {
                /// Type: spacing
                public static let vertical = "highlights.spacing.padding.vertical.value"
                /// Type: spacing
                public static let horizontal = "highlights.spacing.padding.horizontal.value"
            }

            public enum content {
                /// Type: spacing
                public static let gap = "highlights.spacing.content.gap.value"
            }
        }
    }

    public enum notifications {
        public enum spacing {
            public enum content {
                /// Type: spacing
                public static let horizontal = "notifications.spacing.content.horizontal.value"
                /// Type: spacing
                public static let vertical = "notifications.spacing.content.vertical.value"
            }

            public enum icons {
                public enum horizontal {
                    /// Type: spacing
                    public static let left = "notifications.spacing.icons.horizontal.left.value"
                    /// Type: spacing
                    public static let right = "notifications.spacing.icons.horizontal.right.value"
                }

                /// Type: spacing
                public static let vertical = "notifications.spacing.icons.vertical.value"
            }
        }

        public enum gap {
            /// Type: spacing
            public static let vertical = "notifications.gap.vertical.value"
            public enum horizontal {
                /// Type: spacing
                public static let badge = "notifications.gap.horizontal.badge.value"
                /// Type: spacing
                public static let timestamp = "notifications.gap.horizontal.timestamp.value"
                /// Type: spacing
                public static let icons = "notifications.gap.horizontal.icons.value"
            }
        }

        public enum font {
            /// Type: typography
            public static let title = "notifications.font.title.value"
            /// Type: typography
            public static let description = "notifications.font.description.value"
            /// Type: typography
            public static let timestamp = "notifications.font.timestamp.value"
        }

        public enum color {
            public enum container {
                /// Type: color
                public static let selected = "notifications.color.container.selected.value"
            }

            public enum text {
                public enum title {
                    /// Type: color
                    public static let read = "notifications.color.text.title.read.value"
                    /// Type: color
                    public static let unread = "notifications.color.text.title.unread.value"
                }

                public enum description {
                    /// Type: color
                    public static let defaultValue = "notifications.color.text.description.default.value"
                }

                public enum timestamp {
                    /// Type: color
                    public static let defaultValue = "notifications.color.text.timestamp.default.value"
                }
            }

            public enum badge {
                /// Type: color
                public static let unread = "notifications.color.badge.unread.value"
            }
        }
    }

    public enum swipeToDelete {
        public enum spacing {
            /// Type: spacing
            public static let horizontal = "swipeToDelete.spacing.horizontal.value"
            /// Type: spacing
            public static let vertical = "swipeToDelete.spacing.vertical.value"
        }

        public enum color {
            public enum container {
                /// Type: color
                public static let defaultValue = "swipeToDelete.color.container.default.value"
            }

            public enum icon {
                /// Type: color
                public static let defaultValue = "swipeToDelete.color.icon.default.value"
            }
        }
    }

    public enum banner {
        public enum utility {
            public enum color {
                public enum container {
                    /// Type: color
                    public static let alert = "banner.utility.color.container.alert.value"
                    /// Type: color
                    public static let reminder = "banner.utility.color.container.reminder.value"
                    /// Type: color
                    public static let promotional = "banner.utility.color.container.promotional.value"
                    /// Type: color
                    public static let informational = "banner.utility.color.container.informational.value"
                }

                /// Type: color
                public static let text = "banner.utility.color.text.value"
            }

            public enum font {
                /// Type: typography
                public static let header = "banner.utility.font.header.value"
                /// Type: typography
                public static let body = "banner.utility.font.body.value"
            }

            /// Type: borderRadius
            public static let borderRadius = "banner.utility.borderRadius.value"
            public enum spacing {
                /// Type: spacing
                public static let gap = "banner.utility.spacing.gap.value"
                /// Type: spacing
                public static let vertical = "banner.utility.spacing.vertical.value"
                /// Type: spacing
                public static let horizontal = "banner.utility.spacing.horizontal.value"
            }
        }
    }

    public enum titlerows {
        public enum spacing {
            /// Type: spacing
            public static let horizontal = "titlerows.spacing.horizontal.value"
            /// Type: spacing
            public static let vertical = "titlerows.spacing.vertical.value"
        }

        public enum gap {
            /// Type: spacing
            public static let horizontal = "titlerows.gap.horizontal.value"
        }

        public enum borderRadius {
            /// Type: borderRadius
            public static let standard = "titlerows.borderRadius.standard.value"
            /// Type: borderRadius
            public static let incard = "titlerows.borderRadius.incard.value"
        }

        public enum color {
            /// Type: color
            public static let container = "titlerows.color.container.value"
            public enum text {
                /// Type: color
                public static let title = "titlerows.color.text.title.value"
                /// Type: color
                public static let description = "titlerows.color.text.description.value"
            }
        }

        public enum font {
            public enum title {
                /// Type: typography
                public static let large = "titlerows.font.title.large.value"
                /// Type: typography
                public static let small = "titlerows.font.title.small.value"
            }

            public enum description {
                /// Type: typography
                public static let large = "titlerows.font.description.large.value"
                /// Type: typography
                public static let small = "titlerows.font.description.small.value"
            }
        }
    }

    public enum productpalette {
        public enum color {
            public enum text {
                /// Type: color
                public static let defaultValue = "productpalette.color.text.default.value"
                /// Type: color
                public static let disabled = "productpalette.color.text.disabled.value"
            }
        }

        public enum spacing {
            /// Type: spacing
            public static let gap = "productpalette.spacing.gap.value"
            /// Type: spacing
            public static let vertical = "productpalette.spacing.vertical.value"
            /// Type: spacing
            public static let horizontal = "productpalette.spacing.horizontal.value"
            /// Type: spacing
            public static let padding = "productpalette.spacing.padding.value"
        }

        public enum font {
            /// Type: typography
            public static let label = "productpalette.font.label.value"
        }
    }

    public enum slider {
        public enum handle {
            /// Type: borderRadius
            public static let borderRadius = "slider.handle.borderRadius.value"
        }

        public enum color {
            public enum handle {
                /// Type: color
                public static let defaultValue = "slider.color.handle.default.value"
                /// Type: color
                public static let selected = "slider.color.handle.selected.value"
                /// Type: color
                public static let shadow = "slider.color.handle.shadow.value"
                /// Type: color
                public static let border = "slider.color.handle.border.value"
            }

            public enum track {
                /// Type: color
                public static let active = "slider.color.track.active.value"
                /// Type: color
                public static let inactive = "slider.color.track.inactive.value"
            }

            public enum text {
                public enum legend {
                    /// Type: color
                    public static let value = "slider.color.text.legend.value.value"
                    /// Type: color
                    public static let unit = "slider.color.text.legend.unit.value"
                }

                public enum input {
                    public enum secondary {
                        /// Type: color
                        public static let prefix = "slider.color.text.input.secondary.prefix.value"
                        /// Type: color
                        public static let value = "slider.color.text.input.secondary.value.value"
                    }
                }
            }
        }

        public enum font {
            public enum input {
                public enum secondary {
                    /// Type: typography
                    public static let prefix = "slider.font.input.secondary.prefix.value"
                    /// Type: typography
                    public static let value = "slider.font.input.secondary.value.value"
                }
            }

            public enum legend {
                /// Type: typography
                public static let value = "slider.font.legend.value.value"
                /// Type: typography
                public static let unit = "slider.font.legend.unit.value"
            }
        }

        public enum gap {
            /// Type: spacing
            public static let vertical = "slider.gap.vertical.value"
            public enum secondary {
                /// Type: spacing
                public static let horizontal = "slider.gap.secondary.horizontal.value"
            }

            public enum legend {
                /// Type: spacing
                public static let vertical = "slider.gap.legend.vertical.value"
            }
        }

        public enum spacing {
            public enum vertical {
                /// Type: spacing
                public static let top = "slider.spacing.vertical.top.value"
                /// Type: spacing
                public static let bottom = "slider.spacing.vertical.bottom.value"
            }

            public enum horizontal {
                /// Type: spacing
                public static let left = "slider.spacing.horizontal.left.value"
                /// Type: spacing
                public static let right = "slider.spacing.horizontal.right.value"
            }
        }
    }

    public enum core {
        /// Type: color
        public static let ashblue75 = "core.ashblue75.value"
        /// Type: color
        public static let ashblue100 = "core.ashblue100.value"
        /// Type: color
        public static let ashblue200 = "core.ashblue200.value"
        /// Type: color
        public static let ocbcred = "core.ocbcred.value"
        /// Type: color
        public static let royalblue100 = "core.royalblue100.value"
        /// Type: color
        public static let royalblue200 = "core.royalblue200.value"
        /// Type: color
        public static let cornflowerblue100 = "core.cornflowerblue100.value"
        /// Type: color
        public static let sands100 = "core.sands100.value"
        /// Type: color
        public static let sands200 = "core.sands200.value"
        /// Type: color
        public static let cloudygrey200 = "core.cloudygrey200.value"
        /// Type: color
        public static let cloudygrey100 = "core.cloudygrey100.value"
        /// Type: color
        public static let warm100 = "core.warm100.value"
        /// Type: color
        public static let warm00 = "core.warm00.value"
    }

    public enum neutrals {
        /// Type: color
        public static let white = "neutrals.white.value"
        /// Type: color
        public static let neutral100 = "neutrals.neutral100.value"
        /// Type: color
        public static let neutral200 = "neutrals.neutral200.value"
        /// Type: color
        public static let neutral300 = "neutrals.neutral300.value"
        /// Type: color
        public static let neutral400 = "neutrals.neutral400.value"
        /// Type: color
        public static let neutral500 = "neutrals.neutral500.value"
        /// Type: color
        public static let neutral600 = "neutrals.neutral600.value"
        /// Type: color
        public static let neutral700 = "neutrals.neutral700.value"
        /// Type: color
        public static let neutral800 = "neutrals.neutral800.value"
    }

    public enum semantic {
        /// Type: color
        public static let alert100 = "semantic.alert100.value"
        /// Type: color
        public static let alertVariant100 = "semantic.alertVariant100.value"
        /// Type: color
        public static let success100 = "semantic.success100.value"
        /// Type: color
        public static let successVariant100 = "semantic.successVariant100.value"
        /// Type: color
        public static let error100 = "semantic.error100.value"
        /// Type: color
        public static let errorVariant100 = "semantic.errorVariant100.value"
    }

    public enum gradients {
        /// Type: color
        public static let neutralWarm = "gradients.neutralWarm.value"
        /// Type: color
        public static let neutralCool = "gradients.neutralCool.value"
        /// Type: color
        public static let ashClear = "gradients.ashClear.value"
        /// Type: color
        public static let ashCool = "gradients.ashCool.value"
        /// Type: color
        public static let ashWarm = "gradients.ashWarm.value"
        /// Type: color
        public static let ashGrey = "gradients.ashGrey.value"
        /// Type: color
        public static let whiteClear = "gradients.whiteClear.value"
        /// Type: color
        public static let blush = "gradients.blush.value"
        /// Type: color
        public static let ombre = "gradients.ombre.value"
        /// Type: color
        public static let dawn = "gradients.dawn.value"
        /// Type: color
        public static let dusk = "gradients.dusk.value"
        /// Type: color
        public static let sandstorm = "gradients.sandstorm.value"
        /// Type: color
        public static let desert = "gradients.desert.value"
        /// Type: color
        public static let milk = "gradients.milk.value"
        /// Type: color
        public static let alert = "gradients.alert.value"
        /// Type: color
        public static let reminder = "gradients.reminder.value"
        /// Type: color
        public static let promotional = "gradients.promotional.value"
    }

    public enum opensans {
        /// Type: typography
        public static let h3Bold = "opensans.h3-bold.value"
        /// Type: typography
        public static let h3Regular = "opensans.h3-regular.value"
        /// Type: typography
        public static let h4Bold = "opensans.h4-bold.value"
        /// Type: typography
        public static let h4Semibold = "opensans.h4-semibold.value"
        /// Type: typography
        public static let h4Regular = "opensans.h4-regular.value"
        /// Type: typography
        public static let h5Bold = "opensans.h5-bold.value"
        /// Type: typography
        public static let h5Semibold = "opensans.h5-semibold.value"
        /// Type: typography
        public static let h5Regular = "opensans.h5-regular.value"
        /// Type: typography
        public static let h1Bold = "opensans.h1-bold.value"
        /// Type: typography
        public static let h1Semibold = "opensans.h1-semibold.value"
        /// Type: typography
        public static let h1Regular = "opensans.h1-regular.value"
        /// Type: typography
        public static let h2Bold = "opensans.h2-bold.value"
        /// Type: typography
        public static let h2Semibold = "opensans.h2-semibold.value"
        /// Type: typography
        public static let h2Regular = "opensans.h2-regular.value"
        /// Type: typography
        public static let h3Semibold = "opensans.h3-semibold.value"
        /// Type: typography
        public static let h6Regular = "opensans.h6-regular.value"
        /// Type: typography
        public static let h6Semibold = "opensans.h6-semibold.value"
        /// Type: typography
        public static let h6Bold = "opensans.h6-bold.value"
        /// Type: typography
        public static let h7Regular = "opensans.h7-regular.value"
        /// Type: typography
        public static let h7Semibold = "opensans.h7-semibold.value"
        /// Type: typography
        public static let h7Bold = "opensans.h7-bold.value"
        /// Type: typography
        public static let eyebrow1Semibold = "opensans.eyebrow1-semibold.value"
        /// Type: typography
        public static let eyebrow1Bold = "opensans.eyebrow1-bold.value"
    }

    public enum geomanist {
        /// Type: typography
        public static let h1Medium = "geomanist.h1-medium.value"
        /// Type: typography
        public static let h2Medium = "geomanist.h2-medium.value"
        /// Type: typography
        public static let h3Semibold = "geomanist.h3-semibold.value"
    }

    public enum extended {
        /// Type: color
        public static let rosegold = "extended.rosegold.value"
        /// Type: color
        public static let mistyrose = "extended.mistyrose.value"
        /// Type: color
        public static let peachyrose = "extended.peachyrose.value"
        /// Type: color
        public static let moodyblue = "extended.moodyblue.value"
        /// Type: color
        public static let lemonzest = "extended.lemonzest.value"
        /// Type: color
        public static let caramel = "extended.caramel.value"
        /// Type: color
        public static let latte = "extended.latte.value"
        /// Type: color
        public static let fossil = "extended.fossil.value"
    }

    public enum lineHeights {
        /// Type: lineHeights
        public static let xBig = "lineHeights.xBig.value"
        /// Type: lineHeights
        public static let big = "lineHeights.big.value"
        /// Type: lineHeights
        public static let xxl = "lineHeights.xxl.value"
        /// Type: lineHeights
        public static let xl = "lineHeights.xl.value"
        /// Type: lineHeights
        public static let l = "lineHeights.l.value"
        /// Type: lineHeights
        public static let m = "lineHeights.m.value"
        /// Type: lineHeights
        public static let s = "lineHeights.s.value"
        /// Type: lineHeights
        public static let xs = "lineHeights.xs.value"
        /// Type: lineHeights
        public static let xxs = "lineHeights.xxs.value"
    }

    public enum fontFamilies {
        /// Type: fontFamilies
        public static let roboto = "fontFamilies.roboto.value"
        /// Type: fontFamilies
        public static let opensans = "fontFamilies.opensans.value"
        /// Type: fontFamilies
        public static let poppins = "fontFamilies.poppins.value"
        /// Type: fontFamilies
        public static let geomanist = "fontFamilies.geomanist.value"
    }

    public enum borderWidth {
        /// Type: borderWidth
        public static let s = "borderWidth.s.value"
        /// Type: borderWidth
        public static let m = "borderWidth.m.value"
    }

    public enum borderRadius {
        /// Type: borderRadius
        public static let xs = "borderRadius.xs.value"
        /// Type: borderRadius
        public static let s = "borderRadius.s.value"
        /// Type: borderRadius
        public static let m = "borderRadius.m.value"
        /// Type: borderRadius
        public static let ml = "borderRadius.ml.value"
        /// Type: borderRadius
        public static let l = "borderRadius.l.value"
        /// Type: borderRadius
        public static let big = "borderRadius.big.value"
        /// Type: borderRadius
        public static let xl = "borderRadius.xl.value"
        /// Type: borderRadius
        public static let xxl = "borderRadius.xxl.value"
        /// Type: borderRadius
        public static let none = "borderRadius.none.value"
    }

    public enum fontWeights {
        /// Type: fontWeights
        public static let light = "fontWeights.light.value"
        /// Type: fontWeights
        public static let regular = "fontWeights.regular.value"
        /// Type: fontWeights
        public static let medium = "fontWeights.medium.value"
        /// Type: fontWeights
        public static let semibold = "fontWeights.semibold.value"
        /// Type: fontWeights
        public static let bold = "fontWeights.bold.value"
        /// Type: fontWeights
        public static let book = "fontWeights.book.value"
    }

    public enum fontSize {
        /// Type: fontSizes
        public static let xxxs = "fontSize.xxxs.value"
        /// Type: fontSizes
        public static let xxs = "fontSize.xxs.value"
        /// Type: fontSizes
        public static let xs = "fontSize.xs.value"
        /// Type: fontSizes
        public static let s = "fontSize.s.value"
        /// Type: fontSizes
        public static let m = "fontSize.m.value"
        /// Type: fontSizes
        public static let l = "fontSize.l.value"
        /// Type: fontSizes
        public static let xl = "fontSize.xl.value"
        /// Type: fontSizes
        public static let xxl = "fontSize.xxl.value"
        /// Type: fontSizes
        public static let xxxl = "fontSize.xxxl.value"
        /// Type: fontSizes
        public static let big = "fontSize.big.value"
    }

    public enum letterSpacing {
        /// Type: letterSpacing
        public static let none = "letterSpacing.none.value"
        /// Type: letterSpacing
        public static let s = "letterSpacing.s.value"
    }

    public enum paragraphSpacing {
        /// Type: paragraphSpacing
        public static let none = "paragraphSpacing.none.value"
    }

    public enum textCase {
        /// Type: textCase
        public static let none = "textCase.none.value"
        /// Type: textCase
        public static let uppercase = "textCase.uppercase.value"
    }

    public enum textDecoration {
        /// Type: textDecoration
        public static let none = "textDecoration.none.value"
    }

    public enum space {
        /// Type: spacing
        public static let none = "space.none.value"
        /// Type: spacing
        public static let xxxxs = "space.xxxxs.value"
        /// Type: spacing
        public static let xxxs = "space.xxxs.value"
        /// Type: spacing
        public static let xxs = "space.xxs.value"
        /// Type: spacing
        public static let xs = "space.xs.value"
        /// Type: spacing
        public static let s = "space.s.value"
        /// Type: spacing
        public static let ms = "space.ms.value"
        /// Type: spacing
        public static let m = "space.m.value"
        /// Type: spacing
        public static let l = "space.l.value"
        /// Type: spacing
        public static let xl = "space.xl.value"
        /// Type: spacing
        public static let xxl = "space.xxl.value"
        /// Type: spacing
        public static let xxxl = "space.xxxl.value"
        /// Type: spacing
        public static let xxxxl = "space.xxxxl.value"
        /// Type: spacing
        public static let big = "space.big.value"
        /// Type: spacing
        public static let xBig = "space.xBig.value"
        /// Type: spacing
        public static let xxBig = "space.xxBig.value"
    }

    public enum size {
        /// Type: sizing
        public static let xxs = "size.xxs.value"
        /// Type: sizing
        public static let xs = "size.xs.value"
        /// Type: sizing
        public static let s = "size.s.value"
        /// Type: sizing
        public static let m = "size.m.value"
        /// Type: sizing
        public static let ml = "size.ml.value"
        /// Type: sizing
        public static let l = "size.l.value"
        /// Type: sizing
        public static let xl = "size.xl.value"
    }

    public enum elevation {
        /// Type: boxShadow
        public static let none = "elevation.none.value"
        /// Type: boxShadow
        public static let xs = "elevation.xs.value"
        /// Type: boxShadow
        public static let s = "elevation.s.value"
        /// Type: boxShadow
        public static let xl = "elevation.xl.value"
        public enum m {
            /// Type: boxShadow
            public static let btm = "elevation.m.btm.value"
            /// Type: boxShadow
            public static let top = "elevation.m.top.value"
        }

        public enum xxs {
            /// Type: boxShadow
            public static let top = "elevation.xxs.top.value"
            /// Type: boxShadow
            public static let btm = "elevation.xxs.btm.value"
        }

        public enum l {
            /// Type: boxShadow
            public static let btm = "elevation.l.btm.value"
            /// Type: boxShadow
            public static let top = "elevation.l.top.value"
        }
    }
}
