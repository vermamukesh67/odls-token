import Foundation
import SwiftTheme
import UIKit

// THIS FILE IS AUTO-GENERATED. PLEASE DO NOT EDIT IT MANUALLY.
// Generated on 21/09/2023 9:22:28 am

public enum SemanticTokens {
    public enum text {
        public enum link {
            /// Type: color
            public static let active = ThemeColorPicker(stringLiteral: "text.link.active.value")
            public static let activeCGColor = ThemeCGColorPicker(stringLiteral: "text.link.active.value")
            /// Type: color
            public static let pressed = ThemeColorPicker(stringLiteral: "text.link.pressed.value")
            public static let pressedCGColor = ThemeCGColorPicker(stringLiteral: "text.link.pressed.value")
            /// Type: color
            public static let disabled = ThemeColorPicker(stringLiteral: "text.link.disabled.value")
            public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "text.link.disabled.value")
        }

        /// Type: color
        public static let error = ThemeColorPicker(stringLiteral: "text.error.value")
        public static let errorCGColor = ThemeCGColorPicker(stringLiteral: "text.error.value")
        /// Type: color
        public static let header = ThemeColorPicker(stringLiteral: "text.header.value")
        public static let headerCGColor = ThemeCGColorPicker(stringLiteral: "text.header.value")
        /// Type: color
        public static let success = ThemeColorPicker(stringLiteral: "text.success.value")
        public static let successCGColor = ThemeCGColorPicker(stringLiteral: "text.success.value")
        public enum body {
            /// Type: color
            public static let disabled = ThemeColorPicker(stringLiteral: "text.body.disabled.value")
            public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "text.body.disabled.value")
        }
    }

    public enum hyperlinks {
        /// Type: typography
        public static let primary = ThemeAnyPicker(keyPath: "hyperlinks.primary.value")
        public static let primaryAttributedText = ThemeStringAttributesPicker(keyPath: "hyperlinks.primary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let secondary = ThemeAnyPicker(keyPath: "hyperlinks.secondary.value")
        public static let secondaryAttributedText = ThemeStringAttributesPicker(keyPath: "hyperlinks.secondary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
    }

    public enum header {
        /// Type: typography
        public static let primary = ThemeAnyPicker(keyPath: "header.primary.value")
        public static let primaryAttributedText = ThemeStringAttributesPicker(keyPath: "header.primary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let secondary = ThemeAnyPicker(keyPath: "header.secondary.value")
        public static let secondaryAttributedText = ThemeStringAttributesPicker(keyPath: "header.secondary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
    }
}
