import Foundation
import UIKit

// THIS FILE IS AUTO-GENERATED. PLEASE DO NOT EDIT IT MANUALLY.
// Generated on 28/09/2023 3:15:00 pm

/// Struct holding gradients defined for a theme.
public struct KitchenSinkDataThemeGradients {
    public let themeDisplayName: String
    public let gradients: [KitchenSinkDataThemeGradient]
}

/// Struct holding a gradient with displayName.
public struct KitchenSinkDataThemeGradient {
    public let displayName: String
    public let gradient: String
}

/// Class holding static data for Kitchen sink
public enum KitchenSinkData {
    /// List of gradients in each theme.
    public static let gradientsForThemes: [KitchenSinkDataThemeGradients] = [
        KitchenSinkDataThemeGradients(
            themeDisplayName: "mb",
            gradients: [
                KitchenSinkDataThemeGradient(displayName: "Alert", gradient: "linear-gradient(120deg, #febdbd66 2%, #ffe5da99 90%)"),
                KitchenSinkDataThemeGradient(displayName: "Ash clear", gradient: "linear-gradient(309.94deg, #3d525d 18.7%, #3d525d00 78.44%)"),
                KitchenSinkDataThemeGradient(displayName: "Ash cool", gradient: "linear-gradient(90deg, #97a1ae 0%, #3d525d 100%)"),
                KitchenSinkDataThemeGradient(displayName: "Ash grey", gradient: "linear-gradient(180deg, #575d65 0%, #363b40 100%)"),
                KitchenSinkDataThemeGradient(displayName: "Ash warm", gradient: "linear-gradient(0deg, #2d3d45 0%, #3d525d 100%)"),
                KitchenSinkDataThemeGradient(displayName: "Blush", gradient: "linear-gradient(105deg, #d2c7bb66 -29%, #febdbd4d 172%)"),
                KitchenSinkDataThemeGradient(displayName: "Dawn", gradient: "linear-gradient(130deg, #ffe5dac7 -29%, #cacce11a 250%)"),
                KitchenSinkDataThemeGradient(displayName: "Desert", gradient: "linear-gradient(243deg, #f1bf9866 -44%, #cacce145 150%)"),
                KitchenSinkDataThemeGradient(displayName: "Dusk", gradient: "linear-gradient(111deg, #febdbd63 -22%, #cacce145 90%)"),
                KitchenSinkDataThemeGradient(displayName: "Milk", gradient: "linear-gradient(66deg, #faf9f7 0%, #faf9f7 0%, #f4f2f1 98%)"),
                KitchenSinkDataThemeGradient(displayName: "Neutral cool", gradient: "radial-gradient(100% 50% at 100% 50%, #e2e7ec 0%, #f7f9fa 100%)"),
                KitchenSinkDataThemeGradient(displayName: "Neutral warm", gradient: "linear-gradient(270deg, #f7f9fabf 0%, #d3dae1bf 100%)"),
                KitchenSinkDataThemeGradient(displayName: "Ombre", gradient: "linear-gradient(58deg, #d2c7bb4d -49%, #f1bf984d 91%)"),
                KitchenSinkDataThemeGradient(displayName: "Promotional", gradient: "linear-gradient(115deg, #febdbd4d -24%, #cacce166 102%)"),
                KitchenSinkDataThemeGradient(displayName: "Reminder", gradient: "linear-gradient(67deg, #f1bf9833 -2%, #fcf1d599 76%)"),
                KitchenSinkDataThemeGradient(displayName: "Sandstorm", gradient: "linear-gradient(243deg, #fcf1d559 -10%, #f1bf9880 130%)"),
                KitchenSinkDataThemeGradient(displayName: "White clear", gradient: "linear-gradient(309.94deg, #ffffff 0%, #ffffff4d 100%);"),
            ]
        ),
        KitchenSinkDataThemeGradients(
            themeDisplayName: "frlight",
            gradients: [
                KitchenSinkDataThemeGradient(displayName: "Carnation warm", gradient: "linear-gradient(164deg, #ff806a 17.32%, #f26565 82.86%)"),
                KitchenSinkDataThemeGradient(displayName: "Cornflower cool", gradient: "linear-gradient(254.29deg, #6166FF 18.36%, #7b7ff8 90.54%)"),
                KitchenSinkDataThemeGradient(displayName: "Error atlas", gradient: "linear-gradient(254.29deg, #ff5959 0%, #f67979 100%)"),
                KitchenSinkDataThemeGradient(displayName: "Error skye", gradient: "linear-gradient(254.29deg, #f67979 9.46%, #e95555 90.54%)"),
                KitchenSinkDataThemeGradient(displayName: "Moody blue warm", gradient: "linear-gradient(254.29deg, #9fa5f1 18.36%, #7278cf 90.54%)"),
                KitchenSinkDataThemeGradient(displayName: "Salmon cool", gradient: "linear-gradient(253.74deg, #ff806a 37.1%, #ffb38e 117.74%)"),
                KitchenSinkDataThemeGradient(displayName: "Sand clear", gradient: "linear-gradient(309.94deg, #494848 27.78%, #49484800 70.19%)"),
                KitchenSinkDataThemeGradient(displayName: "Sand warm", gradient: "linear-gradient(117.88deg, #dbd9d8 -28.77%, #edeae8 100%)"),
                KitchenSinkDataThemeGradient(displayName: "Skye white clear", gradient: "linear-gradient(309.94deg, #ffffff 14.51%, #ffffff4d 85.49%);"),
                KitchenSinkDataThemeGradient(displayName: "Steel clear", gradient: "linear-gradient(309.94deg, #484e60 27.78%, #484e6000 70.19%)"),
                KitchenSinkDataThemeGradient(displayName: "Steel cool", gradient: "linear-gradient(118.36deg, #767b88 0%, #31384c 100%)"),
                KitchenSinkDataThemeGradient(displayName: "Steel white clear", gradient: "linear-gradient(309.94deg, #ffffff 14.51%, #ffffff4d 85.49%)"),
            ]
        ),
        KitchenSinkDataThemeGradients(
            themeDisplayName: "bb",
            gradients: [
                KitchenSinkDataThemeGradient(displayName: "Black", gradient: "linear-gradient(309.94deg, #5A707B 15.39%, #5a707b14 81.45%)"),
                KitchenSinkDataThemeGradient(displayName: "Blue", gradient: "linear-gradient(204.78deg, #8FBCFE 31.58%, #818FFD 106.77%, #818FFD 106.77%);"),
                KitchenSinkDataThemeGradient(displayName: "Carbon dark gradient", gradient: "linear-gradient(280.56deg, #2D3D45 0%, #39474E 49.81%, #4A5C65 98.6%)"),
                KitchenSinkDataThemeGradient(displayName: "Carbon gradient", gradient: "linear-gradient(280.56deg, #3D525D 0%, #49565F 49.81%, #5A6A75 98.6%)"),
                KitchenSinkDataThemeGradient(displayName: "Green", gradient: "linear-gradient(273.73deg, #74D8A7 11.05%, #55C08C 53.77%, #34A66F 112.5%);"),
                KitchenSinkDataThemeGradient(displayName: "Grey", gradient: "linear-gradient(90deg, #DCE2E5 0%, #F2F5F6 100%)"),
                KitchenSinkDataThemeGradient(displayName: "Ocbc red gradient", gradient: "linear-gradient(230.24deg, #FB5C39 19.14%, #ED1C24 67.18%, #D6271C 84.11%)"),
                KitchenSinkDataThemeGradient(displayName: "Red", gradient: "linear-gradient(230.27deg, #FF8E4F 15.73%, #EA493F 94.52%);"),
                KitchenSinkDataThemeGradient(displayName: "White", gradient: "linear-gradient(309.94deg, #ffffff 15.39%, #ffffff14 81.45%)"),
                KitchenSinkDataThemeGradient(displayName: "Yellow", gradient: "linear-gradient(273.81deg, #FFD566 -20.15%, #FFB248 106.01%);"),
            ]
        ),
    ]
}
