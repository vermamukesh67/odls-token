import Foundation
import SwiftTheme
import UIKit

// THIS FILE IS AUTO-GENERATED. PLEASE DO NOT EDIT IT MANUALLY.
// Generated on 12/09/2023 12:12:53 pm

public enum ThemePickers {
    public enum text {
        public enum link {
            /// Type: color
            public static let active = ThemeColorPicker(stringLiteral: "text.link.active.value")
            public static let activeCGColor = ThemeCGColorPicker(stringLiteral: "text.link.active.value")
            /// Type: color
            public static let pressed = ThemeColorPicker(stringLiteral: "text.link.pressed.value")
            public static let pressedCGColor = ThemeCGColorPicker(stringLiteral: "text.link.pressed.value")
            /// Type: color
            public static let disabled = ThemeColorPicker(stringLiteral: "text.link.disabled.value")
            public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "text.link.disabled.value")
        }

        /// Type: color
        public static let error = ThemeColorPicker(stringLiteral: "text.error.value")
        public static let errorCGColor = ThemeCGColorPicker(stringLiteral: "text.error.value")
        /// Type: color
        public static let header = ThemeColorPicker(stringLiteral: "text.header.value")
        public static let headerCGColor = ThemeCGColorPicker(stringLiteral: "text.header.value")
        /// Type: color
        public static let success = ThemeColorPicker(stringLiteral: "text.success.value")
        public static let successCGColor = ThemeCGColorPicker(stringLiteral: "text.success.value")
        public enum body {
            /// Type: color
            public static let onLight = ThemeColorPicker(stringLiteral: "text.body.onLight.value")
            public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "text.body.onLight.value")
            /// Type: color
            public static let onDark = ThemeColorPicker(stringLiteral: "text.body.onDark.value")
            public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "text.body.onDark.value")
            public enum caption {
                /// Type: color
                public static let onLight = ThemeColorPicker(stringLiteral: "text.body.caption.onLight.value")
                public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "text.body.caption.onLight.value")
                /// Type: color
                public static let onDark = ThemeColorPicker(stringLiteral: "text.body.caption.onDark.value")
                public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "text.body.caption.onDark.value")
            }

            public enum eyebrow {
                /// Type: color
                public static let primary = ThemeColorPicker(stringLiteral: "text.body.eyebrow.primary.value")
                public static let primaryCGColor = ThemeCGColorPicker(stringLiteral: "text.body.eyebrow.primary.value")
                /// Type: color
                public static let secondary = ThemeColorPicker(stringLiteral: "text.body.eyebrow.secondary.value")
                public static let secondaryCGColor = ThemeCGColorPicker(stringLiteral: "text.body.eyebrow.secondary.value")
            }

            /// Type: color
            public static let disabled = ThemeColorPicker(stringLiteral: "text.body.disabled.value")
            public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "text.body.disabled.value")
        }
    }

    public enum interactive {
        public enum primary {
            public enum bg {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "interactive.primary.bg.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "interactive.primary.bg.default.value")
                /// Type: color
                public static let pressed = ThemeColorPicker(stringLiteral: "interactive.primary.bg.pressed.value")
                public static let pressedCGColor = ThemeCGColorPicker(stringLiteral: "interactive.primary.bg.pressed.value")
                /// Type: color
                public static let disabled = ThemeColorPicker(stringLiteral: "interactive.primary.bg.disabled.value")
                public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "interactive.primary.bg.disabled.value")
            }
        }

        public enum secondary {
            public enum bg {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "interactive.secondary.bg.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "interactive.secondary.bg.default.value")
                /// Type: color
                public static let pressed = ThemeColorPicker(stringLiteral: "interactive.secondary.bg.pressed.value")
                public static let pressedCGColor = ThemeCGColorPicker(stringLiteral: "interactive.secondary.bg.pressed.value")
                /// Type: color
                public static let disabled = ThemeColorPicker(stringLiteral: "interactive.secondary.bg.disabled.value")
                public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "interactive.secondary.bg.disabled.value")
            }

            public enum border {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "interactive.secondary.border.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "interactive.secondary.border.default.value")
                /// Type: color
                public static let pressed = ThemeColorPicker(stringLiteral: "interactive.secondary.border.pressed.value")
                public static let pressedCGColor = ThemeCGColorPicker(stringLiteral: "interactive.secondary.border.pressed.value")
                /// Type: color
                public static let disabled = ThemeColorPicker(stringLiteral: "interactive.secondary.border.disabled.value")
                public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "interactive.secondary.border.disabled.value")
            }
        }
    }

    public enum icon {
        public enum link {
            /// Type: color
            public static let active = ThemeColorPicker(stringLiteral: "icon.link.active.value")
            public static let activeCGColor = ThemeCGColorPicker(stringLiteral: "icon.link.active.value")
            /// Type: color
            public static let pressed = ThemeColorPicker(stringLiteral: "icon.link.pressed.value")
            public static let pressedCGColor = ThemeCGColorPicker(stringLiteral: "icon.link.pressed.value")
            /// Type: color
            public static let disabled = ThemeColorPicker(stringLiteral: "icon.link.disabled.value")
            public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "icon.link.disabled.value")
        }

        /// Type: color
        public static let alert = ThemeColorPicker(stringLiteral: "icon.alert.value")
        public static let alertCGColor = ThemeCGColorPicker(stringLiteral: "icon.alert.value")
        /// Type: color
        public static let error = ThemeColorPicker(stringLiteral: "icon.error.value")
        public static let errorCGColor = ThemeCGColorPicker(stringLiteral: "icon.error.value")
        /// Type: color
        public static let success = ThemeColorPicker(stringLiteral: "icon.success.value")
        public static let successCGColor = ThemeCGColorPicker(stringLiteral: "icon.success.value")
        /// Type: color
        public static let informational = ThemeColorPicker(stringLiteral: "icon.informational.value")
        public static let informationalCGColor = ThemeCGColorPicker(stringLiteral: "icon.informational.value")
        public enum defaultValue {
            /// Type: color
            public static let onDark = ThemeColorPicker(stringLiteral: "icon.default.onDark.value")
            public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "icon.default.onDark.value")
            /// Type: color
            public static let onLight = ThemeColorPicker(stringLiteral: "icon.default.onLight.value")
            public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "icon.default.onLight.value")
        }
    }

    public enum background {
        /// Type: color
        public static let surface1 = ThemeColorPicker(stringLiteral: "background.surface1.value")
        public static let surface1CGColor = ThemeCGColorPicker(stringLiteral: "background.surface1.value")
        /// Type: color
        public static let surface2 = ThemeColorPicker(stringLiteral: "background.surface2.value")
        public static let surface2CGColor = ThemeCGColorPicker(stringLiteral: "background.surface2.value")
        /// Type: color
        public static let highlight = ThemeColorPicker(stringLiteral: "background.highlight.value")
        public static let highlightCGColor = ThemeCGColorPicker(stringLiteral: "background.highlight.value")
    }

    public enum hyperlinks {
        /// Type: typography
        public static let primary = ThemeAnyPicker(keyPath: "hyperlinks.primary.value")
        public static let primaryAttributedText = ThemeStringAttributesPicker(keyPath: "hyperlinks.primary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let secondary = ThemeAnyPicker(keyPath: "hyperlinks.secondary.value")
        public static let secondaryAttributedText = ThemeStringAttributesPicker(keyPath: "hyperlinks.secondary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let tertiary = ThemeAnyPicker(keyPath: "hyperlinks.tertiary.value")
        public static let tertiaryAttributedText = ThemeStringAttributesPicker(keyPath: "hyperlinks.tertiary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
    }

    public enum body {
        public enum primary {
            /// Type: typography
            public static let regular = ThemeAnyPicker(keyPath: "body.primary.regular.value")
            public static let regularAttributedText = ThemeStringAttributesPicker(keyPath: "body.primary.regular.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let semibold = ThemeAnyPicker(keyPath: "body.primary.semibold.value")
            public static let semiboldAttributedText = ThemeStringAttributesPicker(keyPath: "body.primary.semibold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }

        public enum secondary {
            /// Type: typography
            public static let regular = ThemeAnyPicker(keyPath: "body.secondary.regular.value")
            public static let regularAttributedText = ThemeStringAttributesPicker(keyPath: "body.secondary.regular.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let semibold = ThemeAnyPicker(keyPath: "body.secondary.semibold.value")
            public static let semiboldAttributedText = ThemeStringAttributesPicker(keyPath: "body.secondary.semibold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }
    }

    public enum caption {
        /// Type: typography
        public static let regular = ThemeAnyPicker(keyPath: "caption.regular.value")
        public static let regularAttributedText = ThemeStringAttributesPicker(keyPath: "caption.regular.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let semibold = ThemeAnyPicker(keyPath: "caption.semibold.value")
        public static let semiboldAttributedText = ThemeStringAttributesPicker(keyPath: "caption.semibold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
    }

    public enum header {
        /// Type: typography
        public static let primary = ThemeAnyPicker(keyPath: "header.primary.value")
        public static let primaryAttributedText = ThemeStringAttributesPicker(keyPath: "header.primary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let secondary = ThemeAnyPicker(keyPath: "header.secondary.value")
        public static let secondaryAttributedText = ThemeStringAttributesPicker(keyPath: "header.secondary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
    }

    public enum eyebrow {
        /// Type: typography
        public static let primary = ThemeAnyPicker(keyPath: "eyebrow.primary.value")
        public static let primaryAttributedText = ThemeStringAttributesPicker(keyPath: "eyebrow.primary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let secondary = ThemeAnyPicker(keyPath: "eyebrow.secondary.value")
        public static let secondaryAttributedText = ThemeStringAttributesPicker(keyPath: "eyebrow.secondary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
    }

    /// Type: spacing
    public static let pagemargin = ThemeCGFloatPicker(stringLiteral: "pagemargin.value")
    public enum button {
        public enum standard {
            public enum color {
                public enum bg {
                    public enum primary {
                        /// Type: color
                        public static let defaultValue = ThemeColorPicker(stringLiteral: "button.standard.color.bg.primary.default.value")
                        public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "button.standard.color.bg.primary.default.value")
                        /// Type: color
                        public static let pressed = ThemeColorPicker(stringLiteral: "button.standard.color.bg.primary.pressed.value")
                        public static let pressedCGColor = ThemeCGColorPicker(stringLiteral: "button.standard.color.bg.primary.pressed.value")
                        /// Type: color
                        public static let disabled = ThemeColorPicker(stringLiteral: "button.standard.color.bg.primary.disabled.value")
                        public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "button.standard.color.bg.primary.disabled.value")
                    }
                }

                public enum text {
                    public enum primary {
                        /// Type: color
                        public static let defaultValue = ThemeColorPicker(stringLiteral: "button.standard.color.text.primary.default.value")
                        public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "button.standard.color.text.primary.default.value")
                        /// Type: color
                        public static let disabled = ThemeColorPicker(stringLiteral: "button.standard.color.text.primary.disabled.value")
                        public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "button.standard.color.text.primary.disabled.value")
                    }

                    public enum secondary {
                        /// Type: color
                        public static let defaultValue = ThemeColorPicker(stringLiteral: "button.standard.color.text.secondary.default.value")
                        public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "button.standard.color.text.secondary.default.value")
                        /// Type: color
                        public static let disabled = ThemeColorPicker(stringLiteral: "button.standard.color.text.secondary.disabled.value")
                        public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "button.standard.color.text.secondary.disabled.value")
                    }
                }

                public enum border {
                    public enum secondary {
                        /// Type: color
                        public static let defaultValue = ThemeColorPicker(stringLiteral: "button.standard.color.border.secondary.default.value")
                        public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "button.standard.color.border.secondary.default.value")
                        /// Type: color
                        public static let pressed = ThemeColorPicker(stringLiteral: "button.standard.color.border.secondary.pressed.value")
                        public static let pressedCGColor = ThemeCGColorPicker(stringLiteral: "button.standard.color.border.secondary.pressed.value")
                        /// Type: color
                        public static let disabled = ThemeColorPicker(stringLiteral: "button.standard.color.border.secondary.disabled.value")
                        public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "button.standard.color.border.secondary.disabled.value")
                    }
                }

                public enum icon {
                    public enum primary {
                        /// Type: color
                        public static let defaultValue = ThemeColorPicker(stringLiteral: "button.standard.color.icon.primary.default.value")
                        public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "button.standard.color.icon.primary.default.value")
                        /// Type: color
                        public static let disabled = ThemeColorPicker(stringLiteral: "button.standard.color.icon.primary.disabled.value")
                        public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "button.standard.color.icon.primary.disabled.value")
                    }

                    public enum secondary {
                        /// Type: color
                        public static let defaultValue = ThemeColorPicker(stringLiteral: "button.standard.color.icon.secondary.default.value")
                        public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "button.standard.color.icon.secondary.default.value")
                        /// Type: color
                        public static let disabled = ThemeColorPicker(stringLiteral: "button.standard.color.icon.secondary.disabled.value")
                        public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "button.standard.color.icon.secondary.disabled.value")
                    }
                }
            }

            /// Type: borderRadius
            public static let borderRadius = ThemeCGFloatPicker(stringLiteral: "button.standard.borderRadius.value")
            public enum spacing {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "button.standard.spacing.vertical.value")
            }
        }

        public enum slider {
            /// Type: typography
            public static let font = ThemeAnyPicker(keyPath: "button.slider.font.value")
            public static let fontAttributedText = ThemeStringAttributesPicker(keyPath: "button.slider.font.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            public enum color {
                public enum container {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "button.slider.color.container.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "button.slider.color.container.default.value")
                    /// Type: color
                    public static let pressed = ThemeColorPicker(stringLiteral: "button.slider.color.container.pressed.value")
                    public static let pressedCGColor = ThemeCGColorPicker(stringLiteral: "button.slider.color.container.pressed.value")
                    /// Type: color
                    public static let success = ThemeColorPicker(stringLiteral: "button.slider.color.container.success.value")
                    public static let successCGColor = ThemeCGColorPicker(stringLiteral: "button.slider.color.container.success.value")
                    /// Type: color
                    public static let error = ThemeColorPicker(stringLiteral: "button.slider.color.container.error.value")
                    public static let errorCGColor = ThemeCGColorPicker(stringLiteral: "button.slider.color.container.error.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "button.slider.color.container.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "button.slider.color.container.disabled.value")
                }

                public enum knob {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "button.slider.color.knob.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "button.slider.color.knob.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "button.slider.color.knob.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "button.slider.color.knob.disabled.value")
                }

                public enum icon {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "button.slider.color.icon.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "button.slider.color.icon.default.value")
                    public enum knob {
                        /// Type: color
                        public static let defaultValue = ThemeColorPicker(stringLiteral: "button.slider.color.icon.knob.default.value")
                        public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "button.slider.color.icon.knob.default.value")
                        /// Type: color
                        public static let disabled = ThemeColorPicker(stringLiteral: "button.slider.color.icon.knob.disabled.value")
                        public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "button.slider.color.icon.knob.disabled.value")
                    }
                }

                public enum text {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "button.slider.color.text.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "button.slider.color.text.default.value")
                    /// Type: color
                    public static let pressed = ThemeColorPicker(stringLiteral: "button.slider.color.text.pressed.value")
                    public static let pressedCGColor = ThemeCGColorPicker(stringLiteral: "button.slider.color.text.pressed.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "button.slider.color.text.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "button.slider.color.text.disabled.value")
                }
            }

            public enum loader {
                /// Type: other
                public static let mode = ThemeAnyPicker(keyPath: "button.slider.loader.mode.value")
            }
        }

        /// Type: typography
        public static let font = ThemeAnyPicker(keyPath: "button.font.value")
        public static let fontAttributedText = ThemeStringAttributesPicker(keyPath: "button.font.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        public enum rounded {
            /// Type: borderRadius
            public static let borderRadius = ThemeCGFloatPicker(stringLiteral: "button.rounded.borderRadius.value")
            public enum spacing {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "button.rounded.spacing.vertical.value")
                /// Type: spacing
                public static let gap = ThemeCGFloatPicker(stringLiteral: "button.rounded.spacing.gap.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "button.rounded.spacing.horizontal.value")
            }
        }

        public enum combo {
            public enum standard {
                public enum spacing {
                    /// Type: spacing
                    public static let gap = ThemeCGFloatPicker(stringLiteral: "button.combo.standard.spacing.gap.value")
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "button.combo.standard.spacing.vertical.value")
                }
            }

            public enum rounded {
                public enum spacing {
                    /// Type: spacing
                    public static let gap = ThemeCGFloatPicker(stringLiteral: "button.combo.rounded.spacing.gap.value")
                }
            }

            public enum standardHorizontal {
                public enum spacing {
                    /// Type: spacing
                    public static let gap = ThemeCGFloatPicker(stringLiteral: "button.combo.standardHorizontal.spacing.gap.value")
                }
            }
        }

        public enum textLink {
            /// Type: spacing
            public static let gap = ThemeCGFloatPicker(stringLiteral: "button.textLink.gap.value")
            public enum color {
                public enum text {
                    public enum defaultValue {
                        /// Type: color
                        public static let onLight = ThemeColorPicker(stringLiteral: "button.textLink.color.text.default.onLight.value")
                        public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "button.textLink.color.text.default.onLight.value")
                        /// Type: color
                        public static let onDark = ThemeColorPicker(stringLiteral: "button.textLink.color.text.default.onDark.value")
                        public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "button.textLink.color.text.default.onDark.value")
                    }

                    public enum pressed {
                        /// Type: color
                        public static let onLight = ThemeColorPicker(stringLiteral: "button.textLink.color.text.pressed.onLight.value")
                        public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "button.textLink.color.text.pressed.onLight.value")
                        /// Type: color
                        public static let onDark = ThemeColorPicker(stringLiteral: "button.textLink.color.text.pressed.onDark.value")
                        public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "button.textLink.color.text.pressed.onDark.value")
                    }

                    public enum disabled {
                        /// Type: color
                        public static let onLight = ThemeColorPicker(stringLiteral: "button.textLink.color.text.disabled.onLight.value")
                        public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "button.textLink.color.text.disabled.onLight.value")
                        /// Type: color
                        public static let onDark = ThemeColorPicker(stringLiteral: "button.textLink.color.text.disabled.onDark.value")
                        public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "button.textLink.color.text.disabled.onDark.value")
                    }
                }

                public enum icon {
                    public enum defaultValue {
                        /// Type: color
                        public static let onLight = ThemeColorPicker(stringLiteral: "button.textLink.color.icon.default.onLight.value")
                        public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "button.textLink.color.icon.default.onLight.value")
                        /// Type: color
                        public static let onDark = ThemeColorPicker(stringLiteral: "button.textLink.color.icon.default.onDark.value")
                        public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "button.textLink.color.icon.default.onDark.value")
                    }

                    public enum pressed {
                        /// Type: color
                        public static let onLight = ThemeColorPicker(stringLiteral: "button.textLink.color.icon.pressed.onLight.value")
                        public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "button.textLink.color.icon.pressed.onLight.value")
                        /// Type: color
                        public static let onDark = ThemeColorPicker(stringLiteral: "button.textLink.color.icon.pressed.onDark.value")
                        public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "button.textLink.color.icon.pressed.onDark.value")
                    }

                    public enum disabled {
                        /// Type: color
                        public static let onLight = ThemeColorPicker(stringLiteral: "button.textLink.color.icon.disabled.onLight.value")
                        public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "button.textLink.color.icon.disabled.onLight.value")
                        /// Type: color
                        public static let onDark = ThemeColorPicker(stringLiteral: "button.textLink.color.icon.disabled.onDark.value")
                        public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "button.textLink.color.icon.disabled.onDark.value")
                    }
                }
            }

            public enum font {
                /// Type: typography
                public static let primary = ThemeAnyPicker(keyPath: "button.textLink.font.primary.value")
                public static let primaryAttributedText = ThemeStringAttributesPicker(keyPath: "button.textLink.font.primary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let secondary = ThemeAnyPicker(keyPath: "button.textLink.font.secondary.value")
                public static let secondaryAttributedText = ThemeStringAttributesPicker(keyPath: "button.textLink.font.secondary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let tertiary = ThemeAnyPicker(keyPath: "button.textLink.font.tertiary.value")
                public static let tertiaryAttributedText = ThemeStringAttributesPicker(keyPath: "button.textLink.font.tertiary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            public enum icon {
                /// Type: sizing
                public static let size = ThemeCGFloatPicker(stringLiteral: "button.textLink.icon.size.value")
            }

            public enum tertiary {
                public enum icon {
                    /// Type: sizing
                    public static let size = ThemeCGFloatPicker(stringLiteral: "button.textLink.tertiary.icon.size.value")
                }
            }
        }

        public enum circle {
            public enum color {
                public enum bg {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "button.circle.color.bg.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "button.circle.color.bg.default.value")
                    /// Type: color
                    public static let pressed = ThemeColorPicker(stringLiteral: "button.circle.color.bg.pressed.value")
                    public static let pressedCGColor = ThemeCGColorPicker(stringLiteral: "button.circle.color.bg.pressed.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "button.circle.color.bg.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "button.circle.color.bg.disabled.value")
                }

                /// Type: color
                public static let actionIcon = ThemeColorPicker(stringLiteral: "button.circle.color.actionIcon.value")
                public static let actionIconCGColor = ThemeCGColorPicker(stringLiteral: "button.circle.color.actionIcon.value")
            }

            public enum size {
                /// Type: sizing
                public static let m = ThemeCGFloatPicker(stringLiteral: "button.circle.size.m.value")
                /// Type: sizing
                public static let l = ThemeCGFloatPicker(stringLiteral: "button.circle.size.l.value")
                /// Type: sizing
                public static let xl = ThemeCGFloatPicker(stringLiteral: "button.circle.size.xl.value")
            }
        }

        public enum sticky {
            public enum spacing {
                public enum vertical {
                    /// Type: spacing
                    public static let wHomeBar = ThemeCGFloatPicker(stringLiteral: "button.sticky.spacing.vertical.wHomeBar.value")
                    /// Type: spacing
                    public static let noHomeBar = ThemeCGFloatPicker(stringLiteral: "button.sticky.spacing.vertical.noHomeBar.value")
                }
            }

            /// Type: boxShadow
            public static let boxShadow = ThemeAnyPicker(keyPath: "button.sticky.boxShadow.value")
            /// Type: borderRadius
            public static let borderRadius = ThemeCGFloatPicker(stringLiteral: "button.sticky.borderRadius.value")
            public enum color {
                /// Type: color
                public static let container = ThemeColorPicker(stringLiteral: "button.sticky.color.container.value")
                public static let containerCGColor = ThemeCGColorPicker(stringLiteral: "button.sticky.color.container.value")
            }
        }
    }

    public enum overlay {
        public enum color {
            /// Type: color
            public static let container = ThemeColorPicker(stringLiteral: "overlay.color.container.value")
            public static let containerCGColor = ThemeCGColorPicker(stringLiteral: "overlay.color.container.value")
        }
    }

    public enum toast {
        public enum color {
            public enum actionIcon {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "toast.color.actionIcon.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.actionIcon.default.value")
            }

            public enum statusIcon {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "toast.color.statusIcon.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.statusIcon.default.value")
                /// Type: color
                public static let success = ThemeColorPicker(stringLiteral: "toast.color.statusIcon.success.value")
                public static let successCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.statusIcon.success.value")
                /// Type: color
                public static let error = ThemeColorPicker(stringLiteral: "toast.color.statusIcon.error.value")
                public static let errorCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.statusIcon.error.value")
                /// Type: color
                public static let informational = ThemeColorPicker(stringLiteral: "toast.color.statusIcon.informational.value")
                public static let informationalCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.statusIcon.informational.value")
            }

            public enum bg {
                public enum container {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "toast.color.bg.container.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.bg.container.default.value")
                    /// Type: color
                    public static let success = ThemeColorPicker(stringLiteral: "toast.color.bg.container.success.value")
                    public static let successCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.bg.container.success.value")
                    /// Type: color
                    public static let error = ThemeColorPicker(stringLiteral: "toast.color.bg.container.error.value")
                    public static let errorCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.bg.container.error.value")
                    /// Type: color
                    public static let informational = ThemeColorPicker(stringLiteral: "toast.color.bg.container.informational.value")
                    public static let informationalCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.bg.container.informational.value")
                }

                public enum emphasis {
                    /// Type: color
                    public static let success = ThemeColorPicker(stringLiteral: "toast.color.bg.emphasis.success.value")
                    public static let successCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.bg.emphasis.success.value")
                    /// Type: color
                    public static let error = ThemeColorPicker(stringLiteral: "toast.color.bg.emphasis.error.value")
                    public static let errorCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.bg.emphasis.error.value")
                    /// Type: color
                    public static let informational = ThemeColorPicker(stringLiteral: "toast.color.bg.emphasis.informational.value")
                    public static let informationalCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.bg.emphasis.informational.value")
                }
            }

            /// Type: color
            public static let font = ThemeColorPicker(stringLiteral: "toast.color.font.value")
            public static let fontCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.font.value")
            public enum fullWidthIcon {
                /// Type: color
                public static let error = ThemeColorPicker(stringLiteral: "toast.color.fullWidthIcon.error.value")
                public static let errorCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.fullWidthIcon.error.value")
                /// Type: color
                public static let success = ThemeColorPicker(stringLiteral: "toast.color.fullWidthIcon.success.value")
                public static let successCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.fullWidthIcon.success.value")
                /// Type: color
                public static let informational = ThemeColorPicker(stringLiteral: "toast.color.fullWidthIcon.informational.value")
                public static let informationalCGColor = ThemeCGColorPicker(stringLiteral: "toast.color.fullWidthIcon.informational.value")
            }
        }

        /// Type: borderRadius
        public static let borderRadius = ThemeCGFloatPicker(stringLiteral: "toast.borderRadius.value")
        /// Type: typography
        public static let font = ThemeAnyPicker(keyPath: "toast.font.value")
        public static let fontAttributedText = ThemeStringAttributesPicker(keyPath: "toast.font.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        public enum spacing {
            /// Type: spacing
            public static let vertical = ThemeCGFloatPicker(stringLiteral: "toast.spacing.vertical.value")
            /// Type: spacing
            public static let horizontal = ThemeCGFloatPicker(stringLiteral: "toast.spacing.horizontal.value")
            /// Type: spacing
            public static let gap = ThemeCGFloatPicker(stringLiteral: "toast.spacing.gap.value")
            public enum fullWidth {
                /// Type: spacing
                public static let topPadding = ThemeCGFloatPicker(stringLiteral: "toast.spacing.fullWidth.topPadding.value")
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "toast.spacing.fullWidth.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "toast.spacing.fullWidth.horizontal.value")
                /// Type: spacing
                public static let gap = ThemeCGFloatPicker(stringLiteral: "toast.spacing.fullWidth.gap.value")
            }
        }

        /// Type: sizing
        public static let size = ThemeCGFloatPicker(stringLiteral: "toast.size.value")
        /// Type: typography
        public static let title = ThemeAnyPicker(keyPath: "toast.title.value")
        public static let titleAttributedText = ThemeStringAttributesPicker(keyPath: "toast.title.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
    }

    public enum avatar {
        /// Type: typography
        public static let font = ThemeAnyPicker(keyPath: "avatar.font.value")
        public static let fontAttributedText = ThemeStringAttributesPicker(keyPath: "avatar.font.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        public enum color {
            public enum bg {
                /// Type: color
                public static let product = ThemeColorPicker(stringLiteral: "avatar.color.bg.product.value")
                public static let productCGColor = ThemeCGColorPicker(stringLiteral: "avatar.color.bg.product.value")
                /// Type: color
                public static let user = ThemeColorPicker(stringLiteral: "avatar.color.bg.user.value")
                public static let userCGColor = ThemeCGColorPicker(stringLiteral: "avatar.color.bg.user.value")
            }

            /// Type: color
            public static let text = ThemeColorPicker(stringLiteral: "avatar.color.text.value")
            public static let textCGColor = ThemeCGColorPicker(stringLiteral: "avatar.color.text.value")
            /// Type: color
            public static let icon = ThemeColorPicker(stringLiteral: "avatar.color.icon.value")
            public static let iconCGColor = ThemeCGColorPicker(stringLiteral: "avatar.color.icon.value")
        }

        /// Type: sizing
        public static let size = ThemeCGFloatPicker(stringLiteral: "avatar.size.value")
        /// Type: sizing
        public static let iconSize = ThemeCGFloatPicker(stringLiteral: "avatar.iconSize.value")
    }

    public enum loader {
        public enum spinner {
            public enum color {
                public enum border {
                    /// Type: color
                    public static let onLight = ThemeColorPicker(stringLiteral: "loader.spinner.color.border.onLight.value")
                    public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "loader.spinner.color.border.onLight.value")
                    /// Type: color
                    public static let onDark = ThemeColorPicker(stringLiteral: "loader.spinner.color.border.onDark.value")
                    public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "loader.spinner.color.border.onDark.value")
                }
            }

            /// Type: borderWidth
            public static let borderWidth = ThemeCGFloatPicker(stringLiteral: "loader.spinner.borderWidth.value")
        }

        public enum skeletal {
            public enum color {
                /// Type: color
                public static let bg = ThemeColorPicker(stringLiteral: "loader.skeletal.color.bg.value")
                public static let bgCGColor = ThemeCGColorPicker(stringLiteral: "loader.skeletal.color.bg.value")
                /// Type: color
                public static let shimmer = ThemeColorPicker(stringLiteral: "loader.skeletal.color.shimmer.value")
                public static let shimmerCGColor = ThemeCGColorPicker(stringLiteral: "loader.skeletal.color.shimmer.value")
            }

            public enum gap {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "loader.skeletal.gap.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "loader.skeletal.gap.horizontal.value")
            }

            public enum horizontal {
                public enum size {
                    /// Type: sizing
                    public static let s = ThemeCGFloatPicker(stringLiteral: "loader.skeletal.horizontal.size.s.value")
                    /// Type: sizing
                    public static let m = ThemeCGFloatPicker(stringLiteral: "loader.skeletal.horizontal.size.m.value")
                    /// Type: sizing
                    public static let l = ThemeCGFloatPicker(stringLiteral: "loader.skeletal.horizontal.size.l.value")
                    /// Type: sizing
                    public static let xl = ThemeCGFloatPicker(stringLiteral: "loader.skeletal.horizontal.size.xl.value")
                }
            }

            public enum rounded {
                public enum borderRadius {
                    /// Type: borderRadius
                    public static let s = ThemeCGFloatPicker(stringLiteral: "loader.skeletal.rounded.borderRadius.s.value")
                }
            }
        }
    }

    public enum switchComponent {
        public enum off {
            public enum color {
                public enum container {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "switch.off.color.container.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "switch.off.color.container.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "switch.off.color.container.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "switch.off.color.container.disabled.value")
                }

                public enum knob {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "switch.off.color.knob.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "switch.off.color.knob.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "switch.off.color.knob.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "switch.off.color.knob.disabled.value")
                }
            }
        }

        public enum on {
            public enum color {
                public enum container {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "switch.on.color.container.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "switch.on.color.container.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "switch.on.color.container.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "switch.on.color.container.disabled.value")
                }

                public enum knob {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "switch.on.color.knob.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "switch.on.color.knob.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "switch.on.color.knob.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "switch.on.color.knob.disabled.value")
                }
            }
        }

        public enum loader {
            /// Type: other
            public static let mode = ThemeAnyPicker(keyPath: "switch.loader.mode.value")
        }

        /// Type: boxShadow
        public static let elevation = ThemeAnyPicker(keyPath: "switch.elevation.value")
    }

    public enum alerts {
        public enum spacing {
            /// Type: spacing
            public static let vertical = ThemeCGFloatPicker(stringLiteral: "alerts.spacing.vertical.value")
            /// Type: spacing
            public static let horizontal = ThemeCGFloatPicker(stringLiteral: "alerts.spacing.horizontal.value")
            /// Type: spacing
            public static let gap = ThemeCGFloatPicker(stringLiteral: "alerts.spacing.gap.value")
        }

        public enum borderRadius {
            /// Type: borderRadius
            public static let standard = ThemeCGFloatPicker(stringLiteral: "alerts.borderRadius.standard.value")
            /// Type: borderRadius
            public static let inCard = ThemeCGFloatPicker(stringLiteral: "alerts.borderRadius.inCard.value")
        }

        /// Type: typography
        public static let font = ThemeAnyPicker(keyPath: "alerts.font.value")
        public static let fontAttributedText = ThemeStringAttributesPicker(keyPath: "alerts.font.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        public enum color {
            /// Type: color
            public static let font = ThemeColorPicker(stringLiteral: "alerts.color.font.value")
            public static let fontCGColor = ThemeCGColorPicker(stringLiteral: "alerts.color.font.value")
            public enum bg {
                public enum container {
                    /// Type: color
                    public static let alert = ThemeColorPicker(stringLiteral: "alerts.color.bg.container.alert.value")
                    public static let alertCGColor = ThemeCGColorPicker(stringLiteral: "alerts.color.bg.container.alert.value")
                    /// Type: color
                    public static let informational = ThemeColorPicker(stringLiteral: "alerts.color.bg.container.informational.value")
                    public static let informationalCGColor = ThemeCGColorPicker(stringLiteral: "alerts.color.bg.container.informational.value")
                    /// Type: color
                    public static let promotional = ThemeColorPicker(stringLiteral: "alerts.color.bg.container.promotional.value")
                    public static let promotionalCGColor = ThemeCGColorPicker(stringLiteral: "alerts.color.bg.container.promotional.value")
                }
            }

            /// Type: color
            public static let actionIcon = ThemeColorPicker(stringLiteral: "alerts.color.actionIcon.value")
            public static let actionIconCGColor = ThemeCGColorPicker(stringLiteral: "alerts.color.actionIcon.value")
            public enum statusIcon {
                /// Type: color
                public static let highAlert = ThemeColorPicker(stringLiteral: "alerts.color.statusIcon.highAlert.value")
                public static let highAlertCGColor = ThemeCGColorPicker(stringLiteral: "alerts.color.statusIcon.highAlert.value")
                /// Type: color
                public static let lowAlert = ThemeColorPicker(stringLiteral: "alerts.color.statusIcon.lowAlert.value")
                public static let lowAlertCGColor = ThemeCGColorPicker(stringLiteral: "alerts.color.statusIcon.lowAlert.value")
                /// Type: color
                public static let informational = ThemeColorPicker(stringLiteral: "alerts.color.statusIcon.informational.value")
                public static let informationalCGColor = ThemeCGColorPicker(stringLiteral: "alerts.color.statusIcon.informational.value")
                /// Type: color
                public static let promotional = ThemeColorPicker(stringLiteral: "alerts.color.statusIcon.promotional.value")
                public static let promotionalCGColor = ThemeCGColorPicker(stringLiteral: "alerts.color.statusIcon.promotional.value")
            }
        }

        public enum infoIcon {
            /// Type: other
            public static let iconRendering = ThemeAnyPicker(keyPath: "alerts.infoIcon.iconRendering.value")
        }
    }

    public enum dividers {
        public enum color {
            public enum bg {
                /// Type: color
                public static let thin = ThemeColorPicker(stringLiteral: "dividers.color.bg.thin.value")
                public static let thinCGColor = ThemeCGColorPicker(stringLiteral: "dividers.color.bg.thin.value")
                /// Type: color
                public static let thick = ThemeColorPicker(stringLiteral: "dividers.color.bg.thick.value")
                public static let thickCGColor = ThemeCGColorPicker(stringLiteral: "dividers.color.bg.thick.value")
            }
        }

        public enum size {
            /// Type: sizing
            public static let thick = ThemeCGFloatPicker(stringLiteral: "dividers.size.thick.value")
        }
    }

    public enum control {
        public enum on {
            public enum color {
                public enum bg {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "control.on.color.bg.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "control.on.color.bg.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "control.on.color.bg.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "control.on.color.bg.disabled.value")
                }

                public enum icon {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "control.on.color.icon.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "control.on.color.icon.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "control.on.color.icon.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "control.on.color.icon.disabled.value")
                }
            }
        }

        public enum off {
            public enum color {
                public enum border {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "control.off.color.border.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "control.off.color.border.default.value")
                    /// Type: color
                    public static let error = ThemeColorPicker(stringLiteral: "control.off.color.border.error.value")
                    public static let errorCGColor = ThemeCGColorPicker(stringLiteral: "control.off.color.border.error.value")
                }

                public enum bg {
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "control.off.color.bg.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "control.off.color.bg.disabled.value")
                }
            }
        }

        /// Type: boxShadow
        public static let elevation = ThemeAnyPicker(keyPath: "control.elevation.value")
        public enum color {
            public enum label {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "control.color.label.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "control.color.label.default.value")
                /// Type: color
                public static let disabled = ThemeColorPicker(stringLiteral: "control.color.label.disabled.value")
                public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "control.color.label.disabled.value")
            }

            public enum description {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "control.color.description.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "control.color.description.default.value")
                /// Type: color
                public static let disabled = ThemeColorPicker(stringLiteral: "control.color.description.disabled.value")
                public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "control.color.description.disabled.value")
            }
        }

        public enum font {
            public enum label {
                /// Type: typography
                public static let s = ThemeAnyPicker(keyPath: "control.font.label.s.value")
                public static let sAttributedText = ThemeStringAttributesPicker(keyPath: "control.font.label.s.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let xs = ThemeAnyPicker(keyPath: "control.font.label.xs.value")
                public static let xsAttributedText = ThemeStringAttributesPicker(keyPath: "control.font.label.xs.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            public enum description {
                /// Type: typography
                public static let s = ThemeAnyPicker(keyPath: "control.font.description.s.value")
                public static let sAttributedText = ThemeStringAttributesPicker(keyPath: "control.font.description.s.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let xs = ThemeAnyPicker(keyPath: "control.font.description.xs.value")
                public static let xsAttributedText = ThemeStringAttributesPicker(keyPath: "control.font.description.xs.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }
        }

        public enum spacing {
            public enum horizontal {
                /// Type: spacing
                public static let label = ThemeCGFloatPicker(stringLiteral: "control.spacing.horizontal.label.value")
                /// Type: spacing
                public static let column = ThemeCGFloatPicker(stringLiteral: "control.spacing.horizontal.column.value")
            }

            public enum vertical {
                /// Type: spacing
                public static let description = ThemeCGFloatPicker(stringLiteral: "control.spacing.vertical.description.value")
                /// Type: spacing
                public static let status = ThemeCGFloatPicker(stringLiteral: "control.spacing.vertical.status.value")
                /// Type: spacing
                public static let row = ThemeCGFloatPicker(stringLiteral: "control.spacing.vertical.row.value")
            }
        }
    }

    public enum tabs {
        public enum color {
            public enum text {
                /// Type: color
                public static let selected = ThemeColorPicker(stringLiteral: "tabs.color.text.selected.value")
                public static let selectedCGColor = ThemeCGColorPicker(stringLiteral: "tabs.color.text.selected.value")
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "tabs.color.text.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "tabs.color.text.default.value")
                /// Type: color
                public static let pill = ThemeColorPicker(stringLiteral: "tabs.color.text.pill.value")
                public static let pillCGColor = ThemeCGColorPicker(stringLiteral: "tabs.color.text.pill.value")
            }

            public enum bg {
                /// Type: color
                public static let selectedbar = ThemeColorPicker(stringLiteral: "tabs.color.bg.selectedbar.value")
                public static let selectedbarCGColor = ThemeCGColorPicker(stringLiteral: "tabs.color.bg.selectedbar.value")
                /// Type: color
                public static let pill = ThemeColorPicker(stringLiteral: "tabs.color.bg.pill.value")
                public static let pillCGColor = ThemeCGColorPicker(stringLiteral: "tabs.color.bg.pill.value")
            }
        }

        public enum font {
            /// Type: typography
            public static let large = ThemeAnyPicker(keyPath: "tabs.font.large.value")
            public static let largeAttributedText = ThemeStringAttributesPicker(keyPath: "tabs.font.large.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let medium = ThemeAnyPicker(keyPath: "tabs.font.medium.value")
            public static let mediumAttributedText = ThemeStringAttributesPicker(keyPath: "tabs.font.medium.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            public enum compact {
                /// Type: typography
                public static let selected = ThemeAnyPicker(keyPath: "tabs.font.compact.selected.value")
                public static let selectedAttributedText = ThemeStringAttributesPicker(keyPath: "tabs.font.compact.selected.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let defaultValue = ThemeAnyPicker(keyPath: "tabs.font.compact.default.value")
                public static let defaultValueAttributedText = ThemeStringAttributesPicker(keyPath: "tabs.font.compact.default.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }
        }

        public enum spacing {
            /// Type: spacing
            public static let vertical = ThemeCGFloatPicker(stringLiteral: "tabs.spacing.vertical.value")
            /// Type: spacing
            public static let horizontal = ThemeCGFloatPicker(stringLiteral: "tabs.spacing.horizontal.value")
            /// Type: spacing
            public static let gap = ThemeCGFloatPicker(stringLiteral: "tabs.spacing.gap.value")
        }

        public enum compact {
            /// Type: spacing
            public static let horizontal = ThemeCGFloatPicker(stringLiteral: "tabs.compact.horizontal.value")
            /// Type: spacing
            public static let gap = ThemeCGFloatPicker(stringLiteral: "tabs.compact.gap.value")
            /// Type: spacing
            public static let bar = ThemeCGFloatPicker(stringLiteral: "tabs.compact.bar.value")
        }

        public enum pill {
            /// Type: spacing
            public static let vertical = ThemeCGFloatPicker(stringLiteral: "tabs.pill.vertical.value")
            /// Type: spacing
            public static let horizontal = ThemeCGFloatPicker(stringLiteral: "tabs.pill.horizontal.value")
            /// Type: spacing
            public static let inBetween = ThemeCGFloatPicker(stringLiteral: "tabs.pill.inBetween.value")
            public enum container {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "tabs.pill.container.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "tabs.pill.container.horizontal.value")
            }
        }
    }

    public enum pagetitle {
        public enum spacing {
            public enum gap {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "pagetitle.spacing.gap.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "pagetitle.spacing.gap.horizontal.value")
            }

            public enum vertical {
                /// Type: spacing
                public static let l = ThemeCGFloatPicker(stringLiteral: "pagetitle.spacing.vertical.l.value")
                /// Type: spacing
                public static let m = ThemeCGFloatPicker(stringLiteral: "pagetitle.spacing.vertical.m.value")
                /// Type: spacing
                public static let s = ThemeCGFloatPicker(stringLiteral: "pagetitle.spacing.vertical.s.value")
                /// Type: spacing
                public static let xl = ThemeCGFloatPicker(stringLiteral: "pagetitle.spacing.vertical.xl.value")
            }
        }

        public enum font {
            public enum header {
                /// Type: typography
                public static let large = ThemeAnyPicker(keyPath: "pagetitle.font.header.large.value")
                public static let largeAttributedText = ThemeStringAttributesPicker(keyPath: "pagetitle.font.header.large.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let medium = ThemeAnyPicker(keyPath: "pagetitle.font.header.medium.value")
                public static let mediumAttributedText = ThemeStringAttributesPicker(keyPath: "pagetitle.font.header.medium.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let small = ThemeAnyPicker(keyPath: "pagetitle.font.header.small.value")
                public static let smallAttributedText = ThemeStringAttributesPicker(keyPath: "pagetitle.font.header.small.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let eyebrow = ThemeAnyPicker(keyPath: "pagetitle.font.header.eyebrow.value")
                public static let eyebrowAttributedText = ThemeStringAttributesPicker(keyPath: "pagetitle.font.header.eyebrow.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            /// Type: typography
            public static let description = ThemeAnyPicker(keyPath: "pagetitle.font.description.value")
            public static let descriptionAttributedText = ThemeStringAttributesPicker(keyPath: "pagetitle.font.description.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }

        public enum color {
            public enum text {
                /// Type: color
                public static let header = ThemeColorPicker(stringLiteral: "pagetitle.color.text.header.value")
                public static let headerCGColor = ThemeCGColorPicker(stringLiteral: "pagetitle.color.text.header.value")
                /// Type: color
                public static let description = ThemeColorPicker(stringLiteral: "pagetitle.color.text.description.value")
                public static let descriptionCGColor = ThemeCGColorPicker(stringLiteral: "pagetitle.color.text.description.value")
                /// Type: color
                public static let eyebrow = ThemeColorPicker(stringLiteral: "pagetitle.color.text.eyebrow.value")
                public static let eyebrowCGColor = ThemeCGColorPicker(stringLiteral: "pagetitle.color.text.eyebrow.value")
            }
        }
    }

    public enum navigation {
        public enum bottom {
            /// Type: typography
            public static let font = ThemeAnyPicker(keyPath: "navigation.bottom.font.value")
            public static let fontAttributedText = ThemeStringAttributesPicker(keyPath: "navigation.bottom.font.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            public enum color {
                public enum icon {
                    /// Type: color
                    public static let on = ThemeColorPicker(stringLiteral: "navigation.bottom.color.icon.on.value")
                    public static let onCGColor = ThemeCGColorPicker(stringLiteral: "navigation.bottom.color.icon.on.value")
                    /// Type: color
                    public static let off = ThemeColorPicker(stringLiteral: "navigation.bottom.color.icon.off.value")
                    public static let offCGColor = ThemeCGColorPicker(stringLiteral: "navigation.bottom.color.icon.off.value")
                }

                public enum text {
                    /// Type: color
                    public static let on = ThemeColorPicker(stringLiteral: "navigation.bottom.color.text.on.value")
                    public static let onCGColor = ThemeCGColorPicker(stringLiteral: "navigation.bottom.color.text.on.value")
                    /// Type: color
                    public static let off = ThemeColorPicker(stringLiteral: "navigation.bottom.color.text.off.value")
                    public static let offCGColor = ThemeCGColorPicker(stringLiteral: "navigation.bottom.color.text.off.value")
                }

                public enum bg {
                    /// Type: color
                    public static let container = ThemeColorPicker(stringLiteral: "navigation.bottom.color.bg.container.value")
                    public static let containerCGColor = ThemeCGColorPicker(stringLiteral: "navigation.bottom.color.bg.container.value")
                }
            }

            public enum borderWidth {
                /// Type: borderWidth
                public static let featured = ThemeCGFloatPicker(stringLiteral: "navigation.bottom.borderWidth.featured.value")
            }

            public enum spacing {
                public enum gap {
                    /// Type: spacing
                    public static let defaultValue = ThemeCGFloatPicker(stringLiteral: "navigation.bottom.spacing.gap.default.value")
                }

                public enum vertical {
                    /// Type: spacing
                    public static let bottom = ThemeCGFloatPicker(stringLiteral: "navigation.bottom.spacing.vertical.bottom.value")
                    /// Type: spacing
                    public static let top = ThemeCGFloatPicker(stringLiteral: "navigation.bottom.spacing.vertical.top.value")
                }
            }

            public enum size {
                /// Type: sizing
                public static let featured = ThemeCGFloatPicker(stringLiteral: "navigation.bottom.size.featured.value")
            }
        }

        public enum top {
            public enum standard {
                public enum color {
                    public enum icon {
                        /// Type: color
                        public static let onLight = ThemeColorPicker(stringLiteral: "navigation.top.standard.color.icon.onLight.value")
                        public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "navigation.top.standard.color.icon.onLight.value")
                        /// Type: color
                        public static let onDark = ThemeColorPicker(stringLiteral: "navigation.top.standard.color.icon.onDark.value")
                        public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "navigation.top.standard.color.icon.onDark.value")
                    }

                    public enum text {
                        /// Type: color
                        public static let onLight = ThemeColorPicker(stringLiteral: "navigation.top.standard.color.text.onLight.value")
                        public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "navigation.top.standard.color.text.onLight.value")
                        /// Type: color
                        public static let onDark = ThemeColorPicker(stringLiteral: "navigation.top.standard.color.text.onDark.value")
                        public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "navigation.top.standard.color.text.onDark.value")
                    }

                    /// Type: color
                    public static let container = ThemeColorPicker(stringLiteral: "navigation.top.standard.color.container.value")
                    public static let containerCGColor = ThemeCGColorPicker(stringLiteral: "navigation.top.standard.color.container.value")
                }

                public enum spacing {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "navigation.top.standard.spacing.vertical.value")
                    /// Type: spacing
                    public static let horizontal = ThemeCGFloatPicker(stringLiteral: "navigation.top.standard.spacing.horizontal.value")
                    public enum gap {
                        /// Type: spacing
                        public static let defaultValue = ThemeCGFloatPicker(stringLiteral: "navigation.top.standard.spacing.gap.default.value")
                        /// Type: spacing
                        public static let icon = ThemeCGFloatPicker(stringLiteral: "navigation.top.standard.spacing.gap.icon.value")
                    }
                }

                /// Type: typography
                public static let font = ThemeAnyPicker(keyPath: "navigation.top.standard.font.value")
                public static let fontAttributedText = ThemeStringAttributesPicker(keyPath: "navigation.top.standard.font.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            public enum search {
                public enum spacing {
                    public enum vertical {
                        /// Type: spacing
                        public static let top = ThemeCGFloatPicker(stringLiteral: "navigation.top.search.spacing.vertical.top.value")
                        /// Type: spacing
                        public static let bottom = ThemeCGFloatPicker(stringLiteral: "navigation.top.search.spacing.vertical.bottom.value")
                    }

                    /// Type: spacing
                    public static let horizontal = ThemeCGFloatPicker(stringLiteral: "navigation.top.search.spacing.horizontal.value")
                }
            }
        }
    }

    public enum search {
        public enum color {
            public enum text {
                public enum input {
                    /// Type: color
                    public static let onDark = ThemeColorPicker(stringLiteral: "search.color.text.input.onDark.value")
                    public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "search.color.text.input.onDark.value")
                    /// Type: color
                    public static let onLight = ThemeColorPicker(stringLiteral: "search.color.text.input.onLight.value")
                    public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "search.color.text.input.onLight.value")
                }

                public enum placeholder {
                    /// Type: color
                    public static let onDark = ThemeColorPicker(stringLiteral: "search.color.text.placeholder.onDark.value")
                    public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "search.color.text.placeholder.onDark.value")
                    /// Type: color
                    public static let onLight = ThemeColorPicker(stringLiteral: "search.color.text.placeholder.onLight.value")
                    public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "search.color.text.placeholder.onLight.value")
                }
            }

            public enum icon {
                /// Type: color
                public static let onLight = ThemeColorPicker(stringLiteral: "search.color.icon.onLight.value")
                public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "search.color.icon.onLight.value")
                /// Type: color
                public static let onDark = ThemeColorPicker(stringLiteral: "search.color.icon.onDark.value")
                public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "search.color.icon.onDark.value")
            }

            public enum container {
                /// Type: color
                public static let onLight = ThemeColorPicker(stringLiteral: "search.color.container.onLight.value")
                public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "search.color.container.onLight.value")
                /// Type: color
                public static let onDark = ThemeColorPicker(stringLiteral: "search.color.container.onDark.value")
                public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "search.color.container.onDark.value")
            }

            public enum border {
                /// Type: color
                public static let onLight = ThemeColorPicker(stringLiteral: "search.color.border.onLight.value")
                public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "search.color.border.onLight.value")
                /// Type: color
                public static let onDark = ThemeColorPicker(stringLiteral: "search.color.border.onDark.value")
                public static let onDarkCGColor = ThemeCGColorPicker(stringLiteral: "search.color.border.onDark.value")
            }
        }

        public enum font {
            /// Type: typography
            public static let input = ThemeAnyPicker(keyPath: "search.font.input.value")
            public static let inputAttributedText = ThemeStringAttributesPicker(keyPath: "search.font.input.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let placeholder = ThemeAnyPicker(keyPath: "search.font.placeholder.value")
            public static let placeholderAttributedText = ThemeStringAttributesPicker(keyPath: "search.font.placeholder.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }

        public enum spacing {
            public enum searchBar {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "search.spacing.searchBar.horizontal.value")
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "search.spacing.searchBar.vertical.value")
            }
        }

        public enum gap {
            /// Type: spacing
            public static let horizontal = ThemeCGFloatPicker(stringLiteral: "search.gap.horizontal.value")
            /// Type: spacing
            public static let searchIcon = ThemeCGFloatPicker(stringLiteral: "search.gap.searchIcon.value")
            /// Type: spacing
            public static let searchBar = ThemeCGFloatPicker(stringLiteral: "search.gap.searchBar.value")
        }

        /// Type: borderRadius
        public static let borderRadius = ThemeCGFloatPicker(stringLiteral: "search.borderRadius.value")
    }

    public enum quickactionbar {
        public enum spacing {
            /// Type: spacing
            public static let gap = ThemeCGFloatPicker(stringLiteral: "quickactionbar.spacing.gap.value")
            /// Type: spacing
            public static let horizontal = ThemeCGFloatPicker(stringLiteral: "quickactionbar.spacing.horizontal.value")
            /// Type: spacing
            public static let vertical = ThemeCGFloatPicker(stringLiteral: "quickactionbar.spacing.vertical.value")
        }

        /// Type: typography
        public static let font = ThemeAnyPicker(keyPath: "quickactionbar.font.value")
        public static let fontAttributedText = ThemeStringAttributesPicker(keyPath: "quickactionbar.font.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        public enum color {
            public enum icon {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "quickactionbar.color.icon.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "quickactionbar.color.icon.default.value")
                /// Type: color
                public static let disabled = ThemeColorPicker(stringLiteral: "quickactionbar.color.icon.disabled.value")
                public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "quickactionbar.color.icon.disabled.value")
            }

            public enum text {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "quickactionbar.color.text.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "quickactionbar.color.text.default.value")
                /// Type: color
                public static let disabled = ThemeColorPicker(stringLiteral: "quickactionbar.color.text.disabled.value")
                public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "quickactionbar.color.text.disabled.value")
            }
        }
    }

    public enum textFields {
        public enum font {
            /// Type: typography
            public static let input = ThemeAnyPicker(keyPath: "textFields.font.input.value")
            public static let inputAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.font.input.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let placeholder = ThemeAnyPicker(keyPath: "textFields.font.placeholder.value")
            public static let placeholderAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.font.placeholder.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let counter = ThemeAnyPicker(keyPath: "textFields.font.counter.value")
            public static let counterAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.font.counter.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let helper = ThemeAnyPicker(keyPath: "textFields.font.helper.value")
            public static let helperAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.font.helper.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let error = ThemeAnyPicker(keyPath: "textFields.font.error.value")
            public static let errorAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.font.error.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            public enum label {
                /// Type: typography
                public static let defaultValue = ThemeAnyPicker(keyPath: "textFields.font.label.default.value")
                public static let defaultValueAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.font.label.default.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let focused = ThemeAnyPicker(keyPath: "textFields.font.label.focused.value")
                public static let focusedAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.font.label.focused.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            /// Type: typography
            public static let presuffix = ThemeAnyPicker(keyPath: "textFields.font.presuffix.value")
            public static let presuffixAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.font.presuffix.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }

        public enum color {
            public enum text {
                public enum label {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "textFields.color.text.label.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.text.label.default.value")
                    /// Type: color
                    public static let focused = ThemeColorPicker(stringLiteral: "textFields.color.text.label.focused.value")
                    public static let focusedCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.text.label.focused.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "textFields.color.text.label.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.text.label.disabled.value")
                }

                public enum input {
                    /// Type: color
                    public static let focused = ThemeColorPicker(stringLiteral: "textFields.color.text.input.focused.value")
                    public static let focusedCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.text.input.focused.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "textFields.color.text.input.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.text.input.disabled.value")
                }

                /// Type: color
                public static let placeholder = ThemeColorPicker(stringLiteral: "textFields.color.text.placeholder.value")
                public static let placeholderCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.text.placeholder.value")
                public enum counter {
                    /// Type: color
                    public static let focused = ThemeColorPicker(stringLiteral: "textFields.color.text.counter.focused.value")
                    public static let focusedCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.text.counter.focused.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "textFields.color.text.counter.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.text.counter.disabled.value")
                }

                public enum helper {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "textFields.color.text.helper.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.text.helper.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "textFields.color.text.helper.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.text.helper.disabled.value")
                }

                /// Type: color
                public static let error = ThemeColorPicker(stringLiteral: "textFields.color.text.error.value")
                public static let errorCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.text.error.value")
                /// Type: color
                public static let success = ThemeColorPicker(stringLiteral: "textFields.color.text.success.value")
                public static let successCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.text.success.value")
                public enum preSuffix {
                    /// Type: color
                    public static let focused = ThemeColorPicker(stringLiteral: "textFields.color.text.preSuffix.focused.value")
                    public static let focusedCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.text.preSuffix.focused.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "textFields.color.text.preSuffix.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.text.preSuffix.disabled.value")
                }
            }

            public enum icon {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "textFields.color.icon.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.icon.default.value")
                /// Type: color
                public static let disabled = ThemeColorPicker(stringLiteral: "textFields.color.icon.disabled.value")
                public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.icon.disabled.value")
            }

            public enum underline {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "textFields.color.underline.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.underline.default.value")
                /// Type: color
                public static let focused = ThemeColorPicker(stringLiteral: "textFields.color.underline.focused.value")
                public static let focusedCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.underline.focused.value")
                /// Type: color
                public static let disabled = ThemeColorPicker(stringLiteral: "textFields.color.underline.disabled.value")
                public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.underline.disabled.value")
                /// Type: color
                public static let error = ThemeColorPicker(stringLiteral: "textFields.color.underline.error.value")
                public static let errorCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.underline.error.value")
                /// Type: color
                public static let success = ThemeColorPicker(stringLiteral: "textFields.color.underline.success.value")
                public static let successCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.underline.success.value")
            }

            public enum button {
                /// Type: color
                public static let inactive = ThemeColorPicker(stringLiteral: "textFields.color.button.inactive.value")
                public static let inactiveCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.button.inactive.value")
                public enum icon {
                    /// Type: color
                    public static let inactive = ThemeColorPicker(stringLiteral: "textFields.color.button.icon.inactive.value")
                    public static let inactiveCGColor = ThemeCGColorPicker(stringLiteral: "textFields.color.button.icon.inactive.value")
                }
            }
        }

        public enum filled {
            public enum color {
                public enum container {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "textFields.filled.color.container.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "textFields.filled.color.container.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "textFields.filled.color.container.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "textFields.filled.color.container.disabled.value")
                }
            }

            public enum borderRadius {
                /// Type: borderRadius
                public static let top = ThemeCGFloatPicker(stringLiteral: "textFields.filled.borderRadius.top.value")
                /// Type: borderRadius
                public static let btm = ThemeCGFloatPicker(stringLiteral: "textFields.filled.borderRadius.btm.value")
            }
        }

        public enum spacing {
            public enum vertical {
                /// Type: spacing
                public static let defaultValue = ThemeCGFloatPicker(stringLiteral: "textFields.spacing.vertical.default.value")
                public enum bottom {
                    /// Type: spacing
                    public static let focused = ThemeCGFloatPicker(stringLiteral: "textFields.spacing.vertical.bottom.focused.value")
                }

                public enum top {
                    /// Type: spacing
                    public static let focused = ThemeCGFloatPicker(stringLiteral: "textFields.spacing.vertical.top.focused.value")
                }
            }

            public enum horizontal {
                /// Type: spacing
                public static let defaultValue = ThemeCGFloatPicker(stringLiteral: "textFields.spacing.horizontal.default.value")
                /// Type: spacing
                public static let focused = ThemeCGFloatPicker(stringLiteral: "textFields.spacing.horizontal.focused.value")
            }

            public enum gap {
                /// Type: spacing
                public static let focused = ThemeCGFloatPicker(stringLiteral: "textFields.spacing.gap.focused.value")
                /// Type: spacing
                public static let scrollbar = ThemeCGFloatPicker(stringLiteral: "textFields.spacing.gap.scrollbar.value")
                public enum suffix {
                    /// Type: spacing
                    public static let s = ThemeCGFloatPicker(stringLiteral: "textFields.spacing.gap.suffix.s.value")
                    /// Type: spacing
                    public static let m = ThemeCGFloatPicker(stringLiteral: "textFields.spacing.gap.suffix.m.value")
                }

                /// Type: spacing
                public static let fields = ThemeCGFloatPicker(stringLiteral: "textFields.spacing.gap.fields.value")
            }

            public enum helper {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "textFields.spacing.helper.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "textFields.spacing.helper.horizontal.value")
            }
        }

        public enum borderWidth {
            /// Type: borderWidth
            public static let underline = ThemeCGFloatPicker(stringLiteral: "textFields.borderWidth.underline.value")
        }

        public enum amount {
            public enum small {
                public enum font {
                    public enum input {
                        /// Type: typography
                        public static let defaultValue = ThemeAnyPicker(keyPath: "textFields.amount.small.font.input.default.value")
                        public static let defaultValueAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.amount.small.font.input.default.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                        /// Type: typography
                        public static let med = ThemeAnyPicker(keyPath: "textFields.amount.small.font.input.med.value")
                        public static let medAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.amount.small.font.input.med.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                        /// Type: typography
                        public static let min = ThemeAnyPicker(keyPath: "textFields.amount.small.font.input.min.value")
                        public static let minAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.amount.small.font.input.min.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                    }

                    public enum placeholder {
                        /// Type: typography
                        public static let defaultValue = ThemeAnyPicker(keyPath: "textFields.amount.small.font.placeholder.default.value")
                        public static let defaultValueAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.amount.small.font.placeholder.default.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                        /// Type: typography
                        public static let med = ThemeAnyPicker(keyPath: "textFields.amount.small.font.placeholder.med.value")
                        public static let medAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.amount.small.font.placeholder.med.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                        /// Type: typography
                        public static let min = ThemeAnyPicker(keyPath: "textFields.amount.small.font.placeholder.min.value")
                        public static let minAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.amount.small.font.placeholder.min.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                    }

                    /// Type: typography
                    public static let suffix = ThemeAnyPicker(keyPath: "textFields.amount.small.font.suffix.value")
                    public static let suffixAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.amount.small.font.suffix.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                }

                public enum gap {
                    /// Type: spacing
                    public static let dropdown = ThemeCGFloatPicker(stringLiteral: "textFields.amount.small.gap.dropdown.value")
                    /// Type: spacing
                    public static let flag = ThemeCGFloatPicker(stringLiteral: "textFields.amount.small.gap.flag.value")
                    /// Type: spacing
                    public static let input = ThemeCGFloatPicker(stringLiteral: "textFields.amount.small.gap.input.value")
                }
            }

            public enum big {
                public enum font {
                    public enum input {
                        /// Type: typography
                        public static let defaultValue = ThemeAnyPicker(keyPath: "textFields.amount.big.font.input.default.value")
                        public static let defaultValueAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.amount.big.font.input.default.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                        /// Type: typography
                        public static let med = ThemeAnyPicker(keyPath: "textFields.amount.big.font.input.med.value")
                        public static let medAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.amount.big.font.input.med.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                        /// Type: typography
                        public static let min = ThemeAnyPicker(keyPath: "textFields.amount.big.font.input.min.value")
                        public static let minAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.amount.big.font.input.min.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                    }

                    public enum placeholder {
                        /// Type: typography
                        public static let defaultValue = ThemeAnyPicker(keyPath: "textFields.amount.big.font.placeholder.default.value")
                        public static let defaultValueAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.amount.big.font.placeholder.default.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                        /// Type: typography
                        public static let med = ThemeAnyPicker(keyPath: "textFields.amount.big.font.placeholder.med.value")
                        public static let medAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.amount.big.font.placeholder.med.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                        /// Type: typography
                        public static let min = ThemeAnyPicker(keyPath: "textFields.amount.big.font.placeholder.min.value")
                        public static let minAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.amount.big.font.placeholder.min.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                    }

                    /// Type: typography
                    public static let suffix = ThemeAnyPicker(keyPath: "textFields.amount.big.font.suffix.value")
                    public static let suffixAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.amount.big.font.suffix.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                    /// Type: typography
                    public static let helper = ThemeAnyPicker(keyPath: "textFields.amount.big.font.helper.value")
                    public static let helperAttributedText = ThemeStringAttributesPicker(keyPath: "textFields.amount.big.font.helper.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                }

                public enum spacing {
                    /// Type: spacing
                    public static let gap = ThemeCGFloatPicker(stringLiteral: "textFields.amount.big.spacing.gap.value")
                    public enum description {
                        /// Type: spacing
                        public static let vertical = ThemeCGFloatPicker(stringLiteral: "textFields.amount.big.spacing.description.vertical.value")
                    }
                }

                public enum gap {
                    /// Type: spacing
                    public static let description = ThemeCGFloatPicker(stringLiteral: "textFields.amount.big.gap.description.value")
                    /// Type: spacing
                    public static let dropdown = ThemeCGFloatPicker(stringLiteral: "textFields.amount.big.gap.dropdown.value")
                    /// Type: spacing
                    public static let flag = ThemeCGFloatPicker(stringLiteral: "textFields.amount.big.gap.flag.value")
                    /// Type: spacing
                    public static let input = ThemeCGFloatPicker(stringLiteral: "textFields.amount.big.gap.input.value")
                }
            }
        }

        public enum dualAmount {
            public enum small {
                public enum gap {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "textFields.dualAmount.small.gap.vertical.value")
                }

                public enum spacing {
                    /// Type: spacing
                    public static let loaders = ThemeCGFloatPicker(stringLiteral: "textFields.dualAmount.small.spacing.loaders.value")
                }
            }

            public enum big {
                /// Type: sizing
                public static let divider = ThemeCGFloatPicker(stringLiteral: "textFields.dualAmount.big.divider.value")
                public enum spacing {
                    public enum top {
                        public enum vertical {
                            /// Type: spacing
                            public static let btm = ThemeCGFloatPicker(stringLiteral: "textFields.dualAmount.big.spacing.top.vertical.btm.value")
                            /// Type: spacing
                            public static let top = ThemeCGFloatPicker(stringLiteral: "textFields.dualAmount.big.spacing.top.vertical.top.value")
                        }
                    }

                    public enum btm {
                        public enum vertical {
                            /// Type: spacing
                            public static let top = ThemeCGFloatPicker(stringLiteral: "textFields.dualAmount.big.spacing.btm.vertical.top.value")
                            /// Type: spacing
                            public static let btm = ThemeCGFloatPicker(stringLiteral: "textFields.dualAmount.big.spacing.btm.vertical.btm.value")
                        }
                    }

                    /// Type: spacing
                    public static let loaders = ThemeCGFloatPicker(stringLiteral: "textFields.dualAmount.big.spacing.loaders.value")
                    /// Type: spacing
                    public static let horizontal = ThemeCGFloatPicker(stringLiteral: "textFields.dualAmount.big.spacing.horizontal.value")
                }
            }
        }
    }

    public enum datapoints {
        public enum font {
            public enum label {
                /// Type: typography
                public static let s = ThemeAnyPicker(keyPath: "datapoints.font.label.s.value")
                public static let sAttributedText = ThemeStringAttributesPicker(keyPath: "datapoints.font.label.s.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let xs = ThemeAnyPicker(keyPath: "datapoints.font.label.xs.value")
                public static let xsAttributedText = ThemeStringAttributesPicker(keyPath: "datapoints.font.label.xs.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            public enum details {
                /// Type: typography
                public static let xl = ThemeAnyPicker(keyPath: "datapoints.font.details.xl.value")
                public static let xlAttributedText = ThemeStringAttributesPicker(keyPath: "datapoints.font.details.xl.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let l = ThemeAnyPicker(keyPath: "datapoints.font.details.l.value")
                public static let lAttributedText = ThemeStringAttributesPicker(keyPath: "datapoints.font.details.l.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let m = ThemeAnyPicker(keyPath: "datapoints.font.details.m.value")
                public static let mAttributedText = ThemeStringAttributesPicker(keyPath: "datapoints.font.details.m.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let s = ThemeAnyPicker(keyPath: "datapoints.font.details.s.value")
                public static let sAttributedText = ThemeStringAttributesPicker(keyPath: "datapoints.font.details.s.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let xs = ThemeAnyPicker(keyPath: "datapoints.font.details.xs.value")
                public static let xsAttributedText = ThemeStringAttributesPicker(keyPath: "datapoints.font.details.xs.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let xxs = ThemeAnyPicker(keyPath: "datapoints.font.details.xxs.value")
                public static let xxsAttributedText = ThemeStringAttributesPicker(keyPath: "datapoints.font.details.xxs.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            /// Type: typography
            public static let description = ThemeAnyPicker(keyPath: "datapoints.font.description.value")
            public static let descriptionAttributedText = ThemeStringAttributesPicker(keyPath: "datapoints.font.description.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            public enum PnL {
                /// Type: typography
                public static let s = ThemeAnyPicker(keyPath: "datapoints.font.PnL.s.value")
                public static let sAttributedText = ThemeStringAttributesPicker(keyPath: "datapoints.font.PnL.s.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let xs = ThemeAnyPicker(keyPath: "datapoints.font.PnL.xs.value")
                public static let xsAttributedText = ThemeStringAttributesPicker(keyPath: "datapoints.font.PnL.xs.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }
        }

        public enum color {
            public enum text {
                /// Type: color
                public static let label = ThemeColorPicker(stringLiteral: "datapoints.color.text.label.value")
                public static let labelCGColor = ThemeCGColorPicker(stringLiteral: "datapoints.color.text.label.value")
                /// Type: color
                public static let details = ThemeColorPicker(stringLiteral: "datapoints.color.text.details.value")
                public static let detailsCGColor = ThemeCGColorPicker(stringLiteral: "datapoints.color.text.details.value")
                /// Type: color
                public static let description = ThemeColorPicker(stringLiteral: "datapoints.color.text.description.value")
                public static let descriptionCGColor = ThemeCGColorPicker(stringLiteral: "datapoints.color.text.description.value")
                /// Type: color
                public static let profit = ThemeColorPicker(stringLiteral: "datapoints.color.text.profit.value")
                public static let profitCGColor = ThemeCGColorPicker(stringLiteral: "datapoints.color.text.profit.value")
                /// Type: color
                public static let loss = ThemeColorPicker(stringLiteral: "datapoints.color.text.loss.value")
                public static let lossCGColor = ThemeCGColorPicker(stringLiteral: "datapoints.color.text.loss.value")
            }

            /// Type: color
            public static let icon = ThemeColorPicker(stringLiteral: "datapoints.color.icon.value")
            public static let iconCGColor = ThemeCGColorPicker(stringLiteral: "datapoints.color.icon.value")
            /// Type: color
            public static let emphasisbar = ThemeColorPicker(stringLiteral: "datapoints.color.emphasisbar.value")
            public static let emphasisbarCGColor = ThemeCGColorPicker(stringLiteral: "datapoints.color.emphasisbar.value")
        }

        public enum spacing {
            public enum gap {
                public enum vertical {
                    /// Type: spacing
                    public static let row = ThemeCGFloatPicker(stringLiteral: "datapoints.spacing.gap.vertical.row.value")
                    /// Type: spacing
                    public static let spacer = ThemeCGFloatPicker(stringLiteral: "datapoints.spacing.gap.vertical.spacer.value")
                }

                public enum horizontal {
                    /// Type: spacing
                    public static let details = ThemeCGFloatPicker(stringLiteral: "datapoints.spacing.gap.horizontal.details.value")
                    /// Type: spacing
                    public static let label = ThemeCGFloatPicker(stringLiteral: "datapoints.spacing.gap.horizontal.label.value")
                    /// Type: spacing
                    public static let column = ThemeCGFloatPicker(stringLiteral: "datapoints.spacing.gap.horizontal.column.value")
                    /// Type: spacing
                    public static let legend = ThemeCGFloatPicker(stringLiteral: "datapoints.spacing.gap.horizontal.legend.value")
                }
            }

            public enum padding {
                /// Type: spacing
                public static let label = ThemeCGFloatPicker(stringLiteral: "datapoints.spacing.padding.label.value")
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "datapoints.spacing.padding.vertical.value")
                /// Type: spacing
                public static let legend = ThemeCGFloatPicker(stringLiteral: "datapoints.spacing.padding.legend.value")
            }
        }

        /// Type: sizing
        public static let spacer = ThemeCGFloatPicker(stringLiteral: "datapoints.spacer.value")
    }

    public enum bottomSheet {
        public enum spacing {
            public enum swipeBar {
                public enum vertical {
                    /// Type: spacing
                    public static let top = ThemeCGFloatPicker(stringLiteral: "bottomSheet.spacing.swipeBar.vertical.top.value")
                    /// Type: spacing
                    public static let bottom = ThemeCGFloatPicker(stringLiteral: "bottomSheet.spacing.swipeBar.vertical.bottom.value")
                }
            }

            public enum cta {
                public enum standard {
                    public enum vertical {
                        /// Type: spacing
                        public static let top = ThemeCGFloatPicker(stringLiteral: "bottomSheet.spacing.cta.standard.vertical.top.value")
                        /// Type: spacing
                        public static let bottom = ThemeCGFloatPicker(stringLiteral: "bottomSheet.spacing.cta.standard.vertical.bottom.value")
                    }

                    /// Type: spacing
                    public static let horizontal = ThemeCGFloatPicker(stringLiteral: "bottomSheet.spacing.cta.standard.horizontal.value")
                }

                public enum sticky {
                    public enum vertical {
                        /// Type: spacing
                        public static let top = ThemeCGFloatPicker(stringLiteral: "bottomSheet.spacing.cta.sticky.vertical.top.value")
                        /// Type: spacing
                        public static let bottom = ThemeCGFloatPicker(stringLiteral: "bottomSheet.spacing.cta.sticky.vertical.bottom.value")
                    }

                    /// Type: spacing
                    public static let horizontal = ThemeCGFloatPicker(stringLiteral: "bottomSheet.spacing.cta.sticky.horizontal.value")
                }
            }

            public enum title {
                public enum noIcon {
                    /// Type: spacing
                    public static let horizontal = ThemeCGFloatPicker(stringLiteral: "bottomSheet.spacing.title.noIcon.horizontal.value")
                }

                public enum withIcon {
                    public enum horizontal {
                        /// Type: spacing
                        public static let left = ThemeCGFloatPicker(stringLiteral: "bottomSheet.spacing.title.withIcon.horizontal.left.value")
                        /// Type: spacing
                        public static let right = ThemeCGFloatPicker(stringLiteral: "bottomSheet.spacing.title.withIcon.horizontal.right.value")
                    }
                }

                public enum vertical {
                    /// Type: spacing
                    public static let bottom = ThemeCGFloatPicker(stringLiteral: "bottomSheet.spacing.title.vertical.bottom.value")
                }
            }

            public enum content {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "bottomSheet.spacing.content.horizontal.value")
                public enum vertical {
                    /// Type: spacing
                    public static let bottom = ThemeCGFloatPicker(stringLiteral: "bottomSheet.spacing.content.vertical.bottom.value")
                }

                public enum selection {
                    /// Type: spacing
                    public static let horizontal = ThemeCGFloatPicker(stringLiteral: "bottomSheet.spacing.content.selection.horizontal.value")
                }
            }
        }

        public enum gap {
            public enum title {
                public enum withIcon {
                    /// Type: spacing
                    public static let horizontal = ThemeCGFloatPicker(stringLiteral: "bottomSheet.gap.title.withIcon.horizontal.value")
                }
            }
        }

        public enum color {
            /// Type: color
            public static let container = ThemeColorPicker(stringLiteral: "bottomSheet.color.container.value")
            public static let containerCGColor = ThemeCGColorPicker(stringLiteral: "bottomSheet.color.container.value")
            /// Type: color
            public static let icon = ThemeColorPicker(stringLiteral: "bottomSheet.color.icon.value")
            public static let iconCGColor = ThemeCGColorPicker(stringLiteral: "bottomSheet.color.icon.value")
            /// Type: color
            public static let font = ThemeColorPicker(stringLiteral: "bottomSheet.color.font.value")
            public static let fontCGColor = ThemeCGColorPicker(stringLiteral: "bottomSheet.color.font.value")
            /// Type: color
            public static let swipeBar = ThemeColorPicker(stringLiteral: "bottomSheet.color.swipeBar.value")
            public static let swipeBarCGColor = ThemeCGColorPicker(stringLiteral: "bottomSheet.color.swipeBar.value")
        }

        public enum size {
            public enum swipeBar {
                /// Type: sizing
                public static let width = ThemeCGFloatPicker(stringLiteral: "bottomSheet.size.swipeBar.width.value")
                /// Type: sizing
                public static let height = ThemeCGFloatPicker(stringLiteral: "bottomSheet.size.swipeBar.height.value")
            }
        }

        public enum borderRadius {
            public enum container {
                /// Type: borderRadius
                public static let top = ThemeCGFloatPicker(stringLiteral: "bottomSheet.borderRadius.container.top.value")
                /// Type: borderRadius
                public static let bottom = ThemeCGFloatPicker(stringLiteral: "bottomSheet.borderRadius.container.bottom.value")
            }

            /// Type: borderRadius
            public static let swipeBar = ThemeCGFloatPicker(stringLiteral: "bottomSheet.borderRadius.swipeBar.value")
        }

        public enum font {
            /// Type: typography
            public static let content = ThemeAnyPicker(keyPath: "bottomSheet.font.content.value")
            public static let contentAttributedText = ThemeStringAttributesPicker(keyPath: "bottomSheet.font.content.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }
    }

    public enum cards {
        public enum boxShadow {
            public enum content {
                /// Type: boxShadow
                public static let high = ThemeAnyPicker(keyPath: "cards.boxShadow.content.high.value")
                /// Type: boxShadow
                public static let low = ThemeAnyPicker(keyPath: "cards.boxShadow.content.low.value")
            }

            /// Type: boxShadow
            public static let base = ThemeAnyPicker(keyPath: "cards.boxShadow.base.value")
        }

        public enum color {
            public enum fill {
                /// Type: color
                public static let high = ThemeColorPicker(stringLiteral: "cards.color.fill.high.value")
                public static let highCGColor = ThemeCGColorPicker(stringLiteral: "cards.color.fill.high.value")
                /// Type: color
                public static let low = ThemeColorPicker(stringLiteral: "cards.color.fill.low.value")
                public static let lowCGColor = ThemeCGColorPicker(stringLiteral: "cards.color.fill.low.value")
            }

            /// Type: color
            public static let icon = ThemeColorPicker(stringLiteral: "cards.color.icon.value")
            public static let iconCGColor = ThemeCGColorPicker(stringLiteral: "cards.color.icon.value")
            public enum insightsCard {
                public enum text {
                    /// Type: color
                    public static let body = ThemeColorPicker(stringLiteral: "cards.color.insightsCard.text.body.value")
                    public static let bodyCGColor = ThemeCGColorPicker(stringLiteral: "cards.color.insightsCard.text.body.value")
                    /// Type: color
                    public static let title = ThemeColorPicker(stringLiteral: "cards.color.insightsCard.text.title.value")
                    public static let titleCGColor = ThemeCGColorPicker(stringLiteral: "cards.color.insightsCard.text.title.value")
                    /// Type: color
                    public static let eyebrow = ThemeColorPicker(stringLiteral: "cards.color.insightsCard.text.eyebrow.value")
                    public static let eyebrowCGColor = ThemeCGColorPicker(stringLiteral: "cards.color.insightsCard.text.eyebrow.value")
                }
            }

            public enum actionCard {
                public enum text {
                    /// Type: color
                    public static let title = ThemeColorPicker(stringLiteral: "cards.color.actionCard.text.title.value")
                    public static let titleCGColor = ThemeCGColorPicker(stringLiteral: "cards.color.actionCard.text.title.value")
                    /// Type: color
                    public static let body = ThemeColorPicker(stringLiteral: "cards.color.actionCard.text.body.value")
                    public static let bodyCGColor = ThemeCGColorPicker(stringLiteral: "cards.color.actionCard.text.body.value")
                }
            }

            public enum productCard {
                /// Type: color
                public static let body = ThemeColorPicker(stringLiteral: "cards.color.productCard.body.value")
                public static let bodyCGColor = ThemeCGColorPicker(stringLiteral: "cards.color.productCard.body.value")
            }

            public enum selectionCard {
                public enum title {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "cards.color.selectionCard.title.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "cards.color.selectionCard.title.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "cards.color.selectionCard.title.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "cards.color.selectionCard.title.disabled.value")
                }

                public enum icon {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "cards.color.selectionCard.icon.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "cards.color.selectionCard.icon.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "cards.color.selectionCard.icon.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "cards.color.selectionCard.icon.disabled.value")
                }
            }
        }

        public enum font {
            public enum insightsCard {
                /// Type: typography
                public static let eyebrow = ThemeAnyPicker(keyPath: "cards.font.insightsCard.eyebrow.value")
                public static let eyebrowAttributedText = ThemeStringAttributesPicker(keyPath: "cards.font.insightsCard.eyebrow.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let title = ThemeAnyPicker(keyPath: "cards.font.insightsCard.title.value")
                public static let titleAttributedText = ThemeStringAttributesPicker(keyPath: "cards.font.insightsCard.title.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let body = ThemeAnyPicker(keyPath: "cards.font.insightsCard.body.value")
                public static let bodyAttributedText = ThemeStringAttributesPicker(keyPath: "cards.font.insightsCard.body.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            public enum actionCard {
                /// Type: typography
                public static let title = ThemeAnyPicker(keyPath: "cards.font.actionCard.title.value")
                public static let titleAttributedText = ThemeStringAttributesPicker(keyPath: "cards.font.actionCard.title.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let body = ThemeAnyPicker(keyPath: "cards.font.actionCard.body.value")
                public static let bodyAttributedText = ThemeStringAttributesPicker(keyPath: "cards.font.actionCard.body.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            public enum productCard {
                /// Type: typography
                public static let body = ThemeAnyPicker(keyPath: "cards.font.productCard.body.value")
                public static let bodyAttributedText = ThemeStringAttributesPicker(keyPath: "cards.font.productCard.body.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            public enum tiles {
                /// Type: typography
                public static let title = ThemeAnyPicker(keyPath: "cards.font.tiles.title.value")
                public static let titleAttributedText = ThemeStringAttributesPicker(keyPath: "cards.font.tiles.title.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let body = ThemeAnyPicker(keyPath: "cards.font.tiles.body.value")
                public static let bodyAttributedText = ThemeStringAttributesPicker(keyPath: "cards.font.tiles.body.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            public enum selectionCard {
                /// Type: typography
                public static let title = ThemeAnyPicker(keyPath: "cards.font.selectionCard.title.value")
                public static let titleAttributedText = ThemeStringAttributesPicker(keyPath: "cards.font.selectionCard.title.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }
        }

        public enum spacing {
            public enum insightCard {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "cards.spacing.insightCard.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "cards.spacing.insightCard.horizontal.value")
                public enum gap {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "cards.spacing.insightCard.gap.vertical.value")
                    /// Type: spacing
                    public static let horizontal = ThemeCGFloatPicker(stringLiteral: "cards.spacing.insightCard.gap.horizontal.value")
                }

                public enum carousel {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "cards.spacing.insightCard.carousel.vertical.value")
                    /// Type: spacing
                    public static let horizontal = ThemeCGFloatPicker(stringLiteral: "cards.spacing.insightCard.carousel.horizontal.value")
                }
            }
        }

        public enum actionCard {
            public enum spacing {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "cards.actionCard.spacing.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "cards.actionCard.spacing.horizontal.value")
            }

            public enum spacer {
                public enum content {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "cards.actionCard.spacer.content.vertical.value")
                }
            }

            public enum gap {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "cards.actionCard.gap.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "cards.actionCard.gap.horizontal.value")
                public enum datapoint {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "cards.actionCard.gap.datapoint.vertical.value")
                }
            }
        }

        public enum productCard {
            public enum spacing {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "cards.productCard.spacing.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "cards.productCard.spacing.horizontal.value")
            }

            public enum gap {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "cards.productCard.gap.horizontal.value")
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "cards.productCard.gap.vertical.value")
            }
        }

        public enum content {
            /// Type: borderRadius
            public static let borderRadius = ThemeCGFloatPicker(stringLiteral: "cards.content.borderRadius.value")
        }

        public enum base {
            public enum borderRadius {
                /// Type: borderRadius
                public static let top = ThemeCGFloatPicker(stringLiteral: "cards.base.borderRadius.top.value")
            }
        }

        public enum standard {
            /// Type: borderRadius
            public static let borderRadius = ThemeCGFloatPicker(stringLiteral: "cards.standard.borderRadius.value")
        }

        public enum tiles {
            public enum spacing {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "cards.tiles.spacing.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "cards.tiles.spacing.horizontal.value")
            }

            public enum gap {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "cards.tiles.gap.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "cards.tiles.gap.horizontal.value")
            }
        }

        public enum selectionCard {
            public enum spacing {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "cards.selectionCard.spacing.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "cards.selectionCard.spacing.horizontal.value")
            }

            /// Type: spacing
            public static let gap = ThemeCGFloatPicker(stringLiteral: "cards.selectionCard.gap.value")
        }

        public enum modular {
            public enum spacing {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "cards.modular.spacing.horizontal.value")
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "cards.modular.spacing.vertical.value")
                public enum content {
                    public enum vertical {
                        /// Type: spacing
                        public static let top = ThemeCGFloatPicker(stringLiteral: "cards.modular.spacing.content.vertical.top.value")
                    }
                }
            }

            public enum gap {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "cards.modular.gap.vertical.value")
                public enum content {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "cards.modular.gap.content.vertical.value")
                }
            }
        }
    }

    public enum tiles {
        public enum standard {
            /// Type: borderRadius
            public static let borderRadius = ThemeCGFloatPicker(stringLiteral: "tiles.standard.borderRadius.value")
            public enum color {
                public enum container {
                    public enum static {
                        /// Type: color
                        public static let variant1 = ThemeColorPicker(stringLiteral: "tiles.standard.color.container.static.variant1.value")
                        public static let variant1CGColor = ThemeCGColorPicker(stringLiteral: "tiles.standard.color.container.static.variant1.value")
                        /// Type: color
                        public static let variant2 = ThemeColorPicker(stringLiteral: "tiles.standard.color.container.static.variant2.value")
                        public static let variant2CGColor = ThemeCGColorPicker(stringLiteral: "tiles.standard.color.container.static.variant2.value")
                    }
                }

                public enum text {
                    /// Type: color
                    public static let headline = ThemeColorPicker(stringLiteral: "tiles.standard.color.text.headline.value")
                    public static let headlineCGColor = ThemeCGColorPicker(stringLiteral: "tiles.standard.color.text.headline.value")
                    /// Type: color
                    public static let body = ThemeColorPicker(stringLiteral: "tiles.standard.color.text.body.value")
                    public static let bodyCGColor = ThemeCGColorPicker(stringLiteral: "tiles.standard.color.text.body.value")
                    /// Type: color
                    public static let eyebrow = ThemeColorPicker(stringLiteral: "tiles.standard.color.text.eyebrow.value")
                    public static let eyebrowCGColor = ThemeCGColorPicker(stringLiteral: "tiles.standard.color.text.eyebrow.value")
                }

                /// Type: color
                public static let icon = ThemeColorPicker(stringLiteral: "tiles.standard.color.icon.value")
                public static let iconCGColor = ThemeCGColorPicker(stringLiteral: "tiles.standard.color.icon.value")
            }

            public enum spacing {
                public enum content {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "tiles.standard.spacing.content.vertical.value")
                    public enum badge {
                        public enum vertical {
                            /// Type: spacing
                            public static let top = ThemeCGFloatPicker(stringLiteral: "tiles.standard.spacing.content.badge.vertical.top.value")
                        }

                        public enum horizontal {
                            /// Type: spacing
                            public static let right = ThemeCGFloatPicker(stringLiteral: "tiles.standard.spacing.content.badge.horizontal.right.value")
                        }
                    }

                    public enum horizontal {
                        /// Type: spacing
                        public static let left = ThemeCGFloatPicker(stringLiteral: "tiles.standard.spacing.content.horizontal.left.value")
                        /// Type: spacing
                        public static let right = ThemeCGFloatPicker(stringLiteral: "tiles.standard.spacing.content.horizontal.right.value")
                    }
                }

                public enum thumbnail {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "tiles.standard.spacing.thumbnail.vertical.value")
                    public enum horizontal {
                        /// Type: spacing
                        public static let left = ThemeCGFloatPicker(stringLiteral: "tiles.standard.spacing.thumbnail.horizontal.left.value")
                        /// Type: spacing
                        public static let right = ThemeCGFloatPicker(stringLiteral: "tiles.standard.spacing.thumbnail.horizontal.right.value")
                    }
                }
            }

            public enum gap {
                public enum content {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "tiles.standard.gap.content.vertical.value")
                    /// Type: spacing
                    public static let horizontal = ThemeCGFloatPicker(stringLiteral: "tiles.standard.gap.content.horizontal.value")
                }
            }

            public enum font {
                /// Type: typography
                public static let headline = ThemeAnyPicker(keyPath: "tiles.standard.font.headline.value")
                public static let headlineAttributedText = ThemeStringAttributesPicker(keyPath: "tiles.standard.font.headline.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let eyebrow = ThemeAnyPicker(keyPath: "tiles.standard.font.eyebrow.value")
                public static let eyebrowAttributedText = ThemeStringAttributesPicker(keyPath: "tiles.standard.font.eyebrow.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let body = ThemeAnyPicker(keyPath: "tiles.standard.font.body.value")
                public static let bodyAttributedText = ThemeStringAttributesPicker(keyPath: "tiles.standard.font.body.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let badge = ThemeAnyPicker(keyPath: "tiles.standard.font.badge.value")
                public static let badgeAttributedText = ThemeStringAttributesPicker(keyPath: "tiles.standard.font.badge.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            public enum badge {
                public enum color {
                    /// Type: color
                    public static let text = ThemeColorPicker(stringLiteral: "tiles.standard.badge.color.text.value")
                    public static let textCGColor = ThemeCGColorPicker(stringLiteral: "tiles.standard.badge.color.text.value")
                    /// Type: color
                    public static let container = ThemeColorPicker(stringLiteral: "tiles.standard.badge.color.container.value")
                    public static let containerCGColor = ThemeCGColorPicker(stringLiteral: "tiles.standard.badge.color.container.value")
                }
            }
        }

        public enum color {
            public enum container {
                /// Type: color
                public static let base = ThemeColorPicker(stringLiteral: "tiles.color.container.base.value")
                public static let baseCGColor = ThemeCGColorPicker(stringLiteral: "tiles.color.container.base.value")
                /// Type: color
                public static let variant1 = ThemeColorPicker(stringLiteral: "tiles.color.container.variant1.value")
                public static let variant1CGColor = ThemeCGColorPicker(stringLiteral: "tiles.color.container.variant1.value")
                /// Type: color
                public static let variant2 = ThemeColorPicker(stringLiteral: "tiles.color.container.variant2.value")
                public static let variant2CGColor = ThemeCGColorPicker(stringLiteral: "tiles.color.container.variant2.value")
                /// Type: color
                public static let variant3 = ThemeColorPicker(stringLiteral: "tiles.color.container.variant3.value")
                public static let variant3CGColor = ThemeCGColorPicker(stringLiteral: "tiles.color.container.variant3.value")
                /// Type: color
                public static let variant4 = ThemeColorPicker(stringLiteral: "tiles.color.container.variant4.value")
                public static let variant4CGColor = ThemeCGColorPicker(stringLiteral: "tiles.color.container.variant4.value")
                /// Type: color
                public static let variant5 = ThemeColorPicker(stringLiteral: "tiles.color.container.variant5.value")
                public static let variant5CGColor = ThemeCGColorPicker(stringLiteral: "tiles.color.container.variant5.value")
                /// Type: color
                public static let variant6 = ThemeColorPicker(stringLiteral: "tiles.color.container.variant6.value")
                public static let variant6CGColor = ThemeCGColorPicker(stringLiteral: "tiles.color.container.variant6.value")
                /// Type: color
                public static let variant7 = ThemeColorPicker(stringLiteral: "tiles.color.container.variant7.value")
                public static let variant7CGColor = ThemeCGColorPicker(stringLiteral: "tiles.color.container.variant7.value")
            }
        }

        public enum badge {
            /// Type: borderRadius
            public static let borderRadius = ThemeCGFloatPicker(stringLiteral: "tiles.badge.borderRadius.value")
            public enum spacing {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "tiles.badge.spacing.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "tiles.badge.spacing.horizontal.value")
            }

            public enum gap {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "tiles.badge.gap.horizontal.value")
            }

            /// Type: boxShadow
            public static let boxShadow = ThemeAnyPicker(keyPath: "tiles.badge.boxShadow.value")
        }

        public enum feature {
            public enum font {
                /// Type: typography
                public static let eyebrow = ThemeAnyPicker(keyPath: "tiles.feature.font.eyebrow.value")
                public static let eyebrowAttributedText = ThemeStringAttributesPicker(keyPath: "tiles.feature.font.eyebrow.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let header = ThemeAnyPicker(keyPath: "tiles.feature.font.header.value")
                public static let headerAttributedText = ThemeStringAttributesPicker(keyPath: "tiles.feature.font.header.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let body = ThemeAnyPicker(keyPath: "tiles.feature.font.body.value")
                public static let bodyAttributedText = ThemeStringAttributesPicker(keyPath: "tiles.feature.font.body.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            public enum color {
                public enum text {
                    /// Type: color
                    public static let eyebrow = ThemeColorPicker(stringLiteral: "tiles.feature.color.text.eyebrow.value")
                    public static let eyebrowCGColor = ThemeCGColorPicker(stringLiteral: "tiles.feature.color.text.eyebrow.value")
                    /// Type: color
                    public static let header = ThemeColorPicker(stringLiteral: "tiles.feature.color.text.header.value")
                    public static let headerCGColor = ThemeCGColorPicker(stringLiteral: "tiles.feature.color.text.header.value")
                    /// Type: color
                    public static let body = ThemeColorPicker(stringLiteral: "tiles.feature.color.text.body.value")
                    public static let bodyCGColor = ThemeCGColorPicker(stringLiteral: "tiles.feature.color.text.body.value")
                }
            }

            /// Type: borderRadius
            public static let borderRadius = ThemeCGFloatPicker(stringLiteral: "tiles.feature.borderRadius.value")
            public enum spacing {
                public enum content {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "tiles.feature.spacing.content.vertical.value")
                    /// Type: spacing
                    public static let horizontal = ThemeCGFloatPicker(stringLiteral: "tiles.feature.spacing.content.horizontal.value")
                }
            }

            public enum gap {
                /// Type: spacing
                public static let labels = ThemeCGFloatPicker(stringLiteral: "tiles.feature.gap.labels.value")
                public enum content {
                    public enum vertical {
                        /// Type: spacing
                        public static let s = ThemeCGFloatPicker(stringLiteral: "tiles.feature.gap.content.vertical.s.value")
                        /// Type: spacing
                        public static let xs = ThemeCGFloatPicker(stringLiteral: "tiles.feature.gap.content.vertical.xs.value")
                    }
                }
            }

            /// Type: boxShadow
            public static let boxShadow = ThemeAnyPicker(keyPath: "tiles.feature.boxShadow.value")
        }
    }

    public enum statustypes {
        public enum spacing {
            /// Type: spacing
            public static let gap = ThemeCGFloatPicker(stringLiteral: "statustypes.spacing.gap.value")
            /// Type: spacing
            public static let vertical = ThemeCGFloatPicker(stringLiteral: "statustypes.spacing.vertical.value")
            /// Type: spacing
            public static let iconTop = ThemeCGFloatPicker(stringLiteral: "statustypes.spacing.iconTop.value")
        }

        public enum color {
            public enum text {
                /// Type: color
                public static let error = ThemeColorPicker(stringLiteral: "statustypes.color.text.error.value")
                public static let errorCGColor = ThemeCGColorPicker(stringLiteral: "statustypes.color.text.error.value")
                /// Type: color
                public static let success = ThemeColorPicker(stringLiteral: "statustypes.color.text.success.value")
                public static let successCGColor = ThemeCGColorPicker(stringLiteral: "statustypes.color.text.success.value")
            }

            public enum icon {
                /// Type: color
                public static let error = ThemeColorPicker(stringLiteral: "statustypes.color.icon.error.value")
                public static let errorCGColor = ThemeCGColorPicker(stringLiteral: "statustypes.color.icon.error.value")
                /// Type: color
                public static let success = ThemeColorPicker(stringLiteral: "statustypes.color.icon.success.value")
                public static let successCGColor = ThemeCGColorPicker(stringLiteral: "statustypes.color.icon.success.value")
            }
        }

        public enum font {
            /// Type: typography
            public static let medium = ThemeAnyPicker(keyPath: "statustypes.font.medium.value")
            public static let mediumAttributedText = ThemeStringAttributesPicker(keyPath: "statustypes.font.medium.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let small = ThemeAnyPicker(keyPath: "statustypes.font.small.value")
            public static let smallAttributedText = ThemeStringAttributesPicker(keyPath: "statustypes.font.small.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }
    }

    public enum rows {
        public enum font {
            /// Type: typography
            public static let header = ThemeAnyPicker(keyPath: "rows.font.header.value")
            public static let headerAttributedText = ThemeStringAttributesPicker(keyPath: "rows.font.header.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            public enum description {
                /// Type: typography
                public static let body = ThemeAnyPicker(keyPath: "rows.font.description.body.value")
                public static let bodyAttributedText = ThemeStringAttributesPicker(keyPath: "rows.font.description.body.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let details = ThemeAnyPicker(keyPath: "rows.font.description.details.value")
                public static let detailsAttributedText = ThemeStringAttributesPicker(keyPath: "rows.font.description.details.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let status = ThemeAnyPicker(keyPath: "rows.font.description.status.value")
                public static let statusAttributedText = ThemeStringAttributesPicker(keyPath: "rows.font.description.status.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }
        }

        public enum gap {
            /// Type: spacing
            public static let vertical = ThemeCGFloatPicker(stringLiteral: "rows.gap.vertical.value")
            public enum horizontal {
                /// Type: spacing
                public static let header = ThemeCGFloatPicker(stringLiteral: "rows.gap.horizontal.header.value")
                /// Type: spacing
                public static let description = ThemeCGFloatPicker(stringLiteral: "rows.gap.horizontal.description.value")
            }
        }

        public enum spacing {
            public enum content {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "rows.spacing.content.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "rows.spacing.content.horizontal.value")
            }

            public enum icon {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "rows.spacing.icon.vertical.value")
                public enum horizontal {
                    /// Type: spacing
                    public static let left = ThemeCGFloatPicker(stringLiteral: "rows.spacing.icon.horizontal.left.value")
                    /// Type: spacing
                    public static let right = ThemeCGFloatPicker(stringLiteral: "rows.spacing.icon.horizontal.right.value")
                }
            }

            public enum card {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "rows.spacing.card.vertical.value")
                public enum horizontal {
                    /// Type: spacing
                    public static let left = ThemeCGFloatPicker(stringLiteral: "rows.spacing.card.horizontal.left.value")
                    /// Type: spacing
                    public static let right = ThemeCGFloatPicker(stringLiteral: "rows.spacing.card.horizontal.right.value")
                }
            }

            public enum container {
                public enum horizontal {
                    /// Type: spacing
                    public static let left = ThemeCGFloatPicker(stringLiteral: "rows.spacing.container.horizontal.left.value")
                }
            }
        }

        public enum color {
            public enum text {
                public enum header {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "rows.color.text.header.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "rows.color.text.header.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "rows.color.text.header.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "rows.color.text.header.disabled.value")
                }

                public enum description {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "rows.color.text.description.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "rows.color.text.description.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "rows.color.text.description.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "rows.color.text.description.disabled.value")
                }

                public enum details {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "rows.color.text.details.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "rows.color.text.details.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "rows.color.text.details.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "rows.color.text.details.disabled.value")
                }
            }

            public enum container {
                /// Type: color
                public static let pressed = ThemeColorPicker(stringLiteral: "rows.color.container.pressed.value")
                public static let pressedCGColor = ThemeCGColorPicker(stringLiteral: "rows.color.container.pressed.value")
            }

            public enum icon {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "rows.color.icon.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "rows.color.icon.default.value")
                /// Type: color
                public static let disabled = ThemeColorPicker(stringLiteral: "rows.color.icon.disabled.value")
                public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "rows.color.icon.disabled.value")
            }
        }

        public enum padding {
            public enum vertical {
                /// Type: spacing
                public static let switchComponent = ThemeCGFloatPicker(stringLiteral: "rows.padding.vertical.switch.value")
                /// Type: spacing
                public static let textlink = ThemeCGFloatPicker(stringLiteral: "rows.padding.vertical.textlink.value")
            }
        }
    }

    public enum chips {
        public enum size {
            /// Type: sizing
            public static let l = ThemeCGFloatPicker(stringLiteral: "chips.size.l.value")
            /// Type: sizing
            public static let m = ThemeCGFloatPicker(stringLiteral: "chips.size.m.value")
            /// Type: sizing
            public static let xl = ThemeCGFloatPicker(stringLiteral: "chips.size.xl.value")
        }

        public enum standard {
            public enum spacing {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "chips.standard.spacing.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "chips.standard.spacing.horizontal.value")
                /// Type: spacing
                public static let gap = ThemeCGFloatPicker(stringLiteral: "chips.standard.spacing.gap.value")
            }
        }

        public enum filter {
            public enum padding {
                /// Type: spacing
                public static let label = ThemeCGFloatPicker(stringLiteral: "chips.filter.padding.label.value")
            }

            public enum container {
                public enum off {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "chips.filter.container.off.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "chips.filter.container.off.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "chips.filter.container.off.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "chips.filter.container.off.disabled.value")
                }

                public enum on {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "chips.filter.container.on.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "chips.filter.container.on.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "chips.filter.container.on.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "chips.filter.container.on.disabled.value")
                }
            }

            public enum text {
                public enum off {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "chips.filter.text.off.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "chips.filter.text.off.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "chips.filter.text.off.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "chips.filter.text.off.disabled.value")
                }

                /// Type: color
                public static let on = ThemeColorPicker(stringLiteral: "chips.filter.text.on.value")
                public static let onCGColor = ThemeCGColorPicker(stringLiteral: "chips.filter.text.on.value")
            }

            public enum icon {
                public enum off {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "chips.filter.icon.off.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "chips.filter.icon.off.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "chips.filter.icon.off.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "chips.filter.icon.off.disabled.value")
                }

                /// Type: color
                public static let on = ThemeColorPicker(stringLiteral: "chips.filter.icon.on.value")
                public static let onCGColor = ThemeCGColorPicker(stringLiteral: "chips.filter.icon.on.value")
            }
        }

        public enum input {
            public enum color {
                public enum container {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "chips.input.color.container.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "chips.input.color.container.default.value")
                    /// Type: color
                    public static let focus = ThemeColorPicker(stringLiteral: "chips.input.color.container.focus.value")
                    public static let focusCGColor = ThemeCGColorPicker(stringLiteral: "chips.input.color.container.focus.value")
                    /// Type: color
                    public static let entry = ThemeColorPicker(stringLiteral: "chips.input.color.container.entry.value")
                    public static let entryCGColor = ThemeCGColorPicker(stringLiteral: "chips.input.color.container.entry.value")
                    /// Type: color
                    public static let defocused = ThemeColorPicker(stringLiteral: "chips.input.color.container.defocused.value")
                    public static let defocusedCGColor = ThemeCGColorPicker(stringLiteral: "chips.input.color.container.defocused.value")
                }

                public enum text {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "chips.input.color.text.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "chips.input.color.text.default.value")
                    /// Type: color
                    public static let counter = ThemeColorPicker(stringLiteral: "chips.input.color.text.counter.value")
                    public static let counterCGColor = ThemeCGColorPicker(stringLiteral: "chips.input.color.text.counter.value")
                }
            }

            public enum counter {
                /// Type: spacing
                public static let gap = ThemeCGFloatPicker(stringLiteral: "chips.input.counter.gap.value")
            }
        }

        public enum choice {
            public enum container {
                public enum off {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "chips.choice.container.off.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "chips.choice.container.off.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "chips.choice.container.off.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "chips.choice.container.off.disabled.value")
                }

                public enum on {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "chips.choice.container.on.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "chips.choice.container.on.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "chips.choice.container.on.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "chips.choice.container.on.disabled.value")
                }
            }

            public enum text {
                public enum off {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "chips.choice.text.off.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "chips.choice.text.off.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "chips.choice.text.off.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "chips.choice.text.off.disabled.value")
                }

                /// Type: color
                public static let on = ThemeColorPicker(stringLiteral: "chips.choice.text.on.value")
                public static let onCGColor = ThemeCGColorPicker(stringLiteral: "chips.choice.text.on.value")
            }

            public enum icon {
                public enum off {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "chips.choice.icon.off.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "chips.choice.icon.off.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "chips.choice.icon.off.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "chips.choice.icon.off.disabled.value")
                }

                /// Type: color
                public static let on = ThemeColorPicker(stringLiteral: "chips.choice.icon.on.value")
                public static let onCGColor = ThemeCGColorPicker(stringLiteral: "chips.choice.icon.on.value")
            }
        }

        public enum font {
            /// Type: typography
            public static let counter = ThemeAnyPicker(keyPath: "chips.font.counter.value")
            public static let counterAttributedText = ThemeStringAttributesPicker(keyPath: "chips.font.counter.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            public enum label {
                /// Type: typography
                public static let s = ThemeAnyPicker(keyPath: "chips.font.label.s.value")
                public static let sAttributedText = ThemeStringAttributesPicker(keyPath: "chips.font.label.s.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let l = ThemeAnyPicker(keyPath: "chips.font.label.l.value")
                public static let lAttributedText = ThemeStringAttributesPicker(keyPath: "chips.font.label.l.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }
        }

        public enum container {
            public enum borderRadius {
                /// Type: borderRadius
                public static let s = ThemeCGFloatPicker(stringLiteral: "chips.container.borderRadius.s.value")
                /// Type: borderRadius
                public static let m = ThemeCGFloatPicker(stringLiteral: "chips.container.borderRadius.m.value")
                /// Type: borderRadius
                public static let l = ThemeCGFloatPicker(stringLiteral: "chips.container.borderRadius.l.value")
            }
        }
    }

    public enum labels {
        public enum font {
            /// Type: typography
            public static let primary = ThemeAnyPicker(keyPath: "labels.font.primary.value")
            public static let primaryAttributedText = ThemeStringAttributesPicker(keyPath: "labels.font.primary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let secondary = ThemeAnyPicker(keyPath: "labels.font.secondary.value")
            public static let secondaryAttributedText = ThemeStringAttributesPicker(keyPath: "labels.font.secondary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }

        /// Type: borderRadius
        public static let borderRadius = ThemeCGFloatPicker(stringLiteral: "labels.borderRadius.value")
        public enum announcement {
            public enum color {
                public enum bg {
                    /// Type: color
                    public static let neutral = ThemeColorPicker(stringLiteral: "labels.announcement.color.bg.neutral.value")
                    public static let neutralCGColor = ThemeCGColorPicker(stringLiteral: "labels.announcement.color.bg.neutral.value")
                    /// Type: color
                    public static let coloured = ThemeColorPicker(stringLiteral: "labels.announcement.color.bg.coloured.value")
                    public static let colouredCGColor = ThemeCGColorPicker(stringLiteral: "labels.announcement.color.bg.coloured.value")
                }

                public enum text {
                    /// Type: color
                    public static let neutral = ThemeColorPicker(stringLiteral: "labels.announcement.color.text.neutral.value")
                    public static let neutralCGColor = ThemeCGColorPicker(stringLiteral: "labels.announcement.color.text.neutral.value")
                    /// Type: color
                    public static let coloured = ThemeColorPicker(stringLiteral: "labels.announcement.color.text.coloured.value")
                    public static let colouredCGColor = ThemeCGColorPicker(stringLiteral: "labels.announcement.color.text.coloured.value")
                }
            }
        }

        public enum status {
            public enum color {
                public enum bg {
                    /// Type: color
                    public static let info = ThemeColorPicker(stringLiteral: "labels.status.color.bg.info.value")
                    public static let infoCGColor = ThemeCGColorPicker(stringLiteral: "labels.status.color.bg.info.value")
                    /// Type: color
                    public static let alert = ThemeColorPicker(stringLiteral: "labels.status.color.bg.alert.value")
                    public static let alertCGColor = ThemeCGColorPicker(stringLiteral: "labels.status.color.bg.alert.value")
                    /// Type: color
                    public static let negative = ThemeColorPicker(stringLiteral: "labels.status.color.bg.negative.value")
                    public static let negativeCGColor = ThemeCGColorPicker(stringLiteral: "labels.status.color.bg.negative.value")
                    /// Type: color
                    public static let positive = ThemeColorPicker(stringLiteral: "labels.status.color.bg.positive.value")
                    public static let positiveCGColor = ThemeCGColorPicker(stringLiteral: "labels.status.color.bg.positive.value")
                }

                /// Type: color
                public static let text = ThemeColorPicker(stringLiteral: "labels.status.color.text.value")
                public static let textCGColor = ThemeCGColorPicker(stringLiteral: "labels.status.color.text.value")
                public enum icon {
                    /// Type: color
                    public static let info = ThemeColorPicker(stringLiteral: "labels.status.color.icon.info.value")
                    public static let infoCGColor = ThemeCGColorPicker(stringLiteral: "labels.status.color.icon.info.value")
                    /// Type: color
                    public static let alert = ThemeColorPicker(stringLiteral: "labels.status.color.icon.alert.value")
                    public static let alertCGColor = ThemeCGColorPicker(stringLiteral: "labels.status.color.icon.alert.value")
                    /// Type: color
                    public static let negative = ThemeColorPicker(stringLiteral: "labels.status.color.icon.negative.value")
                    public static let negativeCGColor = ThemeCGColorPicker(stringLiteral: "labels.status.color.icon.negative.value")
                    /// Type: color
                    public static let positive = ThemeColorPicker(stringLiteral: "labels.status.color.icon.positive.value")
                    public static let positiveCGColor = ThemeCGColorPicker(stringLiteral: "labels.status.color.icon.positive.value")
                }
            }
        }

        public enum spacing {
            public enum announcement {
                public enum primary {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "labels.spacing.announcement.primary.vertical.value")
                    /// Type: spacing
                    public static let horizontal = ThemeCGFloatPicker(stringLiteral: "labels.spacing.announcement.primary.horizontal.value")
                }

                public enum secondary {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "labels.spacing.announcement.secondary.vertical.value")
                    /// Type: spacing
                    public static let horizontal = ThemeCGFloatPicker(stringLiteral: "labels.spacing.announcement.secondary.horizontal.value")
                }
            }

            public enum status {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "labels.spacing.status.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "labels.spacing.status.horizontal.value")
            }

            /// Type: spacing
            public static let gap = ThemeCGFloatPicker(stringLiteral: "labels.spacing.gap.value")
            public enum standard {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "labels.spacing.standard.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "labels.spacing.standard.horizontal.value")
            }
        }

        public enum standard {
            /// Type: borderRadius
            public static let borderRadius = ThemeCGFloatPicker(stringLiteral: "labels.standard.borderRadius.value")
            public enum color {
                public enum bg {
                    /// Type: color
                    public static let neutral = ThemeColorPicker(stringLiteral: "labels.standard.color.bg.neutral.value")
                    public static let neutralCGColor = ThemeCGColorPicker(stringLiteral: "labels.standard.color.bg.neutral.value")
                    /// Type: color
                    public static let coloured = ThemeColorPicker(stringLiteral: "labels.standard.color.bg.coloured.value")
                    public static let colouredCGColor = ThemeCGColorPicker(stringLiteral: "labels.standard.color.bg.coloured.value")
                    /// Type: color
                    public static let white = ThemeColorPicker(stringLiteral: "labels.standard.color.bg.white.value")
                    public static let whiteCGColor = ThemeCGColorPicker(stringLiteral: "labels.standard.color.bg.white.value")
                }

                public enum text {
                    /// Type: color
                    public static let onLight = ThemeColorPicker(stringLiteral: "labels.standard.color.text.onLight.value")
                    public static let onLightCGColor = ThemeCGColorPicker(stringLiteral: "labels.standard.color.text.onLight.value")
                }
            }

            public enum font {
                /// Type: typography
                public static let primary = ThemeAnyPicker(keyPath: "labels.standard.font.primary.value")
                public static let primaryAttributedText = ThemeStringAttributesPicker(keyPath: "labels.standard.font.primary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let secondary = ThemeAnyPicker(keyPath: "labels.standard.font.secondary.value")
                public static let secondaryAttributedText = ThemeStringAttributesPicker(keyPath: "labels.standard.font.secondary.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }
        }
    }

    public enum accordion {
        public enum font {
            public enum standard {
                /// Type: typography
                public static let label = ThemeAnyPicker(keyPath: "accordion.font.standard.label.value")
                public static let labelAttributedText = ThemeStringAttributesPicker(keyPath: "accordion.font.standard.label.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let description = ThemeAnyPicker(keyPath: "accordion.font.standard.description.value")
                public static let descriptionAttributedText = ThemeStringAttributesPicker(keyPath: "accordion.font.standard.description.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            /// Type: typography
            public static let content = ThemeAnyPicker(keyPath: "accordion.font.content.value")
            public static let contentAttributedText = ThemeStringAttributesPicker(keyPath: "accordion.font.content.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            public enum inCard {
                /// Type: typography
                public static let label = ThemeAnyPicker(keyPath: "accordion.font.inCard.label.value")
                public static let labelAttributedText = ThemeStringAttributesPicker(keyPath: "accordion.font.inCard.label.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }
        }

        public enum color {
            public enum container {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "accordion.color.container.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.container.default.value")
                /// Type: color
                public static let pressed = ThemeColorPicker(stringLiteral: "accordion.color.container.pressed.value")
                public static let pressedCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.container.pressed.value")
            }

            public enum text {
                public enum label {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "accordion.color.text.label.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.text.label.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "accordion.color.text.label.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.text.label.disabled.value")
                }

                public enum description {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "accordion.color.text.description.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.text.description.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "accordion.color.text.description.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.text.description.disabled.value")
                }
            }

            public enum chevron {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "accordion.color.chevron.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.chevron.default.value")
                /// Type: color
                public static let disabled = ThemeColorPicker(stringLiteral: "accordion.color.chevron.disabled.value")
                public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.chevron.disabled.value")
            }

            /// Type: color
            public static let content = ThemeColorPicker(stringLiteral: "accordion.color.content.value")
            public static let contentCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.content.value")
            /// Type: color
            public static let bg = ThemeColorPicker(stringLiteral: "accordion.color.bg.value")
            public static let bgCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.bg.value")
            public enum inCard {
                public enum text {
                    public enum label {
                        /// Type: color
                        public static let defaultValue = ThemeColorPicker(stringLiteral: "accordion.color.inCard.text.label.default.value")
                        public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.inCard.text.label.default.value")
                        /// Type: color
                        public static let disabled = ThemeColorPicker(stringLiteral: "accordion.color.inCard.text.label.disabled.value")
                        public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.inCard.text.label.disabled.value")
                    }

                    public enum description {
                        /// Type: color
                        public static let defaultValue = ThemeColorPicker(stringLiteral: "accordion.color.inCard.text.description.default.value")
                        public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.inCard.text.description.default.value")
                        /// Type: color
                        public static let disabled = ThemeColorPicker(stringLiteral: "accordion.color.inCard.text.description.disabled.value")
                        public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.inCard.text.description.disabled.value")
                    }
                }

                public enum chevron {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "accordion.color.inCard.chevron.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.inCard.chevron.default.value")
                    /// Type: color
                    public static let disabled = ThemeColorPicker(stringLiteral: "accordion.color.inCard.chevron.disabled.value")
                    public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "accordion.color.inCard.chevron.disabled.value")
                }
            }
        }

        public enum gap {
            /// Type: spacing
            public static let rows = ThemeCGFloatPicker(stringLiteral: "accordion.gap.rows.value")
            /// Type: spacing
            public static let chevron = ThemeCGFloatPicker(stringLiteral: "accordion.gap.chevron.value")
            public enum inCard {
                /// Type: spacing
                public static let rows = ThemeCGFloatPicker(stringLiteral: "accordion.gap.inCard.rows.value")
            }
        }

        public enum borderRadius {
            /// Type: borderRadius
            public static let inCard = ThemeCGFloatPicker(stringLiteral: "accordion.borderRadius.inCard.value")
        }

        public enum spacing {
            public enum fullWidth {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "accordion.spacing.fullWidth.horizontal.value")
            }

            public enum collapsed {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "accordion.spacing.collapsed.vertical.value")
            }

            public enum inCard {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "accordion.spacing.inCard.horizontal.value")
            }

            public enum expanded {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "accordion.spacing.expanded.vertical.value")
                /// Type: spacing
                public static let bottom = ThemeCGFloatPicker(stringLiteral: "accordion.spacing.expanded.bottom.value")
            }
        }

        public enum inCard {
            /// Type: boxShadow
            public static let boxShadow = ThemeAnyPicker(keyPath: "accordion.inCard.boxShadow.value")
        }
    }

    public enum emptyStates {
        public enum font {
            public enum medium {
                /// Type: typography
                public static let title = ThemeAnyPicker(keyPath: "emptyStates.font.medium.title.value")
                public static let titleAttributedText = ThemeStringAttributesPicker(keyPath: "emptyStates.font.medium.title.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let description = ThemeAnyPicker(keyPath: "emptyStates.font.medium.description.value")
                public static let descriptionAttributedText = ThemeStringAttributesPicker(keyPath: "emptyStates.font.medium.description.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            public enum small {
                /// Type: typography
                public static let title = ThemeAnyPicker(keyPath: "emptyStates.font.small.title.value")
                public static let titleAttributedText = ThemeStringAttributesPicker(keyPath: "emptyStates.font.small.title.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let description = ThemeAnyPicker(keyPath: "emptyStates.font.small.description.value")
                public static let descriptionAttributedText = ThemeStringAttributesPicker(keyPath: "emptyStates.font.small.description.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }
        }

        public enum color {
            public enum medium {
                public enum text {
                    /// Type: color
                    public static let title = ThemeColorPicker(stringLiteral: "emptyStates.color.medium.text.title.value")
                    public static let titleCGColor = ThemeCGColorPicker(stringLiteral: "emptyStates.color.medium.text.title.value")
                    /// Type: color
                    public static let description = ThemeColorPicker(stringLiteral: "emptyStates.color.medium.text.description.value")
                    public static let descriptionCGColor = ThemeCGColorPicker(stringLiteral: "emptyStates.color.medium.text.description.value")
                }
            }

            public enum small {
                public enum text {
                    /// Type: color
                    public static let title = ThemeColorPicker(stringLiteral: "emptyStates.color.small.text.title.value")
                    public static let titleCGColor = ThemeCGColorPicker(stringLiteral: "emptyStates.color.small.text.title.value")
                    /// Type: color
                    public static let description = ThemeColorPicker(stringLiteral: "emptyStates.color.small.text.description.value")
                    public static let descriptionCGColor = ThemeCGColorPicker(stringLiteral: "emptyStates.color.small.text.description.value")
                }
            }
        }

        public enum spacing {
            public enum medium {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "emptyStates.spacing.medium.horizontal.value")
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "emptyStates.spacing.medium.vertical.value")
            }

            public enum large {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "emptyStates.spacing.large.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "emptyStates.spacing.large.horizontal.value")
            }

            public enum small {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "emptyStates.spacing.small.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "emptyStates.spacing.small.horizontal.value")
            }
        }

        public enum gap {
            public enum container {
                public enum medium {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "emptyStates.gap.container.medium.vertical.value")
                }

                public enum small {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "emptyStates.gap.container.small.vertical.value")
                }
            }

            public enum content {
                public enum medium {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "emptyStates.gap.content.medium.vertical.value")
                }

                public enum small {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "emptyStates.gap.content.small.vertical.value")
                }
            }
        }
    }

    public enum transactionListing {
        public enum color {
            public enum text {
                /// Type: color
                public static let status = ThemeColorPicker(stringLiteral: "transactionListing.color.text.status.value")
                public static let statusCGColor = ThemeCGColorPicker(stringLiteral: "transactionListing.color.text.status.value")
                /// Type: color
                public static let priBody = ThemeColorPicker(stringLiteral: "transactionListing.color.text.priBody.value")
                public static let priBodyCGColor = ThemeCGColorPicker(stringLiteral: "transactionListing.color.text.priBody.value")
                /// Type: color
                public static let secBody = ThemeColorPicker(stringLiteral: "transactionListing.color.text.secBody.value")
                public static let secBodyCGColor = ThemeCGColorPicker(stringLiteral: "transactionListing.color.text.secBody.value")
                /// Type: color
                public static let amountIncoming = ThemeColorPicker(stringLiteral: "transactionListing.color.text.amountIncoming.value")
                public static let amountIncomingCGColor = ThemeCGColorPicker(stringLiteral: "transactionListing.color.text.amountIncoming.value")
                /// Type: color
                public static let amountOutgoing = ThemeColorPicker(stringLiteral: "transactionListing.color.text.amountOutgoing.value")
                public static let amountOutgoingCGColor = ThemeCGColorPicker(stringLiteral: "transactionListing.color.text.amountOutgoing.value")
                /// Type: color
                public static let foregnCurrency = ThemeColorPicker(stringLiteral: "transactionListing.color.text.foregnCurrency.value")
                public static let foregnCurrencyCGColor = ThemeCGColorPicker(stringLiteral: "transactionListing.color.text.foregnCurrency.value")
            }

            public enum container {
                /// Type: color
                public static let pressed = ThemeColorPicker(stringLiteral: "transactionListing.color.container.pressed.value")
                public static let pressedCGColor = ThemeCGColorPicker(stringLiteral: "transactionListing.color.container.pressed.value")
            }
        }

        public enum font {
            /// Type: typography
            public static let status = ThemeAnyPicker(keyPath: "transactionListing.font.status.value")
            public static let statusAttributedText = ThemeStringAttributesPicker(keyPath: "transactionListing.font.status.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let priBody = ThemeAnyPicker(keyPath: "transactionListing.font.priBody.value")
            public static let priBodyAttributedText = ThemeStringAttributesPicker(keyPath: "transactionListing.font.priBody.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let secBody = ThemeAnyPicker(keyPath: "transactionListing.font.secBody.value")
            public static let secBodyAttributedText = ThemeStringAttributesPicker(keyPath: "transactionListing.font.secBody.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let amountIncoming = ThemeAnyPicker(keyPath: "transactionListing.font.amountIncoming.value")
            public static let amountIncomingAttributedText = ThemeStringAttributesPicker(keyPath: "transactionListing.font.amountIncoming.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let amountOutgoing = ThemeAnyPicker(keyPath: "transactionListing.font.amountOutgoing.value")
            public static let amountOutgoingAttributedText = ThemeStringAttributesPicker(keyPath: "transactionListing.font.amountOutgoing.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let foreignCurrency = ThemeAnyPicker(keyPath: "transactionListing.font.foreignCurrency.value")
            public static let foreignCurrencyAttributedText = ThemeStringAttributesPicker(keyPath: "transactionListing.font.foreignCurrency.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }

        public enum spacing {
            public enum content {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "transactionListing.spacing.content.horizontal.value")
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "transactionListing.spacing.content.vertical.value")
            }

            public enum icon {
                public enum horizontal {
                    /// Type: spacing
                    public static let left = ThemeCGFloatPicker(stringLiteral: "transactionListing.spacing.icon.horizontal.left.value")
                    /// Type: spacing
                    public static let right = ThemeCGFloatPicker(stringLiteral: "transactionListing.spacing.icon.horizontal.right.value")
                }

                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "transactionListing.spacing.icon.vertical.value")
            }

            public enum card {
                public enum horizontal {
                    /// Type: spacing
                    public static let left = ThemeCGFloatPicker(stringLiteral: "transactionListing.spacing.card.horizontal.left.value")
                    /// Type: spacing
                    public static let right = ThemeCGFloatPicker(stringLiteral: "transactionListing.spacing.card.horizontal.right.value")
                }

                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "transactionListing.spacing.card.vertical.value")
            }
        }

        public enum gap {
            /// Type: spacing
            public static let status = ThemeCGFloatPicker(stringLiteral: "transactionListing.gap.status.value")
            /// Type: spacing
            public static let body = ThemeCGFloatPicker(stringLiteral: "transactionListing.gap.body.value")
            /// Type: spacing
            public static let amount = ThemeCGFloatPicker(stringLiteral: "transactionListing.gap.amount.value")
            /// Type: spacing
            public static let fx = ThemeCGFloatPicker(stringLiteral: "transactionListing.gap.fx.value")
        }
    }

    public enum acknowledgement {
        public enum spacing {
            public enum content {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "acknowledgement.spacing.content.horizontal.value")
            }

            public enum cta {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "acknowledgement.spacing.cta.horizontal.value")
                public enum vertical {
                    /// Type: spacing
                    public static let top = ThemeCGFloatPicker(stringLiteral: "acknowledgement.spacing.cta.vertical.top.value")
                    /// Type: spacing
                    public static let bottom = ThemeCGFloatPicker(stringLiteral: "acknowledgement.spacing.cta.vertical.bottom.value")
                }
            }

            public enum footnote {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "acknowledgement.spacing.footnote.vertical.value")
            }
        }

        public enum gap {
            public enum content {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "acknowledgement.gap.content.vertical.value")
            }

            public enum header {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "acknowledgement.gap.header.vertical.value")
            }

            public enum info {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "acknowledgement.gap.info.vertical.value")
            }
        }

        public enum font {
            /// Type: typography
            public static let content = ThemeAnyPicker(keyPath: "acknowledgement.font.content.value")
            public static let contentAttributedText = ThemeStringAttributesPicker(keyPath: "acknowledgement.font.content.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let link = ThemeAnyPicker(keyPath: "acknowledgement.font.link.value")
            public static let linkAttributedText = ThemeStringAttributesPicker(keyPath: "acknowledgement.font.link.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let footnote = ThemeAnyPicker(keyPath: "acknowledgement.font.footnote.value")
            public static let footnoteAttributedText = ThemeStringAttributesPicker(keyPath: "acknowledgement.font.footnote.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }

        public enum color {
            public enum text {
                /// Type: color
                public static let body = ThemeColorPicker(stringLiteral: "acknowledgement.color.text.body.value")
                public static let bodyCGColor = ThemeCGColorPicker(stringLiteral: "acknowledgement.color.text.body.value")
                /// Type: color
                public static let link = ThemeColorPicker(stringLiteral: "acknowledgement.color.text.link.value")
                public static let linkCGColor = ThemeCGColorPicker(stringLiteral: "acknowledgement.color.text.link.value")
                /// Type: color
                public static let footnote = ThemeColorPicker(stringLiteral: "acknowledgement.color.text.footnote.value")
                public static let footnoteCGColor = ThemeCGColorPicker(stringLiteral: "acknowledgement.color.text.footnote.value")
            }
        }
    }

    public enum otp {
        public enum color {
            public enum bg {
                /// Type: color
                public static let empty = ThemeColorPicker(stringLiteral: "otp.color.bg.empty.value")
                public static let emptyCGColor = ThemeCGColorPicker(stringLiteral: "otp.color.bg.empty.value")
                /// Type: color
                public static let activated = ThemeColorPicker(stringLiteral: "otp.color.bg.activated.value")
                public static let activatedCGColor = ThemeCGColorPicker(stringLiteral: "otp.color.bg.activated.value")
                /// Type: color
                public static let error = ThemeColorPicker(stringLiteral: "otp.color.bg.error.value")
                public static let errorCGColor = ThemeCGColorPicker(stringLiteral: "otp.color.bg.error.value")
                /// Type: color
                public static let filled = ThemeColorPicker(stringLiteral: "otp.color.bg.filled.value")
                public static let filledCGColor = ThemeCGColorPicker(stringLiteral: "otp.color.bg.filled.value")
                /// Type: color
                public static let input = ThemeColorPicker(stringLiteral: "otp.color.bg.input.value")
                public static let inputCGColor = ThemeCGColorPicker(stringLiteral: "otp.color.bg.input.value")
            }

            public enum text {
                /// Type: color
                public static let input = ThemeColorPicker(stringLiteral: "otp.color.text.input.value")
                public static let inputCGColor = ThemeCGColorPicker(stringLiteral: "otp.color.text.input.value")
                /// Type: color
                public static let caption = ThemeColorPicker(stringLiteral: "otp.color.text.caption.value")
                public static let captionCGColor = ThemeCGColorPicker(stringLiteral: "otp.color.text.caption.value")
            }
        }

        public enum font {
            /// Type: typography
            public static let caption = ThemeAnyPicker(keyPath: "otp.font.caption.value")
            public static let captionAttributedText = ThemeStringAttributesPicker(keyPath: "otp.font.caption.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let input = ThemeAnyPicker(keyPath: "otp.font.input.value")
            public static let inputAttributedText = ThemeStringAttributesPicker(keyPath: "otp.font.input.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }

        public enum gap {
            public enum input {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "otp.gap.input.vertical.value")
            }

            /// Type: spacing
            public static let horizontal = ThemeCGFloatPicker(stringLiteral: "otp.gap.horizontal.value")
            /// Type: spacing
            public static let vertical = ThemeCGFloatPicker(stringLiteral: "otp.gap.vertical.value")
        }

        public enum xs {
            public enum gap {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "otp.xs.gap.horizontal.value")
                public enum section {
                    /// Type: spacing
                    public static let horizontal = ThemeCGFloatPicker(stringLiteral: "otp.xs.gap.section.horizontal.value")
                }
            }
        }
    }

    public enum calendar {
        public enum drumroll {
            public enum iOS {
                public enum spacing {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "calendar.drumroll.iOS.spacing.vertical.value")
                }
            }

            public enum android {
                public enum spacing {
                    /// Type: spacing
                    public static let vertical = ThemeCGFloatPicker(stringLiteral: "calendar.drumroll.android.spacing.vertical.value")
                }
            }
        }

        public enum picker {
            public enum font {
                /// Type: typography
                public static let monthyear = ThemeAnyPicker(keyPath: "calendar.picker.font.monthyear.value")
                public static let monthyearAttributedText = ThemeStringAttributesPicker(keyPath: "calendar.picker.font.monthyear.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let days = ThemeAnyPicker(keyPath: "calendar.picker.font.days.value")
                public static let daysAttributedText = ThemeStringAttributesPicker(keyPath: "calendar.picker.font.days.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                public enum date {
                    /// Type: typography
                    public static let defaultValue = ThemeAnyPicker(keyPath: "calendar.picker.font.date.default.value")
                    public static let defaultValueAttributedText = ThemeStringAttributesPicker(keyPath: "calendar.picker.font.date.default.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                    /// Type: typography
                    public static let selected = ThemeAnyPicker(keyPath: "calendar.picker.font.date.selected.value")
                    public static let selectedAttributedText = ThemeStringAttributesPicker(keyPath: "calendar.picker.font.date.selected.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                }
            }

            public enum color {
                public enum text {
                    /// Type: color
                    public static let monthyear = ThemeColorPicker(stringLiteral: "calendar.picker.color.text.monthyear.value")
                    public static let monthyearCGColor = ThemeCGColorPicker(stringLiteral: "calendar.picker.color.text.monthyear.value")
                    /// Type: color
                    public static let days = ThemeColorPicker(stringLiteral: "calendar.picker.color.text.days.value")
                    public static let daysCGColor = ThemeCGColorPicker(stringLiteral: "calendar.picker.color.text.days.value")
                    public enum date {
                        /// Type: color
                        public static let defaultValue = ThemeColorPicker(stringLiteral: "calendar.picker.color.text.date.default.value")
                        public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "calendar.picker.color.text.date.default.value")
                        /// Type: color
                        public static let disabled = ThemeColorPicker(stringLiteral: "calendar.picker.color.text.date.disabled.value")
                        public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "calendar.picker.color.text.date.disabled.value")
                        /// Type: color
                        public static let today = ThemeColorPicker(stringLiteral: "calendar.picker.color.text.date.today.value")
                        public static let todayCGColor = ThemeCGColorPicker(stringLiteral: "calendar.picker.color.text.date.today.value")
                        /// Type: color
                        public static let selection = ThemeColorPicker(stringLiteral: "calendar.picker.color.text.date.selection.value")
                        public static let selectionCGColor = ThemeCGColorPicker(stringLiteral: "calendar.picker.color.text.date.selection.value")
                    }
                }

                public enum container {
                    /// Type: color
                    public static let selected = ThemeColorPicker(stringLiteral: "calendar.picker.color.container.selected.value")
                    public static let selectedCGColor = ThemeCGColorPicker(stringLiteral: "calendar.picker.color.container.selected.value")
                    /// Type: color
                    public static let range = ThemeColorPicker(stringLiteral: "calendar.picker.color.container.range.value")
                    public static let rangeCGColor = ThemeCGColorPicker(stringLiteral: "calendar.picker.color.container.range.value")
                }

                public enum icon {
                    public enum chevron {
                        /// Type: color
                        public static let active = ThemeColorPicker(stringLiteral: "calendar.picker.color.icon.chevron.active.value")
                        public static let activeCGColor = ThemeCGColorPicker(stringLiteral: "calendar.picker.color.icon.chevron.active.value")
                        /// Type: color
                        public static let inactive = ThemeColorPicker(stringLiteral: "calendar.picker.color.icon.chevron.inactive.value")
                        public static let inactiveCGColor = ThemeCGColorPicker(stringLiteral: "calendar.picker.color.icon.chevron.inactive.value")
                    }
                }

                /// Type: color
                public static let bg = ThemeColorPicker(stringLiteral: "calendar.picker.color.bg.value")
                public static let bgCGColor = ThemeCGColorPicker(stringLiteral: "calendar.picker.color.bg.value")
            }
        }
    }

    public enum errorHandling {
        public enum toast {
            public enum spacing {
                public enum horizontal {
                    /// Type: spacing
                    public static let bottom = ThemeCGFloatPicker(stringLiteral: "errorHandling.toast.spacing.horizontal.bottom.value")
                }
            }
        }

        public enum color {
            /// Type: color
            public static let text = ThemeColorPicker(stringLiteral: "errorHandling.color.text.value")
            public static let textCGColor = ThemeCGColorPicker(stringLiteral: "errorHandling.color.text.value")
            /// Type: color
            public static let icon = ThemeColorPicker(stringLiteral: "errorHandling.color.icon.value")
            public static let iconCGColor = ThemeCGColorPicker(stringLiteral: "errorHandling.color.icon.value")
        }
    }

    public enum progressIndicator {
        public enum color {
            /// Type: color
            public static let track = ThemeColorPicker(stringLiteral: "progressIndicator.color.track.value")
            public static let trackCGColor = ThemeCGColorPicker(stringLiteral: "progressIndicator.color.track.value")
            /// Type: color
            public static let indicator = ThemeColorPicker(stringLiteral: "progressIndicator.color.indicator.value")
            public static let indicatorCGColor = ThemeCGColorPicker(stringLiteral: "progressIndicator.color.indicator.value")
        }
    }

    public enum cvp {
        public enum color {
            public enum text {
                /// Type: color
                public static let description = ThemeColorPicker(stringLiteral: "cvp.color.text.description.value")
                public static let descriptionCGColor = ThemeCGColorPicker(stringLiteral: "cvp.color.text.description.value")
            }
        }

        public enum font {
            /// Type: typography
            public static let description = ThemeAnyPicker(keyPath: "cvp.font.description.value")
            public static let descriptionAttributedText = ThemeStringAttributesPicker(keyPath: "cvp.font.description.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }

        public enum spacing {
            public enum visual {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "cvp.spacing.visual.vertical.value")
            }

            public enum content {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "cvp.spacing.content.horizontal.value")
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "cvp.spacing.content.vertical.value")
            }

            public enum button {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "cvp.spacing.button.horizontal.value")
                public enum vertical {
                    /// Type: spacing
                    public static let top = ThemeCGFloatPicker(stringLiteral: "cvp.spacing.button.vertical.top.value")
                    /// Type: spacing
                    public static let btm = ThemeCGFloatPicker(stringLiteral: "cvp.spacing.button.vertical.btm.value")
                }
            }
        }

        public enum gap {
            /// Type: spacing
            public static let content = ThemeCGFloatPicker(stringLiteral: "cvp.gap.content.value")
        }
    }

    public enum authentication {
        public enum spacing {
            /// Type: spacing
            public static let horizontal = ThemeCGFloatPicker(stringLiteral: "authentication.spacing.horizontal.value")
            /// Type: spacing
            public static let vertical = ThemeCGFloatPicker(stringLiteral: "authentication.spacing.vertical.value")
        }

        public enum gap {
            public enum graphic {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "authentication.gap.graphic.vertical.value")
            }

            public enum header {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "authentication.gap.header.vertical.value")
            }

            public enum content {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "authentication.gap.content.vertical.value")
            }
        }

        public enum color {
            public enum text {
                /// Type: color
                public static let title = ThemeColorPicker(stringLiteral: "authentication.color.text.title.value")
                public static let titleCGColor = ThemeCGColorPicker(stringLiteral: "authentication.color.text.title.value")
                /// Type: color
                public static let description = ThemeColorPicker(stringLiteral: "authentication.color.text.description.value")
                public static let descriptionCGColor = ThemeCGColorPicker(stringLiteral: "authentication.color.text.description.value")
                /// Type: color
                public static let timer = ThemeColorPicker(stringLiteral: "authentication.color.text.timer.value")
                public static let timerCGColor = ThemeCGColorPicker(stringLiteral: "authentication.color.text.timer.value")
            }

            public enum bg {
                /// Type: color
                public static let loader = ThemeColorPicker(stringLiteral: "authentication.color.bg.loader.value")
                public static let loaderCGColor = ThemeCGColorPicker(stringLiteral: "authentication.color.bg.loader.value")
            }
        }

        public enum font {
            /// Type: typography
            public static let title = ThemeAnyPicker(keyPath: "authentication.font.title.value")
            public static let titleAttributedText = ThemeStringAttributesPicker(keyPath: "authentication.font.title.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let description = ThemeAnyPicker(keyPath: "authentication.font.description.value")
            public static let descriptionAttributedText = ThemeStringAttributesPicker(keyPath: "authentication.font.description.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let timer = ThemeAnyPicker(keyPath: "authentication.font.timer.value")
            public static let timerAttributedText = ThemeStringAttributesPicker(keyPath: "authentication.font.timer.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }
    }

    public enum tabswitch {
        public enum spacing {
            /// Type: spacing
            public static let vertical = ThemeCGFloatPicker(stringLiteral: "tabswitch.spacing.vertical.value")
            /// Type: spacing
            public static let horizontal = ThemeCGFloatPicker(stringLiteral: "tabswitch.spacing.horizontal.value")
        }

        public enum color {
            public enum bg {
                /// Type: color
                public static let on = ThemeColorPicker(stringLiteral: "tabswitch.color.bg.on.value")
                public static let onCGColor = ThemeCGColorPicker(stringLiteral: "tabswitch.color.bg.on.value")
            }

            public enum label {
                /// Type: color
                public static let on = ThemeColorPicker(stringLiteral: "tabswitch.color.label.on.value")
                public static let onCGColor = ThemeCGColorPicker(stringLiteral: "tabswitch.color.label.on.value")
                /// Type: color
                public static let off = ThemeColorPicker(stringLiteral: "tabswitch.color.label.off.value")
                public static let offCGColor = ThemeCGColorPicker(stringLiteral: "tabswitch.color.label.off.value")
            }
        }

        /// Type: borderRadius
        public static let borderRadius = ThemeCGFloatPicker(stringLiteral: "tabswitch.borderRadius.value")
        public enum font {
            /// Type: typography
            public static let label = ThemeAnyPicker(keyPath: "tabswitch.font.label.value")
            public static let labelAttributedText = ThemeStringAttributesPicker(keyPath: "tabswitch.font.label.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }
    }

    public enum stepper {
        public enum color {
            public enum circle {
                /// Type: color
                public static let active = ThemeColorPicker(stringLiteral: "stepper.color.circle.active.value")
                public static let activeCGColor = ThemeCGColorPicker(stringLiteral: "stepper.color.circle.active.value")
                /// Type: color
                public static let inactive = ThemeColorPicker(stringLiteral: "stepper.color.circle.inactive.value")
                public static let inactiveCGColor = ThemeCGColorPicker(stringLiteral: "stepper.color.circle.inactive.value")
                /// Type: color
                public static let success = ThemeColorPicker(stringLiteral: "stepper.color.circle.success.value")
                public static let successCGColor = ThemeCGColorPicker(stringLiteral: "stepper.color.circle.success.value")
                /// Type: color
                public static let failed = ThemeColorPicker(stringLiteral: "stepper.color.circle.failed.value")
                public static let failedCGColor = ThemeCGColorPicker(stringLiteral: "stepper.color.circle.failed.value")
            }

            /// Type: color
            public static let icon = ThemeColorPicker(stringLiteral: "stepper.color.icon.value")
            public static let iconCGColor = ThemeCGColorPicker(stringLiteral: "stepper.color.icon.value")
            /// Type: color
            public static let connector = ThemeColorPicker(stringLiteral: "stepper.color.connector.value")
            public static let connectorCGColor = ThemeCGColorPicker(stringLiteral: "stepper.color.connector.value")
            public enum text {
                /// Type: color
                public static let number = ThemeColorPicker(stringLiteral: "stepper.color.text.number.value")
                public static let numberCGColor = ThemeCGColorPicker(stringLiteral: "stepper.color.text.number.value")
                /// Type: color
                public static let description = ThemeColorPicker(stringLiteral: "stepper.color.text.description.value")
                public static let descriptionCGColor = ThemeCGColorPicker(stringLiteral: "stepper.color.text.description.value")
                /// Type: color
                public static let title = ThemeColorPicker(stringLiteral: "stepper.color.text.title.value")
                public static let titleCGColor = ThemeCGColorPicker(stringLiteral: "stepper.color.text.title.value")
            }

            /// Type: color
            public static let progress = ThemeColorPicker(stringLiteral: "stepper.color.progress.value")
            public static let progressCGColor = ThemeCGColorPicker(stringLiteral: "stepper.color.progress.value")
        }

        public enum font {
            /// Type: typography
            public static let number = ThemeAnyPicker(keyPath: "stepper.font.number.value")
            public static let numberAttributedText = ThemeStringAttributesPicker(keyPath: "stepper.font.number.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let description = ThemeAnyPicker(keyPath: "stepper.font.description.value")
            public static let descriptionAttributedText = ThemeStringAttributesPicker(keyPath: "stepper.font.description.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let title = ThemeAnyPicker(keyPath: "stepper.font.title.value")
            public static let titleAttributedText = ThemeStringAttributesPicker(keyPath: "stepper.font.title.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }

        public enum spacing {
            public enum text {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "stepper.spacing.text.horizontal.value")
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "stepper.spacing.text.vertical.value")
            }

            public enum badge {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "stepper.spacing.badge.vertical.value")
            }
        }

        public enum gap {
            /// Type: spacing
            public static let connector = ThemeCGFloatPicker(stringLiteral: "stepper.gap.connector.value")
            /// Type: spacing
            public static let description = ThemeCGFloatPicker(stringLiteral: "stepper.gap.description.value")
        }

        public enum connector {
            /// Type: sizing
            public static let top = ThemeCGFloatPicker(stringLiteral: "stepper.connector.top.value")
        }
    }

    public enum pagination {
        public enum gap {
            /// Type: spacing
            public static let page = ThemeCGFloatPicker(stringLiteral: "pagination.gap.page.value")
        }

        public enum color {
            /// Type: color
            public static let active = ThemeColorPicker(stringLiteral: "pagination.color.active.value")
            public static let activeCGColor = ThemeCGColorPicker(stringLiteral: "pagination.color.active.value")
            /// Type: color
            public static let inactive = ThemeColorPicker(stringLiteral: "pagination.color.inactive.value")
            public static let inactiveCGColor = ThemeCGColorPicker(stringLiteral: "pagination.color.inactive.value")
        }
    }

    public enum highlights {
        public enum spacing {
            public enum row {
                /// Type: spacing
                public static let gap = ThemeCGFloatPicker(stringLiteral: "highlights.spacing.row.gap.value")
            }

            public enum padding {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "highlights.spacing.padding.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "highlights.spacing.padding.horizontal.value")
            }

            public enum content {
                /// Type: spacing
                public static let gap = ThemeCGFloatPicker(stringLiteral: "highlights.spacing.content.gap.value")
            }
        }
    }

    public enum notifications {
        public enum spacing {
            public enum content {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "notifications.spacing.content.horizontal.value")
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "notifications.spacing.content.vertical.value")
            }

            public enum icons {
                public enum horizontal {
                    /// Type: spacing
                    public static let left = ThemeCGFloatPicker(stringLiteral: "notifications.spacing.icons.horizontal.left.value")
                    /// Type: spacing
                    public static let right = ThemeCGFloatPicker(stringLiteral: "notifications.spacing.icons.horizontal.right.value")
                }

                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "notifications.spacing.icons.vertical.value")
            }
        }

        public enum gap {
            /// Type: spacing
            public static let vertical = ThemeCGFloatPicker(stringLiteral: "notifications.gap.vertical.value")
            public enum horizontal {
                /// Type: spacing
                public static let badge = ThemeCGFloatPicker(stringLiteral: "notifications.gap.horizontal.badge.value")
                /// Type: spacing
                public static let timestamp = ThemeCGFloatPicker(stringLiteral: "notifications.gap.horizontal.timestamp.value")
                /// Type: spacing
                public static let icons = ThemeCGFloatPicker(stringLiteral: "notifications.gap.horizontal.icons.value")
            }
        }

        public enum font {
            /// Type: typography
            public static let title = ThemeAnyPicker(keyPath: "notifications.font.title.value")
            public static let titleAttributedText = ThemeStringAttributesPicker(keyPath: "notifications.font.title.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let description = ThemeAnyPicker(keyPath: "notifications.font.description.value")
            public static let descriptionAttributedText = ThemeStringAttributesPicker(keyPath: "notifications.font.description.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            /// Type: typography
            public static let timestamp = ThemeAnyPicker(keyPath: "notifications.font.timestamp.value")
            public static let timestampAttributedText = ThemeStringAttributesPicker(keyPath: "notifications.font.timestamp.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }

        public enum color {
            public enum container {
                /// Type: color
                public static let selected = ThemeColorPicker(stringLiteral: "notifications.color.container.selected.value")
                public static let selectedCGColor = ThemeCGColorPicker(stringLiteral: "notifications.color.container.selected.value")
            }

            public enum text {
                public enum title {
                    /// Type: color
                    public static let read = ThemeColorPicker(stringLiteral: "notifications.color.text.title.read.value")
                    public static let readCGColor = ThemeCGColorPicker(stringLiteral: "notifications.color.text.title.read.value")
                    /// Type: color
                    public static let unread = ThemeColorPicker(stringLiteral: "notifications.color.text.title.unread.value")
                    public static let unreadCGColor = ThemeCGColorPicker(stringLiteral: "notifications.color.text.title.unread.value")
                }

                public enum description {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "notifications.color.text.description.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "notifications.color.text.description.default.value")
                }

                public enum timestamp {
                    /// Type: color
                    public static let defaultValue = ThemeColorPicker(stringLiteral: "notifications.color.text.timestamp.default.value")
                    public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "notifications.color.text.timestamp.default.value")
                }
            }

            public enum badge {
                /// Type: color
                public static let unread = ThemeColorPicker(stringLiteral: "notifications.color.badge.unread.value")
                public static let unreadCGColor = ThemeCGColorPicker(stringLiteral: "notifications.color.badge.unread.value")
            }
        }
    }

    public enum swipeToDelete {
        public enum spacing {
            /// Type: spacing
            public static let horizontal = ThemeCGFloatPicker(stringLiteral: "swipeToDelete.spacing.horizontal.value")
            /// Type: spacing
            public static let vertical = ThemeCGFloatPicker(stringLiteral: "swipeToDelete.spacing.vertical.value")
        }

        public enum color {
            public enum container {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "swipeToDelete.color.container.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "swipeToDelete.color.container.default.value")
            }

            public enum icon {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "swipeToDelete.color.icon.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "swipeToDelete.color.icon.default.value")
            }
        }
    }

    public enum banner {
        public enum utility {
            public enum color {
                public enum container {
                    /// Type: color
                    public static let alert = ThemeColorPicker(stringLiteral: "banner.utility.color.container.alert.value")
                    public static let alertCGColor = ThemeCGColorPicker(stringLiteral: "banner.utility.color.container.alert.value")
                    /// Type: color
                    public static let reminder = ThemeColorPicker(stringLiteral: "banner.utility.color.container.reminder.value")
                    public static let reminderCGColor = ThemeCGColorPicker(stringLiteral: "banner.utility.color.container.reminder.value")
                    /// Type: color
                    public static let promotional = ThemeColorPicker(stringLiteral: "banner.utility.color.container.promotional.value")
                    public static let promotionalCGColor = ThemeCGColorPicker(stringLiteral: "banner.utility.color.container.promotional.value")
                    /// Type: color
                    public static let informational = ThemeColorPicker(stringLiteral: "banner.utility.color.container.informational.value")
                    public static let informationalCGColor = ThemeCGColorPicker(stringLiteral: "banner.utility.color.container.informational.value")
                }

                /// Type: color
                public static let text = ThemeColorPicker(stringLiteral: "banner.utility.color.text.value")
                public static let textCGColor = ThemeCGColorPicker(stringLiteral: "banner.utility.color.text.value")
            }

            public enum font {
                /// Type: typography
                public static let header = ThemeAnyPicker(keyPath: "banner.utility.font.header.value")
                public static let headerAttributedText = ThemeStringAttributesPicker(keyPath: "banner.utility.font.header.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let body = ThemeAnyPicker(keyPath: "banner.utility.font.body.value")
                public static let bodyAttributedText = ThemeStringAttributesPicker(keyPath: "banner.utility.font.body.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            /// Type: borderRadius
            public static let borderRadius = ThemeCGFloatPicker(stringLiteral: "banner.utility.borderRadius.value")
            public enum spacing {
                /// Type: spacing
                public static let gap = ThemeCGFloatPicker(stringLiteral: "banner.utility.spacing.gap.value")
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "banner.utility.spacing.vertical.value")
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "banner.utility.spacing.horizontal.value")
            }
        }
    }

    public enum titlerows {
        public enum spacing {
            /// Type: spacing
            public static let horizontal = ThemeCGFloatPicker(stringLiteral: "titlerows.spacing.horizontal.value")
            /// Type: spacing
            public static let vertical = ThemeCGFloatPicker(stringLiteral: "titlerows.spacing.vertical.value")
        }

        public enum gap {
            /// Type: spacing
            public static let horizontal = ThemeCGFloatPicker(stringLiteral: "titlerows.gap.horizontal.value")
        }

        public enum borderRadius {
            /// Type: borderRadius
            public static let standard = ThemeCGFloatPicker(stringLiteral: "titlerows.borderRadius.standard.value")
            /// Type: borderRadius
            public static let incard = ThemeCGFloatPicker(stringLiteral: "titlerows.borderRadius.incard.value")
        }

        public enum color {
            /// Type: color
            public static let container = ThemeColorPicker(stringLiteral: "titlerows.color.container.value")
            public static let containerCGColor = ThemeCGColorPicker(stringLiteral: "titlerows.color.container.value")
            public enum text {
                /// Type: color
                public static let title = ThemeColorPicker(stringLiteral: "titlerows.color.text.title.value")
                public static let titleCGColor = ThemeCGColorPicker(stringLiteral: "titlerows.color.text.title.value")
                /// Type: color
                public static let description = ThemeColorPicker(stringLiteral: "titlerows.color.text.description.value")
                public static let descriptionCGColor = ThemeCGColorPicker(stringLiteral: "titlerows.color.text.description.value")
            }
        }

        public enum font {
            public enum title {
                /// Type: typography
                public static let large = ThemeAnyPicker(keyPath: "titlerows.font.title.large.value")
                public static let largeAttributedText = ThemeStringAttributesPicker(keyPath: "titlerows.font.title.large.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let small = ThemeAnyPicker(keyPath: "titlerows.font.title.small.value")
                public static let smallAttributedText = ThemeStringAttributesPicker(keyPath: "titlerows.font.title.small.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }

            public enum description {
                /// Type: typography
                public static let large = ThemeAnyPicker(keyPath: "titlerows.font.description.large.value")
                public static let largeAttributedText = ThemeStringAttributesPicker(keyPath: "titlerows.font.description.large.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let small = ThemeAnyPicker(keyPath: "titlerows.font.description.small.value")
                public static let smallAttributedText = ThemeStringAttributesPicker(keyPath: "titlerows.font.description.small.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }
        }
    }

    public enum productpalette {
        public enum color {
            public enum text {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "productpalette.color.text.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "productpalette.color.text.default.value")
                /// Type: color
                public static let disabled = ThemeColorPicker(stringLiteral: "productpalette.color.text.disabled.value")
                public static let disabledCGColor = ThemeCGColorPicker(stringLiteral: "productpalette.color.text.disabled.value")
            }
        }

        public enum spacing {
            /// Type: spacing
            public static let gap = ThemeCGFloatPicker(stringLiteral: "productpalette.spacing.gap.value")
            /// Type: spacing
            public static let vertical = ThemeCGFloatPicker(stringLiteral: "productpalette.spacing.vertical.value")
            /// Type: spacing
            public static let horizontal = ThemeCGFloatPicker(stringLiteral: "productpalette.spacing.horizontal.value")
            /// Type: spacing
            public static let padding = ThemeCGFloatPicker(stringLiteral: "productpalette.spacing.padding.value")
        }

        public enum font {
            /// Type: typography
            public static let label = ThemeAnyPicker(keyPath: "productpalette.font.label.value")
            public static let labelAttributedText = ThemeStringAttributesPicker(keyPath: "productpalette.font.label.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        }
    }

    public enum slider {
        public enum handle {
            /// Type: borderRadius
            public static let borderRadius = ThemeCGFloatPicker(stringLiteral: "slider.handle.borderRadius.value")
        }

        public enum color {
            public enum handle {
                /// Type: color
                public static let defaultValue = ThemeColorPicker(stringLiteral: "slider.color.handle.default.value")
                public static let defaultValueCGColor = ThemeCGColorPicker(stringLiteral: "slider.color.handle.default.value")
                /// Type: color
                public static let selected = ThemeColorPicker(stringLiteral: "slider.color.handle.selected.value")
                public static let selectedCGColor = ThemeCGColorPicker(stringLiteral: "slider.color.handle.selected.value")
                /// Type: color
                public static let shadow = ThemeColorPicker(stringLiteral: "slider.color.handle.shadow.value")
                public static let shadowCGColor = ThemeCGColorPicker(stringLiteral: "slider.color.handle.shadow.value")
                /// Type: color
                public static let border = ThemeColorPicker(stringLiteral: "slider.color.handle.border.value")
                public static let borderCGColor = ThemeCGColorPicker(stringLiteral: "slider.color.handle.border.value")
            }

            public enum track {
                /// Type: color
                public static let active = ThemeColorPicker(stringLiteral: "slider.color.track.active.value")
                public static let activeCGColor = ThemeCGColorPicker(stringLiteral: "slider.color.track.active.value")
                /// Type: color
                public static let inactive = ThemeColorPicker(stringLiteral: "slider.color.track.inactive.value")
                public static let inactiveCGColor = ThemeCGColorPicker(stringLiteral: "slider.color.track.inactive.value")
            }

            public enum text {
                public enum legend {
                    /// Type: color
                    public static let value = ThemeColorPicker(stringLiteral: "slider.color.text.legend.value.value")
                    public static let valueCGColor = ThemeCGColorPicker(stringLiteral: "slider.color.text.legend.value.value")
                    /// Type: color
                    public static let unit = ThemeColorPicker(stringLiteral: "slider.color.text.legend.unit.value")
                    public static let unitCGColor = ThemeCGColorPicker(stringLiteral: "slider.color.text.legend.unit.value")
                }

                public enum input {
                    public enum secondary {
                        /// Type: color
                        public static let prefix = ThemeColorPicker(stringLiteral: "slider.color.text.input.secondary.prefix.value")
                        public static let prefixCGColor = ThemeCGColorPicker(stringLiteral: "slider.color.text.input.secondary.prefix.value")
                        /// Type: color
                        public static let value = ThemeColorPicker(stringLiteral: "slider.color.text.input.secondary.value.value")
                        public static let valueCGColor = ThemeCGColorPicker(stringLiteral: "slider.color.text.input.secondary.value.value")
                    }
                }
            }
        }

        public enum font {
            public enum input {
                public enum secondary {
                    /// Type: typography
                    public static let prefix = ThemeAnyPicker(keyPath: "slider.font.input.secondary.prefix.value")
                    public static let prefixAttributedText = ThemeStringAttributesPicker(keyPath: "slider.font.input.secondary.prefix.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                    /// Type: typography
                    public static let value = ThemeAnyPicker(keyPath: "slider.font.input.secondary.value.value")
                    public static let valueAttributedText = ThemeStringAttributesPicker(keyPath: "slider.font.input.secondary.value.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                }
            }

            public enum legend {
                /// Type: typography
                public static let value = ThemeAnyPicker(keyPath: "slider.font.legend.value.value")
                public static let valueAttributedText = ThemeStringAttributesPicker(keyPath: "slider.font.legend.value.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
                /// Type: typography
                public static let unit = ThemeAnyPicker(keyPath: "slider.font.legend.unit.value")
                public static let unitAttributedText = ThemeStringAttributesPicker(keyPath: "slider.font.legend.unit.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
            }
        }

        public enum gap {
            /// Type: spacing
            public static let vertical = ThemeCGFloatPicker(stringLiteral: "slider.gap.vertical.value")
            public enum secondary {
                /// Type: spacing
                public static let horizontal = ThemeCGFloatPicker(stringLiteral: "slider.gap.secondary.horizontal.value")
            }

            public enum legend {
                /// Type: spacing
                public static let vertical = ThemeCGFloatPicker(stringLiteral: "slider.gap.legend.vertical.value")
            }
        }

        public enum spacing {
            public enum vertical {
                /// Type: spacing
                public static let top = ThemeCGFloatPicker(stringLiteral: "slider.spacing.vertical.top.value")
                /// Type: spacing
                public static let bottom = ThemeCGFloatPicker(stringLiteral: "slider.spacing.vertical.bottom.value")
            }

            public enum horizontal {
                /// Type: spacing
                public static let left = ThemeCGFloatPicker(stringLiteral: "slider.spacing.horizontal.left.value")
                /// Type: spacing
                public static let right = ThemeCGFloatPicker(stringLiteral: "slider.spacing.horizontal.right.value")
            }
        }
    }

    public enum core {
        /// Type: color
        public static let ashblue75 = ThemeColorPicker(stringLiteral: "core.ashblue75.value")
        public static let ashblue75CGColor = ThemeCGColorPicker(stringLiteral: "core.ashblue75.value")
        /// Type: color
        public static let ashblue100 = ThemeColorPicker(stringLiteral: "core.ashblue100.value")
        public static let ashblue100CGColor = ThemeCGColorPicker(stringLiteral: "core.ashblue100.value")
        /// Type: color
        public static let ashblue200 = ThemeColorPicker(stringLiteral: "core.ashblue200.value")
        public static let ashblue200CGColor = ThemeCGColorPicker(stringLiteral: "core.ashblue200.value")
        /// Type: color
        public static let ocbcred = ThemeColorPicker(stringLiteral: "core.ocbcred.value")
        public static let ocbcredCGColor = ThemeCGColorPicker(stringLiteral: "core.ocbcred.value")
        /// Type: color
        public static let royalblue100 = ThemeColorPicker(stringLiteral: "core.royalblue100.value")
        public static let royalblue100CGColor = ThemeCGColorPicker(stringLiteral: "core.royalblue100.value")
        /// Type: color
        public static let royalblue200 = ThemeColorPicker(stringLiteral: "core.royalblue200.value")
        public static let royalblue200CGColor = ThemeCGColorPicker(stringLiteral: "core.royalblue200.value")
        /// Type: color
        public static let sands100 = ThemeColorPicker(stringLiteral: "core.sands100.value")
        public static let sands100CGColor = ThemeCGColorPicker(stringLiteral: "core.sands100.value")
        /// Type: color
        public static let sands200 = ThemeColorPicker(stringLiteral: "core.sands200.value")
        public static let sands200CGColor = ThemeCGColorPicker(stringLiteral: "core.sands200.value")
        /// Type: color
        public static let cloudygrey200 = ThemeColorPicker(stringLiteral: "core.cloudygrey200.value")
        public static let cloudygrey200CGColor = ThemeCGColorPicker(stringLiteral: "core.cloudygrey200.value")
        /// Type: color
        public static let cloudygrey100 = ThemeColorPicker(stringLiteral: "core.cloudygrey100.value")
        public static let cloudygrey100CGColor = ThemeCGColorPicker(stringLiteral: "core.cloudygrey100.value")
        /// Type: color
        public static let warm100 = ThemeColorPicker(stringLiteral: "core.warm100.value")
        public static let warm100CGColor = ThemeCGColorPicker(stringLiteral: "core.warm100.value")
        /// Type: color
        public static let warm00 = ThemeColorPicker(stringLiteral: "core.warm00.value")
        public static let warm00CGColor = ThemeCGColorPicker(stringLiteral: "core.warm00.value")
    }

    public enum neutrals {
        /// Type: color
        public static let white = ThemeColorPicker(stringLiteral: "neutrals.white.value")
        public static let whiteCGColor = ThemeCGColorPicker(stringLiteral: "neutrals.white.value")
        /// Type: color
        public static let neutral100 = ThemeColorPicker(stringLiteral: "neutrals.neutral100.value")
        public static let neutral100CGColor = ThemeCGColorPicker(stringLiteral: "neutrals.neutral100.value")
        /// Type: color
        public static let neutral200 = ThemeColorPicker(stringLiteral: "neutrals.neutral200.value")
        public static let neutral200CGColor = ThemeCGColorPicker(stringLiteral: "neutrals.neutral200.value")
        /// Type: color
        public static let neutral300 = ThemeColorPicker(stringLiteral: "neutrals.neutral300.value")
        public static let neutral300CGColor = ThemeCGColorPicker(stringLiteral: "neutrals.neutral300.value")
        /// Type: color
        public static let neutral400 = ThemeColorPicker(stringLiteral: "neutrals.neutral400.value")
        public static let neutral400CGColor = ThemeCGColorPicker(stringLiteral: "neutrals.neutral400.value")
        /// Type: color
        public static let neutral500 = ThemeColorPicker(stringLiteral: "neutrals.neutral500.value")
        public static let neutral500CGColor = ThemeCGColorPicker(stringLiteral: "neutrals.neutral500.value")
        /// Type: color
        public static let neutral600 = ThemeColorPicker(stringLiteral: "neutrals.neutral600.value")
        public static let neutral600CGColor = ThemeCGColorPicker(stringLiteral: "neutrals.neutral600.value")
        /// Type: color
        public static let neutral700 = ThemeColorPicker(stringLiteral: "neutrals.neutral700.value")
        public static let neutral700CGColor = ThemeCGColorPicker(stringLiteral: "neutrals.neutral700.value")
        /// Type: color
        public static let neutral800 = ThemeColorPicker(stringLiteral: "neutrals.neutral800.value")
        public static let neutral800CGColor = ThemeCGColorPicker(stringLiteral: "neutrals.neutral800.value")
    }

    public enum semantic {
        /// Type: color
        public static let alert100 = ThemeColorPicker(stringLiteral: "semantic.alert100.value")
        public static let alert100CGColor = ThemeCGColorPicker(stringLiteral: "semantic.alert100.value")
        /// Type: color
        public static let alertVariant100 = ThemeColorPicker(stringLiteral: "semantic.alertVariant100.value")
        public static let alertVariant100CGColor = ThemeCGColorPicker(stringLiteral: "semantic.alertVariant100.value")
        /// Type: color
        public static let success100 = ThemeColorPicker(stringLiteral: "semantic.success100.value")
        public static let success100CGColor = ThemeCGColorPicker(stringLiteral: "semantic.success100.value")
        /// Type: color
        public static let successVariant100 = ThemeColorPicker(stringLiteral: "semantic.successVariant100.value")
        public static let successVariant100CGColor = ThemeCGColorPicker(stringLiteral: "semantic.successVariant100.value")
        /// Type: color
        public static let error100 = ThemeColorPicker(stringLiteral: "semantic.error100.value")
        public static let error100CGColor = ThemeCGColorPicker(stringLiteral: "semantic.error100.value")
        /// Type: color
        public static let errorVariant100 = ThemeColorPicker(stringLiteral: "semantic.errorVariant100.value")
        public static let errorVariant100CGColor = ThemeCGColorPicker(stringLiteral: "semantic.errorVariant100.value")
    }

    public enum gradients {
        /// Type: color
        public static let neutralWarm = ThemeColorPicker(stringLiteral: "gradients.neutralWarm.value")
        public static let neutralWarmCGColor = ThemeCGColorPicker(stringLiteral: "gradients.neutralWarm.value")
        /// Type: color
        public static let neutralCool = ThemeColorPicker(stringLiteral: "gradients.neutralCool.value")
        public static let neutralCoolCGColor = ThemeCGColorPicker(stringLiteral: "gradients.neutralCool.value")
        /// Type: color
        public static let ashClear = ThemeColorPicker(stringLiteral: "gradients.ashClear.value")
        public static let ashClearCGColor = ThemeCGColorPicker(stringLiteral: "gradients.ashClear.value")
        /// Type: color
        public static let ashCool = ThemeColorPicker(stringLiteral: "gradients.ashCool.value")
        public static let ashCoolCGColor = ThemeCGColorPicker(stringLiteral: "gradients.ashCool.value")
        /// Type: color
        public static let ashWarm = ThemeColorPicker(stringLiteral: "gradients.ashWarm.value")
        public static let ashWarmCGColor = ThemeCGColorPicker(stringLiteral: "gradients.ashWarm.value")
        /// Type: color
        public static let ashGrey = ThemeColorPicker(stringLiteral: "gradients.ashGrey.value")
        public static let ashGreyCGColor = ThemeCGColorPicker(stringLiteral: "gradients.ashGrey.value")
        /// Type: color
        public static let whiteClear = ThemeColorPicker(stringLiteral: "gradients.whiteClear.value")
        public static let whiteClearCGColor = ThemeCGColorPicker(stringLiteral: "gradients.whiteClear.value")
        /// Type: color
        public static let blush = ThemeColorPicker(stringLiteral: "gradients.blush.value")
        public static let blushCGColor = ThemeCGColorPicker(stringLiteral: "gradients.blush.value")
        /// Type: color
        public static let ombre = ThemeColorPicker(stringLiteral: "gradients.ombre.value")
        public static let ombreCGColor = ThemeCGColorPicker(stringLiteral: "gradients.ombre.value")
        /// Type: color
        public static let dawn = ThemeColorPicker(stringLiteral: "gradients.dawn.value")
        public static let dawnCGColor = ThemeCGColorPicker(stringLiteral: "gradients.dawn.value")
        /// Type: color
        public static let dusk = ThemeColorPicker(stringLiteral: "gradients.dusk.value")
        public static let duskCGColor = ThemeCGColorPicker(stringLiteral: "gradients.dusk.value")
        /// Type: color
        public static let sandstorm = ThemeColorPicker(stringLiteral: "gradients.sandstorm.value")
        public static let sandstormCGColor = ThemeCGColorPicker(stringLiteral: "gradients.sandstorm.value")
        /// Type: color
        public static let desert = ThemeColorPicker(stringLiteral: "gradients.desert.value")
        public static let desertCGColor = ThemeCGColorPicker(stringLiteral: "gradients.desert.value")
        /// Type: color
        public static let milk = ThemeColorPicker(stringLiteral: "gradients.milk.value")
        public static let milkCGColor = ThemeCGColorPicker(stringLiteral: "gradients.milk.value")
        /// Type: color
        public static let alert = ThemeColorPicker(stringLiteral: "gradients.alert.value")
        public static let alertCGColor = ThemeCGColorPicker(stringLiteral: "gradients.alert.value")
        /// Type: color
        public static let reminder = ThemeColorPicker(stringLiteral: "gradients.reminder.value")
        public static let reminderCGColor = ThemeCGColorPicker(stringLiteral: "gradients.reminder.value")
        /// Type: color
        public static let promotional = ThemeColorPicker(stringLiteral: "gradients.promotional.value")
        public static let promotionalCGColor = ThemeCGColorPicker(stringLiteral: "gradients.promotional.value")
    }

    public enum opensans {
        /// Type: typography
        public static let h3Bold = ThemeAnyPicker(keyPath: "opensans.h3-bold.value")
        public static let h3BoldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h3-bold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h3Regular = ThemeAnyPicker(keyPath: "opensans.h3-regular.value")
        public static let h3RegularAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h3-regular.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h4Bold = ThemeAnyPicker(keyPath: "opensans.h4-bold.value")
        public static let h4BoldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h4-bold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h4Semibold = ThemeAnyPicker(keyPath: "opensans.h4-semibold.value")
        public static let h4SemiboldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h4-semibold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h4Regular = ThemeAnyPicker(keyPath: "opensans.h4-regular.value")
        public static let h4RegularAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h4-regular.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h5Bold = ThemeAnyPicker(keyPath: "opensans.h5-bold.value")
        public static let h5BoldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h5-bold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h5Semibold = ThemeAnyPicker(keyPath: "opensans.h5-semibold.value")
        public static let h5SemiboldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h5-semibold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h5Regular = ThemeAnyPicker(keyPath: "opensans.h5-regular.value")
        public static let h5RegularAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h5-regular.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h1Bold = ThemeAnyPicker(keyPath: "opensans.h1-bold.value")
        public static let h1BoldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h1-bold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h1Semibold = ThemeAnyPicker(keyPath: "opensans.h1-semibold.value")
        public static let h1SemiboldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h1-semibold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h1Regular = ThemeAnyPicker(keyPath: "opensans.h1-regular.value")
        public static let h1RegularAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h1-regular.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h2Bold = ThemeAnyPicker(keyPath: "opensans.h2-bold.value")
        public static let h2BoldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h2-bold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h2Semibold = ThemeAnyPicker(keyPath: "opensans.h2-semibold.value")
        public static let h2SemiboldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h2-semibold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h2Regular = ThemeAnyPicker(keyPath: "opensans.h2-regular.value")
        public static let h2RegularAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h2-regular.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h3Semibold = ThemeAnyPicker(keyPath: "opensans.h3-semibold.value")
        public static let h3SemiboldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h3-semibold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h6Regular = ThemeAnyPicker(keyPath: "opensans.h6-regular.value")
        public static let h6RegularAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h6-regular.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h6Semibold = ThemeAnyPicker(keyPath: "opensans.h6-semibold.value")
        public static let h6SemiboldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h6-semibold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h6Bold = ThemeAnyPicker(keyPath: "opensans.h6-bold.value")
        public static let h6BoldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h6-bold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h7Regular = ThemeAnyPicker(keyPath: "opensans.h7-regular.value")
        public static let h7RegularAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h7-regular.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h7Semibold = ThemeAnyPicker(keyPath: "opensans.h7-semibold.value")
        public static let h7SemiboldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h7-semibold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h7Bold = ThemeAnyPicker(keyPath: "opensans.h7-bold.value")
        public static let h7BoldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.h7-bold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let eyebrow1Semibold = ThemeAnyPicker(keyPath: "opensans.eyebrow1-semibold.value")
        public static let eyebrow1SemiboldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.eyebrow1-semibold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let eyebrow1Bold = ThemeAnyPicker(keyPath: "opensans.eyebrow1-bold.value")
        public static let eyebrow1BoldAttributedText = ThemeStringAttributesPicker(keyPath: "opensans.eyebrow1-bold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
    }

    public enum geomanist {
        /// Type: typography
        public static let h1Medium = ThemeAnyPicker(keyPath: "geomanist.h1-medium.value")
        public static let h1MediumAttributedText = ThemeStringAttributesPicker(keyPath: "geomanist.h1-medium.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h2Medium = ThemeAnyPicker(keyPath: "geomanist.h2-medium.value")
        public static let h2MediumAttributedText = ThemeStringAttributesPicker(keyPath: "geomanist.h2-medium.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
        /// Type: typography
        public static let h3Semibold = ThemeAnyPicker(keyPath: "geomanist.h3-semibold.value")
        public static let h3SemiboldAttributedText = ThemeStringAttributesPicker(keyPath: "geomanist.h3-semibold.value", map: { FigmaTypography(figmaValuesRaw: $0).attributedText })
    }

    public enum extended {
        /// Type: color
        public static let rosegold = ThemeColorPicker(stringLiteral: "extended.rosegold.value")
        public static let rosegoldCGColor = ThemeCGColorPicker(stringLiteral: "extended.rosegold.value")
        /// Type: color
        public static let mistyrose = ThemeColorPicker(stringLiteral: "extended.mistyrose.value")
        public static let mistyroseCGColor = ThemeCGColorPicker(stringLiteral: "extended.mistyrose.value")
        /// Type: color
        public static let peachyrose = ThemeColorPicker(stringLiteral: "extended.peachyrose.value")
        public static let peachyroseCGColor = ThemeCGColorPicker(stringLiteral: "extended.peachyrose.value")
        /// Type: color
        public static let moodyblue = ThemeColorPicker(stringLiteral: "extended.moodyblue.value")
        public static let moodyblueCGColor = ThemeCGColorPicker(stringLiteral: "extended.moodyblue.value")
        /// Type: color
        public static let lemonzest = ThemeColorPicker(stringLiteral: "extended.lemonzest.value")
        public static let lemonzestCGColor = ThemeCGColorPicker(stringLiteral: "extended.lemonzest.value")
        /// Type: color
        public static let caramel = ThemeColorPicker(stringLiteral: "extended.caramel.value")
        public static let caramelCGColor = ThemeCGColorPicker(stringLiteral: "extended.caramel.value")
        /// Type: color
        public static let latte = ThemeColorPicker(stringLiteral: "extended.latte.value")
        public static let latteCGColor = ThemeCGColorPicker(stringLiteral: "extended.latte.value")
        /// Type: color
        public static let fossil = ThemeColorPicker(stringLiteral: "extended.fossil.value")
        public static let fossilCGColor = ThemeCGColorPicker(stringLiteral: "extended.fossil.value")
    }

    public enum lineHeights {
        /// Type: lineHeights
        public static let xBig = ThemeAnyPicker(keyPath: "lineHeights.xBig.value")
        /// Type: lineHeights
        public static let big = ThemeAnyPicker(keyPath: "lineHeights.big.value")
        /// Type: lineHeights
        public static let xxl = ThemeAnyPicker(keyPath: "lineHeights.xxl.value")
        /// Type: lineHeights
        public static let xl = ThemeAnyPicker(keyPath: "lineHeights.xl.value")
        /// Type: lineHeights
        public static let l = ThemeAnyPicker(keyPath: "lineHeights.l.value")
        /// Type: lineHeights
        public static let m = ThemeAnyPicker(keyPath: "lineHeights.m.value")
        /// Type: lineHeights
        public static let s = ThemeAnyPicker(keyPath: "lineHeights.s.value")
        /// Type: lineHeights
        public static let xs = ThemeAnyPicker(keyPath: "lineHeights.xs.value")
        /// Type: lineHeights
        public static let xxs = ThemeAnyPicker(keyPath: "lineHeights.xxs.value")
    }

    public enum fontFamilies {
        /// Type: fontFamilies
        public static let roboto = ThemeAnyPicker(keyPath: "fontFamilies.roboto.value")
        /// Type: fontFamilies
        public static let opensans = ThemeAnyPicker(keyPath: "fontFamilies.opensans.value")
        /// Type: fontFamilies
        public static let poppins = ThemeAnyPicker(keyPath: "fontFamilies.poppins.value")
        /// Type: fontFamilies
        public static let geomanist = ThemeAnyPicker(keyPath: "fontFamilies.geomanist.value")
    }

    public enum borderWidth {
        /// Type: borderWidth
        public static let s = ThemeCGFloatPicker(stringLiteral: "borderWidth.s.value")
        /// Type: borderWidth
        public static let m = ThemeCGFloatPicker(stringLiteral: "borderWidth.m.value")
    }

    public enum borderRadius {
        /// Type: borderRadius
        public static let xs = ThemeCGFloatPicker(stringLiteral: "borderRadius.xs.value")
        /// Type: borderRadius
        public static let s = ThemeCGFloatPicker(stringLiteral: "borderRadius.s.value")
        /// Type: borderRadius
        public static let m = ThemeCGFloatPicker(stringLiteral: "borderRadius.m.value")
        /// Type: borderRadius
        public static let ml = ThemeCGFloatPicker(stringLiteral: "borderRadius.ml.value")
        /// Type: borderRadius
        public static let l = ThemeCGFloatPicker(stringLiteral: "borderRadius.l.value")
        /// Type: borderRadius
        public static let big = ThemeCGFloatPicker(stringLiteral: "borderRadius.big.value")
        /// Type: borderRadius
        public static let xl = ThemeCGFloatPicker(stringLiteral: "borderRadius.xl.value")
        /// Type: borderRadius
        public static let xxl = ThemeCGFloatPicker(stringLiteral: "borderRadius.xxl.value")
        /// Type: borderRadius
        public static let none = ThemeCGFloatPicker(stringLiteral: "borderRadius.none.value")
    }

    public enum fontWeights {
        /// Type: fontWeights
        public static let light = ThemeAnyPicker(keyPath: "fontWeights.light.value")
        /// Type: fontWeights
        public static let regular = ThemeAnyPicker(keyPath: "fontWeights.regular.value")
        /// Type: fontWeights
        public static let medium = ThemeAnyPicker(keyPath: "fontWeights.medium.value")
        /// Type: fontWeights
        public static let semibold = ThemeAnyPicker(keyPath: "fontWeights.semibold.value")
        /// Type: fontWeights
        public static let bold = ThemeAnyPicker(keyPath: "fontWeights.bold.value")
        /// Type: fontWeights
        public static let book = ThemeAnyPicker(keyPath: "fontWeights.book.value")
    }

    public enum fontSize {
        /// Type: fontSizes
        public static let xxxs = ThemeAnyPicker(keyPath: "fontSize.xxxs.value")
        /// Type: fontSizes
        public static let xxs = ThemeAnyPicker(keyPath: "fontSize.xxs.value")
        /// Type: fontSizes
        public static let xs = ThemeAnyPicker(keyPath: "fontSize.xs.value")
        /// Type: fontSizes
        public static let s = ThemeAnyPicker(keyPath: "fontSize.s.value")
        /// Type: fontSizes
        public static let m = ThemeAnyPicker(keyPath: "fontSize.m.value")
        /// Type: fontSizes
        public static let l = ThemeAnyPicker(keyPath: "fontSize.l.value")
        /// Type: fontSizes
        public static let xl = ThemeAnyPicker(keyPath: "fontSize.xl.value")
        /// Type: fontSizes
        public static let xxl = ThemeAnyPicker(keyPath: "fontSize.xxl.value")
        /// Type: fontSizes
        public static let xxxl = ThemeAnyPicker(keyPath: "fontSize.xxxl.value")
        /// Type: fontSizes
        public static let big = ThemeAnyPicker(keyPath: "fontSize.big.value")
    }

    public enum letterSpacing {
        /// Type: letterSpacing
        public static let none = ThemeAnyPicker(keyPath: "letterSpacing.none.value")
        /// Type: letterSpacing
        public static let s = ThemeAnyPicker(keyPath: "letterSpacing.s.value")
    }

    public enum paragraphSpacing {
        /// Type: paragraphSpacing
        public static let none = ThemeAnyPicker(keyPath: "paragraphSpacing.none.value")
    }

    public enum textCase {
        /// Type: textCase
        public static let none = ThemeAnyPicker(keyPath: "textCase.none.value")
        /// Type: textCase
        public static let uppercase = ThemeAnyPicker(keyPath: "textCase.uppercase.value")
    }

    public enum textDecoration {
        /// Type: textDecoration
        public static let none = ThemeAnyPicker(keyPath: "textDecoration.none.value")
    }

    public enum space {
        /// Type: spacing
        public static let none = ThemeCGFloatPicker(stringLiteral: "space.none.value")
        /// Type: spacing
        public static let xxxxs = ThemeCGFloatPicker(stringLiteral: "space.xxxxs.value")
        /// Type: spacing
        public static let xxxs = ThemeCGFloatPicker(stringLiteral: "space.xxxs.value")
        /// Type: spacing
        public static let xxs = ThemeCGFloatPicker(stringLiteral: "space.xxs.value")
        /// Type: spacing
        public static let xs = ThemeCGFloatPicker(stringLiteral: "space.xs.value")
        /// Type: spacing
        public static let s = ThemeCGFloatPicker(stringLiteral: "space.s.value")
        /// Type: spacing
        public static let ms = ThemeCGFloatPicker(stringLiteral: "space.ms.value")
        /// Type: spacing
        public static let m = ThemeCGFloatPicker(stringLiteral: "space.m.value")
        /// Type: spacing
        public static let l = ThemeCGFloatPicker(stringLiteral: "space.l.value")
        /// Type: spacing
        public static let xl = ThemeCGFloatPicker(stringLiteral: "space.xl.value")
        /// Type: spacing
        public static let xxl = ThemeCGFloatPicker(stringLiteral: "space.xxl.value")
        /// Type: spacing
        public static let xxxl = ThemeCGFloatPicker(stringLiteral: "space.xxxl.value")
        /// Type: spacing
        public static let xxxxl = ThemeCGFloatPicker(stringLiteral: "space.xxxxl.value")
        /// Type: spacing
        public static let big = ThemeCGFloatPicker(stringLiteral: "space.big.value")
        /// Type: spacing
        public static let xBig = ThemeCGFloatPicker(stringLiteral: "space.xBig.value")
        /// Type: spacing
        public static let xxBig = ThemeCGFloatPicker(stringLiteral: "space.xxBig.value")
    }

    public enum size {
        /// Type: sizing
        public static let xxs = ThemeCGFloatPicker(stringLiteral: "size.xxs.value")
        /// Type: sizing
        public static let xs = ThemeCGFloatPicker(stringLiteral: "size.xs.value")
        /// Type: sizing
        public static let s = ThemeCGFloatPicker(stringLiteral: "size.s.value")
        /// Type: sizing
        public static let m = ThemeCGFloatPicker(stringLiteral: "size.m.value")
        /// Type: sizing
        public static let ml = ThemeCGFloatPicker(stringLiteral: "size.ml.value")
        /// Type: sizing
        public static let l = ThemeCGFloatPicker(stringLiteral: "size.l.value")
        /// Type: sizing
        public static let xl = ThemeCGFloatPicker(stringLiteral: "size.xl.value")
    }

    public enum elevation {
        /// Type: boxShadow
        public static let none = ThemeAnyPicker(keyPath: "elevation.none.value")
        /// Type: boxShadow
        public static let xs = ThemeAnyPicker(keyPath: "elevation.xs.value")
        /// Type: boxShadow
        public static let s = ThemeAnyPicker(keyPath: "elevation.s.value")
        /// Type: boxShadow
        public static let xl = ThemeAnyPicker(keyPath: "elevation.xl.value")
        public enum m {
            /// Type: boxShadow
            public static let btm = ThemeAnyPicker(keyPath: "elevation.m.btm.value")
            /// Type: boxShadow
            public static let top = ThemeAnyPicker(keyPath: "elevation.m.top.value")
        }

        public enum xxs {
            /// Type: boxShadow
            public static let top = ThemeAnyPicker(keyPath: "elevation.xxs.top.value")
            /// Type: boxShadow
            public static let btm = ThemeAnyPicker(keyPath: "elevation.xxs.btm.value")
        }

        public enum l {
            /// Type: boxShadow
            public static let btm = ThemeAnyPicker(keyPath: "elevation.l.btm.value")
            /// Type: boxShadow
            public static let top = ThemeAnyPicker(keyPath: "elevation.l.top.value")
        }
    }
}
